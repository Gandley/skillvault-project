# OPENCLAW THANK YOU PAGE DIRECTIVE

**Purpose:** Generate a thank you or confirmation page that does more than confirm a transaction. A well-built thank you page builds trust immediately after conversion, sets clear expectations, reduces buyer's remorse, and — where appropriate — opens the door to the next offer.

**Core Principle:** The thank you page is the most underused real estate in any funnel. The reader just said yes. Their trust is at its highest point. Their attention is focused. This is not the place to coast — it is the place to deepen the relationship and extend the value chain.

**Tone Rule:** This is not a sales page. Excitement and clarity are the goals. The reader should feel confirmed, welcomed, and certain about what happens next. Never make them feel immediately sold to again.

---

## INPUT VARIABLES

| Variable | Purpose |
|---|---|
| `what_they_got` | What was just purchased or opted into |
| `next_step` | What happens now — delivery method, access link, email sequence, etc. |
| `upsell_offer` | The next logical offer (optional) |
| `mode_preference` | `post-purchase` / `post-optin` / blank for Jake to decide |

---

## STEP 01 — INPUT EVALUATION & RECOMMENDATIONS

Before building, Jake evaluates the inputs and outputs three recommendations.

### 1. Mode Confirmation

If mode is left blank, Jake selects based on what was provided:

| Situation | Mode |
|---|---|
| Product, course, or paid offer was purchased | `post-purchase` |
| Free lead magnet, checklist, or free resource was opted into | `post-optin` |
| Free trial or free account was created | `post-optin` with purchase nudge note |
| Webinar or event registration | `post-optin` with event-specific next steps |

### 2. Upsell Viability Assessment

If an upsell is provided, Jake evaluates whether it should be presented and how aggressively:

| Situation | Recommendation |
|---|---|
| Upsell is a natural next step to what was just purchased | Present — use the full upsell block |
| Upsell is loosely related | Present softly — frame as a resource, not a push |
| Upsell is unrelated to what was just purchased | Do not present — flag this mismatch to the user |
| No upsell provided | Skip the upsell block entirely — do not manufacture one |

**Rule:** A forced or irrelevant upsell on a thank you page destroys trust at the exact moment it's highest. If the fit isn't clear, Jake flags it and leaves the block empty rather than guessing.

### 3. Next Step Clarity Check

Jake reviews the `next_step` input and flags if it's vague or incomplete:
- If next steps are unclear or missing — flag before building: `[NEXT STEP UNCLEAR — clarify before deployment]`
- The next step section is the most important functional element on this page — a confused buyer becomes a refund request

### Evaluation Output Format

```
## INPUT EVALUATION
---
Mode: [post-purchase / post-optin] — [reason if not specified by user]
Upsell: [Present / Present softly / Skip] — [reason]
Next Step Clarity: [Clear / Needs clarification] — [note if flagged]
---
```

---

## MODE A — POST-PURCHASE THANK YOU PAGE

Use when: a paid product, course, membership, or service was just purchased.

---

### SECTION 01 — CONFIRMATION HEADLINE

```
[Headline — warm, celebratory, specific to what they bought]
[Sub-headline — 1 line reinforcing the decision they just made]
```

**Rules:**
- Name what they just got — don't be generic ("Your order is confirmed" is weak)
- Make them feel smart for buying — this is buyer's remorse prevention
- Keep it warm and human — they just spent money, meet that moment
- Examples:
  - "You're in. [Product Name] is on its way."
  - "Great call. Here's everything you just unlocked."
  - "Welcome to the other side. Let's get you started."

---

### SECTION 02 — WHAT HAPPENS NEXT

```
[Section headline: "Here's What Happens Now" or similar]
[2–4 clear, numbered steps]
```

**Rules:**
- This is the most important functional section on the page
- Every step must be specific — not "check your email" but "check your inbox at [email] for a message from [sender name] with subject line '[subject]'"
- Number the steps — sequence matters and numbered lists reduce anxiety
- Include timeframes where relevant ("within 5 minutes," "immediately," "within 24 hours")
- If there is an access link, note where it appears: `[ACCESS LINK — insert here]`
- Cover: how they access what they bought, what to do if something goes wrong, what comes next after first access

---

### SECTION 03 — UPSELL BLOCK (conditional)

Only include if upsell viability assessment recommends it.

```
[Upsell transition headline — bridge from the purchase to the next offer]
[2–3 sentences explaining what it is and why it's the logical next step]
[Benefit bullet stack — 2–3 bullets, outcome-focused]
[Upsell CTA button]
[Micro reassurance — price, what they get, no obligation]
```

**Rules:**
- Open the upsell with a connection to what they just bought — never cold pivot
- Frame it as the natural next step, not a new sale: "Since you just grabbed X, the next thing most people want is Y"
- Keep the pitch short — 2–3 sentences max before the bullets
- The tone shifts slightly here but must stay warm — this is a recommendation, not a hard sell
- If presenting softly: frame as a resource or bonus opportunity, remove urgency language
- Price must be visible — never hide it on a thank you page upsell

---

### SECTION 04 — COMMUNITY OR SOCIAL INVITE (optional)

```
[1–2 sentences inviting them into a community, group, or social channel]
[Link placeholder or button]
```

**Rules:**
- Only include if a real community exists — do not manufacture this section
- Facebook group, Slack, Discord, or community platform
- Frame as belonging, not obligation: "Join 2,400+ members already inside" not "You must join our group"
- Keep it brief — this is a secondary action, not the focus

---

### SECTION 05 — REASSURANCE CLOSE

```
[2–3 sentences — warm close that reinforces the decision and sets a positive tone]
[Optional: signature line from the founder/brand]
```

**Rules:**
- This is the last thing they read — make it human
- Reinforce that they made the right call without overselling
- Can include a direct line from the founder if the brand has a personal face
- Examples:
  - "If you ever have questions, we're one email away at [support email]. We want to see you win with this."
  - "You made a great decision today. Now let's make it count."

---

## MODE B — POST-OPT-IN THANK YOU PAGE

Use when: a free lead magnet, checklist, guide, webinar registration, or free resource was just opted into.

---

### SECTION 01 — CONFIRMATION HEADLINE

```
[Headline — confirms delivery and names what they're getting]
[Sub-headline — builds anticipation for what's coming]
```

**Rules:**
- Confirm the delivery immediately — they want to know it's on its way
- Name the specific lead magnet — not "your free resource"
- Build forward momentum toward opening the email or taking the next step
- Examples:
  - "It's on its way. Check your inbox for [Lead Magnet Name]."
  - "You're in. [Lead Magnet Name] is heading to your inbox right now."
  - "Done. Your [Lead Magnet Name] is on its way — here's what to do next."

---

### SECTION 02 — WHAT TO EXPECT

```
[Section headline: "Here's What's Coming" or similar]
[3–5 short points or sentences about what the email sequence or next steps contain]
```

**Rules:**
- Set expectations for the email sequence if one exists — tell them what's coming and when
- Frame each email or step as a benefit, not a description
  - Weak: "Email 2 covers list building"
  - Strong: "In your second email, you'll get the exact framework we use to add 50+ subscribers a week — no ads required"
- This section reduces unsubscribes by making the sequence feel valuable before it arrives
- If there is no email sequence — just confirm delivery and tell them what to do when the email arrives

---

### SECTION 03 — SOFT NEXT STEP (optional)

```
[1 transition sentence]
[Brief description of a relevant paid offer or next resource — 2–3 sentences]
[Soft CTA — curiosity-driven, not transactional]
```

**Rules:**
- This is not an upsell — it is a gentle pointer to what exists next
- Only include if there is a clearly relevant paid offer
- No price on this page — if they click through, the offer page handles that
- Tone: "When you're ready, here's where most people go next" not "Buy this now"
- CTA examples: "See how it works →" / "Take a look →" / "Learn more →"

---

### SECTION 04 — REASSURANCE CLOSE

```
[2–3 sentences — warm, human close]
```

**Rules:**
- Confirm they made a good call opting in
- Tell them you won't spam them — earn the inbox
- Keep it personal and brief
- Example: "We take your inbox seriously. You'll only hear from us when we have something worth your time. Talk soon."

---

## OUTPUT FORMAT

```
## INPUT EVALUATION
---
[Mode, upsell, and next step assessment]
---

## [SECTION NAME]
---
[Copy]
---
```

Each section labeled and self-contained for deployment. Deliver every section in full — do not summarize or compress.

---

*License: Open — any agent may use this skill*
*Created: 2026-05-21*
