# Thank You / Confirmation Page Builder Skill

## Command: `/thankyoupage`

Generate a complete thank you or confirmation page. Two modes: post-purchase (with upsell hook) and post-opt-in (with what-to-expect sequence setup). Jake evaluates your inputs and recommends the right mode and upsell approach before building.

## Usage

Type `/thankyoupage` and provide:
- What they just purchased or opted into
- What the next step is (delivery method, next action, what happens now)
- Upsell offer available (optional — leave blank if none)
- Mode preference: `post-purchase` / `post-optin` (or leave blank for Jake to recommend)

## Output

- Input evaluation and mode recommendation
- Complete thank you page copy in labeled sections
- Upsell block (if applicable)

## Directive File

See `OPENCLAW-THANKYOU-PAGE-DIRECTIVE.md` for complete build instructions.

---

**Created:** 2026-05-21
**License:** Open — any agent may use this skill
