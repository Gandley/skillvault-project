# ElevenLabs API Reference

## Base URL

All endpoints use `https://api.elevenlabs.io/v1/` as the base URL.

## Authentication

Every request must include the API key in the `xi-api-key` header:

```
xi-api-key: {ELEVENLABS_API_KEY}
```

## Endpoints

### Text-to-Speech Methods

| Method | Endpoint | Description |
|---|---|---|
| `POST` | `/text-to-speech/{voice_id}` | Create audio from text |
| `POST` | `/text-to-speech/{voice_id}/stream` | Stream audio from text |

### Voice Methods

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/voices` | List all voices |
| `GET` | `/voices/{voice_id}` | Get voice details |
| `POST` | `/voices/add` | Add/clone a voice |
| `DELETE` | `/voices/{voice_id}` | Delete a voice |
| `POST` | `/voices/{voice_id}/edit` | Edit voice details |

### Sound Generation Methods

| Method | Endpoint | Description |
|---|---|---|
| `POST` | `/sound-generation` | Create sound effects |

### History Methods

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/history` | Get audio generation history |
| `GET` | `/history/{history_item_id}` | Get history item details |
| `DELETE` | `/history/{history_item_id}` | Delete history item |

## Models

| Model ID | Description |
|---|---|
| `eleven_multilingual_v2` | Best for multilingual support |
| `eleven_monolingual_v1` | Best for English |
| `eleven_turbo_v2` | Fastest generation |

## Rate Limits

ElevenLabs applies rate limits based on the account tier. If a `429` response is received, wait for the number of seconds in the `Retry-After` header before retrying.

## Error Codes

| Error | Description |
|---|---|
| `invalid_api_key` | No API key provided or invalid API key |
| `voice_not_found` | Voice ID does not exist |
| `insufficient_quota` | Out of characters or monthly limit reached |
| `rate_limit_exceeded` | Rate limit exceeded |
| `internal_server_error` | Internal server error |
