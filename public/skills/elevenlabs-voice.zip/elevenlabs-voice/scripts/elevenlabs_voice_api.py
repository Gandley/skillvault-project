#!/usr/bin/env python3
"""
ElevenLabs API Helper Script

Provides convenient CLI commands for common ElevenLabs operations.
Reads ELEVENLABS_API_KEY from environment variable.

Usage:
    elevenlabs_voice_api.py tts --text TEXT --voice-id ID [--output PATH]
    elevenlabs_voice_api.py list-voices
    elevenlabs_voice_api.py get-voice --voice-id ID
    elevenlabs_voice_api.py add-voice --name NAME --file PATH
    elevenlabs_voice_api.py delete-voice --voice-id ID
    elevenlabs_voice_api.py generate-sound --text TEXT [--output PATH]
    elevenlabs_voice_api.py get-history
"""

import sys
import os
import json
import argparse
import requests
from typing import Dict, Any


BASE_URL = "https://api.elevenlabs.io/v1"


def get_token() -> str:
    """Load ElevenLabs API Token from environment."""
    token = os.environ.get("ELEVENLABS_API_KEY")
    if not token:
        print("Error: ELEVENLABS_API_KEY environment variable is not set.", file=sys.stderr)
        print("Set it with: export ELEVENLABS_API_KEY='your-token'", file=sys.stderr)
        sys.exit(1)
    return token


def get_headers() -> Dict[str, str]:
    """Get request headers with authorization."""
    return {
        "xi-api-key": get_token(),
        "Content-Type": "application/json",
    }


def handle_response(resp: requests.Response) -> Dict[str, Any]:
    """Handle ElevenLabs API response."""
    try:
        data = resp.json()
    except ValueError:
        print(f"Error: Non-JSON response: {resp.text}", file=sys.stderr)
        sys.exit(1)

    if resp.status_code == 429:
        retry_after = resp.headers.get("Retry-After", "30")
        print(f"Rate limited. Retry after {retry_after} seconds.", file=sys.stderr)
        sys.exit(1)

    if resp.status_code >= 400:
        error = data.get("detail", {}).get("message", "unknown_error")
        print(f"ElevenLabs API error: {error}", file=sys.stderr)
        sys.exit(1)

    return data


def tts(args) -> None:
    """Text-to-speech."""
    body = {
        "text": args.text,
        "model_id": "eleven_monolingual_v1",
    }
    resp = requests.post(f"{BASE_URL}/text-to-speech/{args.voice_id}", headers=get_headers(), json=body)
    if resp.status_code == 200:
        output_path = args.output or "speech.mp3"
        with open(output_path, "wb") as f:
            f.write(resp.content)
        print(json.dumps({"ok": True, "action": "tts", "output": output_path}))
    else:
        data = handle_response(resp)
        print(json.dumps(data, indent=2))


def list_voices(args) -> None:
    """List all voices."""
    resp = requests.get(f"{BASE_URL}/voices", headers=get_headers())
    data = handle_response(resp)
    print(json.dumps(data, indent=2))


def get_voice(args) -> None:
    """Get voice details."""
    resp = requests.get(f"{BASE_URL}/voices/{args.voice_id}", headers=get_headers())
    data = handle_response(resp)
    print(json.dumps(data, indent=2))


def add_voice(args) -> None:
    """Add/clone a voice."""
    headers = {"xi-api-key": get_token()}
    files = {"files": open(args.file, "rb")}
    data = {"name": args.name}
    resp = requests.post(f"{BASE_URL}/voices/add", headers=headers, files=files, data=data)
    data = handle_response(resp)
    print(json.dumps(data, indent=2))


def delete_voice(args) -> None:
    """Delete a voice."""
    resp = requests.delete(f"{BASE_URL}/voices/{args.voice_id}", headers=get_headers())
    data = handle_response(resp)
    print(json.dumps(data, indent=2))


def generate_sound(args) -> None:
    """Generate sound effect."""
    body = {"text": args.text}
    resp = requests.post(f"{BASE_URL}/sound-generation", headers=get_headers(), json=body)
    if resp.status_code == 200:
        output_path = args.output or "sound.mp3"
        with open(output_path, "wb") as f:
            f.write(resp.content)
        print(json.dumps({"ok": True, "action": "generate_sound", "output": output_path}))
    else:
        data = handle_response(resp)
        print(json.dumps(data, indent=2))


def get_history(args) -> None:
    """Get audio generation history."""
    resp = requests.get(f"{BASE_URL}/history", headers=get_headers())
    data = handle_response(resp)
    print(json.dumps(data, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(description="ElevenLabs API Helper")
    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # tts
    p = subparsers.add_parser("tts", help="Text-to-speech")
    p.add_argument("--text", required=True, help="Text to speak")
    p.add_argument("--voice-id", required=True, help="Voice ID")
    p.add_argument("--output", help="Output path")
    p.set_defaults(func=tts)

    # list-voices
    p = subparsers.add_parser("list-voices", help="List all voices")
    p.set_defaults(func=list_voices)

    # get-voice
    p = subparsers.add_parser("get-voice", help="Get voice details")
    p.add_argument("--voice-id", required=True, help="Voice ID")
    p.set_defaults(func=get_voice)

    # add-voice
    p = subparsers.add_parser("add-voice", help="Add/clone a voice")
    p.add_argument("--name", required=True, help="Voice name")
    p.add_argument("--file", required=True, help="Audio file path")
    p.set_defaults(func=add_voice)

    # delete-voice
    p = subparsers.add_parser("delete-voice", help="Delete a voice")
    p.add_argument("--voice-id", required=True, help="Voice ID")
    p.set_defaults(func=delete_voice)

    # generate-sound
    p = subparsers.add_parser("generate-sound", help="Generate sound effect")
    p.add_argument("--text", required=True, help="Sound description")
    p.add_argument("--output", help="Output path")
    p.set_defaults(func=generate_sound)

    # get-history
    p = subparsers.add_parser("get-history", help="Get audio generation history")
    p.set_defaults(func=get_history)

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    args.func(args)


if __name__ == "__main__":
    main()
