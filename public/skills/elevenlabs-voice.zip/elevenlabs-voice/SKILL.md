---
name: elevenlabs-voice
description: Generates high-quality AI voiceover audio using the ElevenLabs API. Use this skill to convert text to speech, list available voices, clone a custom voice, or retrieve audio generation history. Works with any voice ID and any pipeline. Triggers on phrases like "generate audio", "create voiceover", "text to speech", "generate narration", "clone my voice", "list voices", or any request to produce an MP3 from text using ElevenLabs.
version: 2.1.0
metadata: {"openclaw":{"requires":{"env":["ELEVENLABS_API_KEY"],"bins":["curl","python3"]},"primaryEnv":"ELEVENLABS_API_KEY","emoji":"🎙️"}}
---

# ElevenLabs Voice

Generate high-quality AI voiceover audio from text using the ElevenLabs API. This skill is voice-agnostic — it works with any voice ID, any model, and any pipeline.

---

## Required credential

| Variable | Description | Where to get it |
|---|---|---|
| `ELEVENLABS_API_KEY` | Your ElevenLabs API key | [elevenlabs.io/app/settings/api-key](https://elevenlabs.io/app/settings/api-key) |

Store it in your environment — never hardcode it in scripts.

```bash
export ELEVENLABS_API_KEY=your_key_here
```

---

## Voice configuration

This skill does not assume a default voice. You must supply a voice ID with every TTS request.

**To find your voice ID:**
```bash
python scripts/elevenlabs_voice_api.py list-voices
```

Or via curl:
```bash
curl -X GET https://api.elevenlabs.io/v1/voices \
  -H "xi-api-key: $ELEVENLABS_API_KEY"
```

The response lists all voices in your library with their `voice_id` values. Copy the one you want and pass it to every TTS call.

**Recommended settings for narration:**
```json
{
  "stability": 0.5,
  "similarity_boost": 0.75
}
```
Adjust stability up (toward 1.0) for more consistent delivery. Adjust down for more expressive variation. Test before committing to a full production run.

---

## Core operations

---

### 1. Text-to-speech (TTS)

**Endpoint:** `POST https://api.elevenlabs.io/v1/text-to-speech/{voice_id}`

```bash
curl -X POST "https://api.elevenlabs.io/v1/text-to-speech/YOUR_VOICE_ID" \
  -H "xi-api-key: $ELEVENLABS_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "text": "Your narration text here.",
    "model_id": "eleven_multilingual_v2",
    "voice_settings": {
      "stability": 0.5,
      "similarity_boost": 0.75
    }
  }' \
  --output output.mp3
```

Replace `YOUR_VOICE_ID` with your actual voice ID. The response body is the raw MP3 binary — `--output` saves it directly.

**Via helper script:**
```bash
python scripts/elevenlabs_voice_api.py tts \
  --text "Your narration text here." \
  --voice-id YOUR_VOICE_ID \
  --output output.mp3
```

---

### 2. List voices

Returns all voices in your library, including cloned voices and ElevenLabs presets.

```bash
curl -X GET https://api.elevenlabs.io/v1/voices \
  -H "xi-api-key: $ELEVENLABS_API_KEY"
```

```bash
python scripts/elevenlabs_voice_api.py list-voices
```

Each voice in the response contains:
- `voice_id` — use this in TTS calls
- `name` — human-readable label
- `category` — `premade` or `cloned`

---

### 3. Get a specific voice

```bash
curl -X GET "https://api.elevenlabs.io/v1/voices/YOUR_VOICE_ID" \
  -H "xi-api-key: $ELEVENLABS_API_KEY"
```

---

### 4. Add a custom voice (voice cloning)

Provide a name and one or more audio sample files (WAV or MP3, minimum 1 minute of clean audio recommended).

```bash
curl -X POST https://api.elevenlabs.io/v1/voices/add \
  -H "xi-api-key: $ELEVENLABS_API_KEY" \
  -F "name=My Custom Voice" \
  -F "files=@/path/to/sample.wav"
```

```bash
python scripts/elevenlabs_voice_api.py add-voice \
  --name "My Custom Voice" \
  --file /path/to/sample.wav
```

The response returns the new `voice_id`. Save it — you'll need it for all future TTS calls with this voice.

---

### 5. Delete a voice

```bash
curl -X DELETE "https://api.elevenlabs.io/v1/voices/YOUR_VOICE_ID" \
  -H "xi-api-key: $ELEVENLABS_API_KEY"
```

```bash
python scripts/elevenlabs_voice_api.py delete-voice --voice-id YOUR_VOICE_ID
```

---

### 6. Check account usage

```bash
curl -X GET https://api.elevenlabs.io/v1/user \
  -H "xi-api-key: $ELEVENLABS_API_KEY"
```

Returns your subscription tier and remaining character quota. Check this before large production runs.

---

### 7. Retrieve generation history

```bash
curl -X GET https://api.elevenlabs.io/v1/history \
  -H "xi-api-key: $ELEVENLABS_API_KEY"
```

```bash
python scripts/elevenlabs_voice_api.py get-history
```

---

## Output files

- All TTS output is MP3 format
- Name output files clearly: `[segment-id].mp3` (e.g. `phase1-01-intro.mp3`)
- After generation, verify the file exists and is non-zero size before passing to the next pipeline stage
- MP3s must be uploaded to a public hosting service (e.g. Cloudinary) before being used in video rendering — local file paths will not work with external render APIs

---

## Rate limits

| Tier | Requests/min |
|---|---|
| Free | 30 |
| Creator | 60 |
| Pro | 120 |

For batch production runs (multiple segments in sequence), add a 2-second delay between requests to avoid hitting rate limits. If you receive a `429` error, wait 30 seconds and retry.

---

## Error handling

| HTTP Status | Error | Cause | Fix |
|---|---|---|---|
| 401 | `invalid_api_key` | Wrong or missing API key | Verify `ELEVENLABS_API_KEY` is set and correct |
| 404 | `voice_not_found` | Voice ID does not exist | Run `list-voices` to confirm the correct ID |
| 400 | `not_enough_characters` | Character quota exceeded | Check usage via `/v1/user`, upgrade plan if needed |
| 400 | `file_too_large` | Audio sample too large for cloning | Compress or trim the audio file |
| 422 | `validation_error` | Malformed request body | Check JSON syntax and required fields |
| 429 | `rate_limit_exceeded` | Too many requests | Wait 30 seconds, retry with backoff |
| 500 | `server_error` | ElevenLabs server issue | Wait and retry — check status.elevenlabs.io |

Always verify the output MP3 file size after generation. A 0-byte file means the API returned an error body instead of audio — check the response for the error message.

---

## Guardrails

- Never expose `ELEVENLABS_API_KEY` in logs, scripts, or public repositories
- Always validate that the output file is non-zero before passing it downstream
- Do not clone voices without authorization from the voice owner
- Respect ElevenLabs content policy — do not generate deceptive, abusive, or illegal content
- For long texts (>2,500 characters), split into segments and generate separately — large payloads increase failure risk

---

## Helper script reference

Full command list for `scripts/elevenlabs_voice_api.py`:

| Command | Description |
|---|---|
| `tts --text TEXT --voice-id ID [--output PATH]` | Generate speech from text |
| `list-voices` | List all voices in your library |
| `get-voice --voice-id ID` | Get details for a specific voice |
| `add-voice --name NAME --file PATH` | Clone a new voice from an audio file |
| `delete-voice --voice-id ID` | Delete a voice from your library |
| `generate-sound --text TEXT [--output PATH]` | Generate a sound effect from a description |
| `get-history` | Retrieve your generation history |

---

## What this skill does NOT do

- Does not upload audio files to any hosting service — pass the MP3 to cloudinary after generation
- Does not name or organize output files — caller is responsible for naming conventions
- Does not generate slide content or video — that is slide-renderer and video-assembler's job
- Does not select a voice for you — you must supply a voice ID; use `list-voices` to find yours
- Does not split long texts automatically — texts over 2,500 characters should be split manually before calling TTS
- Does not retry failed generations automatically — verify output file size and retry manually if 0 bytes

- `references/api-reference.md` — full ElevenLabs API endpoint reference
- `scripts/elevenlabs_voice_api.py` — helper script for all common operations
