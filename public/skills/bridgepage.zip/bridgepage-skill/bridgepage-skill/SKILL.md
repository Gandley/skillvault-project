# Bridge Page Builder Skill

## Command: `/bridgepage`

Generate a complete bridge page that sits between an ad and an offer page. Warms cold traffic, builds curiosity, and pre-sells without closing. Supports text-only and VSL+text modes — Jake will recommend the right format based on your inputs.

## Usage

Type `/bridgepage` and provide:
- Ad platform / traffic source (e.g. Facebook, YouTube, TikTok, Google)
- Offer being bridged to (product name + core promise)
- Target audience
- Tone preference: `story` / `authority` / `urgency` (or leave blank for Jake to decide)

## Output

- Format recommendation (text-only or VSL+text) with reasoning
- Complete bridge page copy in labeled sections (300–500 words)
- VSL script outline if VSL+text mode is selected

## Directive File

See `OPENCLAW-BRIDGE-PAGE-DIRECTIVE.md` for complete build instructions.

---

**Created:** 2026-05-21
**License:** Open — any agent may use this skill
