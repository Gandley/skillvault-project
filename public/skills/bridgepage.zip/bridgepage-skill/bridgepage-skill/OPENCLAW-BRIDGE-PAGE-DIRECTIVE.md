# OPENCLAW BRIDGE PAGE DIRECTIVE

**Purpose:** Generate a bridge page that connects an ad to an offer page. The bridge page has one job: warm the visitor up and get the click. It does not close. It does not oversell. It creates curiosity, builds a moment of trust, and hands the reader off to the sales or landing page ready to buy.

**Core Principle:** A bridge page that tries to do the sales page's job will kill conversions on both pages. Stay in your lane. Curiosity and warmth. Nothing more.

---

## STEP 01 — FORMAT RECOMMENDATION

Before writing a single line of copy, Jake must recommend a format and explain why.

### Decision Framework

Evaluate the inputs against these criteria and output a recommendation with 2–3 sentence reasoning:

**Recommend TEXT-ONLY when:**
- Traffic source is Google Search or native ads (reader-intent, text-comfortable audience)
- Offer is information-based and the mechanism is easy to explain in writing
- Niche has a skeptical or professional audience (finance, B2B, health professionals)
- Tone selected is `authority`
- The offer page already has a VSL — avoid video fatigue back to back

**Recommend VSL+TEXT when:**
- Traffic source is Facebook, Instagram, TikTok, or YouTube (video-native audiences)
- Offer involves a personal transformation or emotional journey (fitness, relationships, mindset)
- Tone selected is `story` — stories convert better on video
- The product has a face or personality behind it (personal brand, coach, creator)
- Cold traffic from scroll-based platforms where video stops the thumb better than text

**When tone is left blank:** Jake selects the tone based on the platform and niche. State the chosen tone in the recommendation and why.

**Output format for recommendation:**
```
## FORMAT RECOMMENDATION
Mode: [TEXT-ONLY or VSL+TEXT]
Tone: [story / authority / urgency]
Reason: [2–3 sentences explaining the decision based on the inputs]
```

---

## STEP 02 — BUILD THE BRIDGE PAGE

### CRITICAL RULE — THE BRIDGE PAGE MUST NOT OVERSELL

This is the most common bridge page failure. If the copy is making specific claims, stacking features, or trying to close the reader — it has crossed into sales page territory. Pull it back. The bridge page's only job is to make the reader curious enough and warm enough to click through.

**The test:** If you removed the CTA and the reader still felt sold to — rewrite it.

---

### TEXT-ONLY MODE

Build the following sections in order. Total word count: 300–500 words maximum.

---

**SECTION 01 — PATTERN INTERRUPT HEADLINE**

```
[Bold, short headline — 4–8 words]
[Optional sub-headline — one clarifying line]
```

**Rules:**
- Must stop the reader cold — they just came from an ad, their guard is up
- Challenge a belief, name a frustration, or make a surprising claim
- Do not name the product yet
- Sub-headline adds curiosity, not explanation

**Examples by tone:**

*Story:* "She Was About To Quit. Then This Happened."
*Authority:* "Most People Get This Completely Wrong."
*Urgency:* "The Window On This Is Closing Fast."

---

**SECTION 02 — CURIOSITY HOOK**

```
[2–3 short paragraphs OR a tight bulleted list]
```

**Rules:**
- Open a loop — raise a question or tension the reader needs resolved
- Do not close the loop here — that happens on the offer page
- Reference the problem the audience already has
- Make them feel like they're about to discover something important
- No product name yet — keep it mechanism or outcome-focused

---

**SECTION 03 — STORY OR PROOF SNIPPET**

```
[1 short story (100–150 words) OR 1–2 specific result callouts]
```

**Rules:**
- Story mode: brief, relatable, specific — someone like the reader who found a better way
- Proof mode: a specific result with context — not vague ("lost weight") but real ("dropped 22 lbs in 6 weeks without cutting carbs")
- This section is the trust builder — it must feel real and grounded
- Do not over-explain — leave enough unsaid to drive curiosity

**Story structure (if used):**
```
[Who they were / the problem they had]
[The moment everything changed — hint at the mechanism]
[Where they are now — the outcome]
[Transition: "That's why I'm sharing this..."]
```

---

**SECTION 04 — IDENTITY BRIDGE**

```
[1 short paragraph — 2–4 sentences]
```

**Rules:**
- Explicitly tell the reader this is for people like them
- Name their identity, situation, or goal — make them feel seen
- This is the "you belong here" moment before the CTA
- Be specific — vague identity statements do nothing

**Examples:**
- "If you're a solopreneur who's tired of building things that don't convert, this was made for you."
- "This is for the person who's tried the courses, watched the videos, and still isn't seeing results."
- "If you're already running paid traffic and want to stop bleeding money on pages that don't warm — keep reading."

---

**SECTION 05 — SOFT CTA**

```
[CTA headline — create forward momentum]
[CTA button label]
[Micro reassurance line]
```

**Rules:**
- The CTA must feel like a natural next step, not a push
- Button label should be curiosity-driven, not transaction-driven
  - Bad: "Buy Now" / "Click Here"
  - Good: "Show Me How It Works" / "See The Full Story" / "Take Me There"
- Micro reassurance removes the last hesitation: "No purchase required" / "Free to watch" / "Takes 30 seconds"
- Do not repeat price, features, or offer details — that's the next page's job

---

### VSL+TEXT MODE

In VSL+text mode, the page has two components: a short VSL script and supporting text below the video. Build both.

---

**COMPONENT 01 — PRE-VIDEO HEADLINE (above the player)**

```
[Headline — 5–9 words]
[Sub-headline — one line directing them to watch]
```

**Rules:**
- Headline creates enough curiosity to hit play
- Sub-headline sets expectation: "Watch this short video before you do anything else."
- Do not reveal what the video is about — just make them need to know

---

**COMPONENT 02 — VSL SCRIPT OUTLINE**

Build a structured script outline (not full word-for-word script — that is the VSL skill's job). Provide:

```
[Hook — first 15 seconds: pattern interrupt or bold claim]
[Problem agitation — 30–45 seconds: name the pain]
[Story or proof moment — 45–90 seconds: the turning point]
[Mechanism tease — 15–30 seconds: hint at the solution without revealing it]
[Bridge CTA — final 15 seconds: direct them to click below]
```

Total estimated video length: 2–4 minutes maximum for a bridge page VSL.

**Rule:** Flag clearly that this is a script outline. If the user needs a full VSL script, direct them to use `/vsl` after this skill completes.

---

**COMPONENT 03 — SUPPORTING TEXT (below the video)**

```
[Identity bridge paragraph — who this is for]
[Soft CTA button]
[Micro reassurance line]
```

**Rules:**
- This text exists for visitors who skim or skip the video
- Keep it to 3–5 sentences maximum
- Same soft CTA rules as text-only mode apply

---

## TONE GUIDE

| Tone | Feel | Best Used When |
|---|---|---|
| `story` | Personal, warm, relatable | Emotional niches, personal brands, transformation offers |
| `authority` | Confident, credible, expert | B2B, finance, professional audiences, skeptical niches |
| `urgency` | Forward momentum, time/opportunity pressure | Launches, limited offers, competitive markets |

**Tone affects:** headline style, story vs. proof choice, CTA language, and sentence rhythm.

---

## LENGTH RULE

Bridge pages are 300–500 words of visible copy. This is a hard ceiling.

If the output is longer than 500 words — cut it. A bridge page that reads like a sales page is a broken bridge page. If there is more to say — it belongs on the offer page.

---

## OUTPUT FORMAT

```
## FORMAT RECOMMENDATION
---
[Mode and reasoning]
---

## [SECTION NAME]
---
[Copy]
---
```

Each section labeled and self-contained for deployment.

---

*License: Open — any agent may use this skill*
*Created: 2026-05-21*
