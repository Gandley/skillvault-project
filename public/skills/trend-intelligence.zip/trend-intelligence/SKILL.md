---
name: trend-intelligence
description: >
  On-demand trend and algorithm intelligence for Nova's content pipelines. Activate immediately
  when the user types /trends, /trend brief, /what's trending, /algorithm update, or asks anything
  like "what should I post about", "what's performing right now", "what's hot on Instagram/YouTube/LinkedIn",
  "what's the algorithm doing", or "give me content ideas based on trends". Also activate when the
  user mentions a trending topic and wants to know if Nova should jump on it. This skill monitors
  platform algorithm signals, trending topics, viral content patterns, and hashtag performance across
  Instagram, YouTube, and LinkedIn — specifically within the AI agent deployment, AI automation, and
  entrepreneur/make-money-online niches. Outputs a structured Trend Brief ready to feed directly into
  the Content Calendar skill or the Social Post Pipeline. Always run this skill before any content
  planning session — do not let Nova plan content without a current trend check.
---

# Trend & Algorithm Intelligence

On-demand trend monitoring and algorithm analysis for Nova. Produces a structured Trend Brief covering
Instagram, YouTube, and LinkedIn across two niches: AI Agent Deployment/Management and Entrepreneur/MMO.

## Primary command

`/trends` — Run a full trend brief across all platforms and both niches.

## Supporting commands

- `/trends instagram` — Instagram-only trend brief
- `/trends youtube` — YouTube-only trend brief
- `/trends linkedin` — LinkedIn-only trend brief
- `/trends [topic]` — Check if a specific topic is trending and whether Nova should jump on it
- `/algorithm update` — What has changed recently in platform algorithms (no topic search)
- `/trend check [topic]` — Quick yes/no on whether a topic is worth posting about right now

---

## Two-niche framework

Every trend brief covers both niches simultaneously. Never run a brief for one niche only unless
the user explicitly requests it.

**Niche A — AI Agent Deployment & Management**
Core topics: AI agents, agentic workflows, AI automation, OpenClaw, n8n, Make.com, Claude, GPT-4,
AI tools for business, AI workforce, operator frameworks, AI ROI, deploying agents, managing AI systems

**Niche B — Entrepreneur / Make Money Online**
Core topics: online business, digital products, passive income, solopreneurs, side hustles, creator economy,
productized services, business automation, scaling without hiring, AI for entrepreneurs, content monetization

When a topic bridges both niches (e.g. "AI tools that help you make money online"), flag it as a
**Cross-Niche Opportunity** — these are the highest-priority content opportunities and should be
surfaced prominently in the brief.

---

## Platform algorithm profiles

Use these as the baseline for what each platform currently rewards. Update recommendations based on
search findings — if algorithm behavior has shifted, the search results will reflect it.

### Instagram
**What the algorithm rewards:**
- Reels under 30 seconds with strong hook in first 2 seconds
- Original audio or trending audio (check what's spiking)
- High save rate and share rate (more weight than likes)
- Carousel posts for educational content (swipe-through = time on post)
- Consistent posting cadence (4–5x per week minimum for growth phase)
- Keyword-optimized captions — Instagram now indexes caption text for search

**Content format priority order:** Reels > Carousels > Single image > Stories (for distribution only)

**Hashtag guidance:** 3–5 highly relevant hashtags perform better than 20–30 broad ones.
Mix: 1 niche hashtag + 1 topic hashtag + 1 community hashtag.

### YouTube
**What the algorithm rewards:**
- Click-through rate (CTR) — thumbnail + title combination is everything
- Watch time percentage — YouTube Shorts need 80%+ retention to get pushed
- Shorts under 60 seconds with a hook in the first 3 seconds
- Strong title with a curiosity gap or clear value proposition
- Consistent upload schedule — algorithm favors predictable channels
- Chapters and timestamps for long-form (improves session time)

**Content format priority order:** Shorts (for discovery) > Long-form tutorials > Live streams

**Thumbnail rule:** Face + emotion + bold text outperforms graphic-only thumbnails in this niche.

### LinkedIn
**What the algorithm rewards:**
- Text posts with line breaks (no wall of text — use white space aggressively)
- Posts that generate comments within the first 60–90 minutes of posting
- Carousels (PDF documents) — highest engagement format for educational content
- Personal story + business lesson format outperforms pure information posts
- Native video (uploaded directly, not YouTube links)
- Posting Tuesday–Thursday, 7–9am or 5–6pm local time

**Content format priority order:** Carousels > Text posts > Native video > Articles

**LinkedIn-specific:** Engagement bait ("comment below") still works but use sparingly. The algorithm
docks reach if the post gets comments but no likes or shares — it needs balanced engagement signals.

---

## Trend brief workflow

When `/trends` is triggered, run these stages in order. Do not skip stages.

---

### STAGE 1 — Platform algorithm pulse (2–3 searches)

Search for recent algorithm changes and what is currently being rewarded on each platform.

**Search queries to run:**
```
Instagram algorithm changes [current month year]
YouTube Shorts algorithm [current month year]
LinkedIn algorithm update [current month year]
```

Extract: Any confirmed algorithm changes in the last 30–60 days. If none found, note "algorithm
stable — no confirmed changes" and proceed with baseline profile above.

---

### STAGE 2 — Niche A trend scan (3–4 searches)

Search for what is trending in the AI agent and automation space right now.

**Search queries to run:**
```
AI agents trending topics [current month year]
AI automation viral content creators [current month year]
AI tools for business trending [current month year]
OpenClaw OR n8n OR "AI agents" trending social media [current month year]
```

Extract per result:
- Topic or angle that is getting traction
- Which platform it's performing on
- Estimated recency (days ago, this week, this month)
- Content format that's working (video, post, thread, carousel)

---

### STAGE 3 — Niche B trend scan (3–4 searches)

Search for what is trending in the entrepreneur and MMO space right now.

**Search queries to run:**
```
make money online trending [current month year]
entrepreneur content trending Instagram YouTube LinkedIn [current month year]
solopreneur viral content [current month year]
digital products passive income trending [current month year]
```

Extract same fields as Stage 2.

---

### STAGE 4 — Hashtag and keyword intelligence (2 searches)

Search for current high-performing hashtags and keywords in both niches.

**Search queries to run:**
```
best hashtags AI automation business [current month year]
trending hashtags entrepreneur solopreneur [current month year]
```

Extract: Top 5–8 hashtags per niche with notes on reach (niche vs broad).

---

### STAGE 5 — Cross-niche opportunity detection

After completing Stages 2 and 3, scan both trend lists for overlapping themes.

A Cross-Niche Opportunity exists when:
- The same core message applies to both audiences
- A trend in one niche has not yet crossed to the other (first-mover advantage)
- An AI tool or automation topic directly addresses an entrepreneur pain point

Flag all Cross-Niche Opportunities with a ⚡ symbol in the brief.

---

### STAGE 6 — Compile and output the Trend Brief

After all searches are complete, compile everything into the structured Trend Brief format below.
Do not output partial briefs — present the full brief at once.

---

## Trend Brief output format

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 NOVA TREND BRIEF
[Date] | Platforms: Instagram · YouTube · LinkedIn
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## ALGORITHM STATUS

**Instagram:** [Stable / Updated — one sentence summary]
**YouTube:** [Stable / Updated — one sentence summary]
**LinkedIn:** [Stable / Updated — one sentence summary]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## NICHE A — AI AGENT DEPLOYMENT & AUTOMATION

### Trending Topics
[List 4–6 topics currently getting traction]
- **[Topic name]** — [Platform] — [Format performing best] — [Brief note on why it's working]
- ...

### Top Angles Right Now
[2–3 specific content angles Nova can use immediately]
1. [Angle] — [Why it works right now]
2. [Angle] — [Why it works right now]
3. [Angle] — [Why it works right now]

### Recommended Hashtags (Instagram)
[5–6 hashtags with a one-word context note]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## NICHE B — ENTREPRENEUR / MAKE MONEY ONLINE

### Trending Topics
[List 4–6 topics currently getting traction]
- **[Topic name]** — [Platform] — [Format performing best] — [Brief note]
- ...

### Top Angles Right Now
[2–3 specific content angles Nova can use immediately]
1. [Angle] — [Why it works right now]
2. [Angle] — [Why it works right now]
3. [Angle] — [Why it works right now]

### Recommended Hashtags (Instagram)
[5–6 hashtags with a one-word context note]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## ⚡ CROSS-NICHE OPPORTUNITIES

[List 1–3 topics that bridge both niches — these are the highest-priority content plays]
1. **[Topic]** — [Why it works for both audiences] — [Recommended format + platform]
2. ...

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## PLATFORM FORMAT RECOMMENDATIONS THIS WEEK

**Instagram:** [Specific format recommendation based on current algorithm + trends]
**YouTube:** [Specific format recommendation]
**LinkedIn:** [Specific format recommendation]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## NOVA'S TOP 3 CONTENT PLAYS RIGHT NOW

Priority content Nova should create immediately based on this brief:

1. 🥇 **[Content piece title or concept]**
   Platform: [platform] | Format: [format] | Niche: [A / B / Both]
   Why now: [one sentence urgency]

2. 🥈 **[Content piece title or concept]**
   Platform: [platform] | Format: [format] | Niche: [A / B / Both]
   Why now: [one sentence urgency]

3. 🥉 **[Content piece title or concept]**
   Platform: [platform] | Format: [format] | Niche: [A / B / Both]
   Why now: [one sentence urgency]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Next step: Run /content calendar to build this week's posts around these plays,
or run /social post pipeline to start creating content now.
```

📲 *Telegram push — send when brief is complete:*
```
📊 Nova Trend Brief Ready

Top play: [#1 content play title]
Platform: [platform] | Format: [format]
⚡ Cross-niche opportunities: [count]

Open Nova to build your calendar → /content calendar
```

---

## Quick commands — single topic check

### `/trend check [topic]`

User wants to know if a specific topic is worth jumping on right now.
Run 2 searches on the topic, then respond in this format:

```
⚡ TREND CHECK — [Topic]

Status: 🟢 JUMP ON IT / 🟡 FADING — ACT FAST / 🔴 SKIP IT

Why: [2–3 sentences on current momentum, which platforms, how long it's been trending]
Best angle: [One specific content angle if status is green or yellow]
Best format: [Recommended format for the best-fit platform]
Expires: [Estimate — "This window is 24–48 hours" / "This has legs for 1–2 weeks" / etc.]
```

📲 *Telegram push — send immediately when status is 🟢 JUMP ON IT only:*
```
⚡ Trend Alert — Jump On This Now

Topic: [Topic]
Platform: [best platform] | Format: [format]
Window: [expiry estimate]

Open Nova → /trend check [topic] for full details
```

Do not send a Telegram push for 🟡 or 🔴 status — only green warrants an interrupt.

---

## Trend jump decision rules

When Nova identifies a trend, apply these rules before recommending it:

**Jump on it when:**
- The trend is under 72 hours old in the niche (first-mover advantage still available)
- It maps directly to one of the two core niches without forcing a connection
- There's a clear content angle that doesn't require misrepresenting the brand

**Move fast but don't force it when:**
- The trend is 3–7 days old (still relevant but competition is growing)
- The connection to the niche requires one logical bridge — acceptable if the bridge is clear

**Skip it when:**
- The trend is over 2 weeks old in the niche (late = noise)
- The connection to AI automation or entrepreneurship is a stretch
- The trend involves controversy, politics, or anything that could damage brand positioning
- It's a sound/audio trend on Instagram and the audio isn't available or doesn't fit

---

## Output rules

- Always complete all 6 stages before presenting the brief. No partial outputs.
- Never present the brief mid-search — compile first, present once.
- If search results are thin on a topic, note "Limited signal — monitor this" rather than fabricating trend data.
- The Top 3 Content Plays must be actionable immediately — not "consider posting about X" but "here is the specific piece to create."
- Cross-Niche Opportunities are the crown jewel of every brief. Spend extra attention identifying them.

## What this skill does NOT do

- Does not create content — hand off to Social Post Pipeline or Content Calendar for that
- Does not schedule posts — that is PostStream's job
- Does not track historical performance — that is the Analytics Feedback Loop skill's job
- Does not fabricate trend data — if signal is weak, it says so
