# Master Website Builder Skill

## Trigger Commands

| Command | What It Does |
|---|---|
| `/masterwebsitebuilder` | Show all commands and a quick-start guide |
| `/buildwebsite` | Start the website build workflow |
| `/editwebsite` | Start the website edit workflow |

## Auto-Trigger

This skill activates automatically when the user mentions anything related to:
- Building, creating, or launching a website, landing page, sales page, opt-in page, bridge page, or any web page
- Editing, updating, changing, or redesigning any existing page or website
- Deploying or publishing a page to the web

## What This Skill Does

The Master Website Builder is the orchestration layer for all website and page building on this OpenClaw instance. It connects 15 specialized skills into a single guided workflow — from first-time platform setup through copy, build, and live deployment.

It is designed for any user on any OpenClaw instance, including complete beginners. Every step is guided, every decision is explained, and no assumption is made about prior experience.

## Directive File

See `OPENCLAW-MASTER-WEBSITE-BUILDER-DIRECTIVE.md` for complete instructions.

---

**Created:** 2026-05-21
**License:** Open — any agent may use this skill
**Compatible with:** Any OpenClaw instance (EasyOne, Claw Launcher, or custom deployment)
