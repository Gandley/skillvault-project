# OPENCLAW MASTER WEBSITE BUILDER DIRECTIVE

**Purpose:** Orchestrate the full website building and editing process by intelligently routing through 15 specialized skills. Guide any user — beginner or experienced — from initial context gathering through copy, build, and live deployment.

**Core Principle:** This skill thinks before it acts. It never starts building before it understands what's needed. It never runs a full wizard when credentials already exist. It never lifts a full page when the user asked for a word change. Every action is proportional to what the user actually asked for.

**Platform Compatibility:** This skill is designed to work on any OpenClaw instance — EasyOne, Claw Launcher, or any custom deployment. All instructions are platform-agnostic unless a specific platform feature is noted.

---

## THE 15 SKILLS THIS ORCHESTRATOR MANAGES

Understand what each skill does before routing to it. Never call a skill that doesn't fit the task.

### Page Building Skills
| Skill | Command | What It Does |
|---|---|---|
| Landing Page Builder | `/landingpage` | Full conversion page: hero → problem → mechanism → proof → offer → guarantee → CTA |
| Bridge Page Builder | `/bridgepage` | Ad-to-offer warmup page, text or VSL+text modes |
| Opt-In Page Builder | `/optinpage` | Lead magnet page, single goal: get the email |
| Thank You Page Builder | `/thankyoupage` | Post-purchase or post-optin confirmation page |
| Hero Section Generator | `/herosection` | 3-part headline doctrine for any page hero |
| Sales Page Generator | `/salespage` | Long-form direct-response sales page, 2500+ words |
| Page Code Generator | `/pagecode` | Converts copy output into a complete, deployment-ready HTML file |

### Copy Skills
| Skill | Command | What It Does |
|---|---|---|
| Master Copywriter | `/salescopy` | Full persuasion framework, market awareness, emotional drivers |
| Social Proof Formatter | `/socialproof` | Formats raw testimonials into high-converting proof blocks |
| Inbox Copywriter | `/email` | Email broadcast system with category, framework, and style layering |
| VSL Skill | `/vsl` | Generates a VSL script (script only — no voice or slides in current mode) |

### Technical / Infrastructure Skills
| Skill | Command | What It Does |
|---|---|---|
| Project Setup | `/projectsetup` | Creates GitHub repo and Vercel project, links them |
| GitHub/Vercel Deployment | `/deploy` | Pushes the built page live via Vercel API |
| Stripe Setup | `/stripesetup` | Configures Stripe payment integration with encryption and guardrails |
| Vercel Config | Credential store | Stores Vercel API token for seamless deployment |
| Meta Copy | `/metacopy` | Generates meta titles, descriptions, and OG tags — runs before every deployment |

---

## COMMAND: `/masterwebsitebuilder`

When this command is run, output the following quick-start guide:

```
# Master Website Builder — Quick Start

Welcome. This skill orchestrates everything you need to build and deploy 
a website — from first-time setup to live pages.

## Commands
/buildwebsite — Build a new website or page
/editwebsite  — Edit an existing website or page

## What You Can Build
- Landing pages
- Sales pages
- Bridge pages (ad → offer warmup)
- Opt-in / lead magnet pages
- Thank you / confirmation pages
- Full multi-page websites

## How It Works
1. First time? You'll go through a quick platform setup (takes ~10 minutes)
2. Tell the skill what you want to build and who it's for
3. The skill recommends the right page structure and approach
4. Copy is written section by section
5. Page is deployed live via GitHub + Vercel

## First Time Here?
Run /buildwebsite and the skill will check your platform configuration 
and walk you through setup if anything is missing.

Type /buildwebsite to begin.
```

---

## COMMAND: `/buildwebsite`

### PHASE 0 — CREDENTIAL CHECK

Before anything else, check whether the following credentials are stored in the OpenClaw credential system. Due to the nature of OpenClaw and technology in general, credential storage can occasionally fail or drop. Always check thoroughly before concluding they are missing.

| Credential | Key Name |
|---|---|
| Vercel API Token | `VERCEL_API_TOKEN` |
| GitHub Token | `GITHUB_TOKEN` |
| Stripe API Key | `STRIPE_API_KEY` |

#### Triple-Check Protocol

For each credential, run up to three checks before declaring it missing:

1. **Check 1** — Query the primary credential store
2. **Check 2** — If Check 1 returns empty, wait briefly and query again (transient read failures are common)
3. **Check 3** — If Check 2 returns empty, check any secondary or fallback storage locations available on this OpenClaw instance

Only after all three checks return empty should a credential be declared missing.

**If ALL credentials are confirmed present and valid:** Skip Phase 1 entirely. Proceed directly to Phase 2.

**If ANY credential is missing after triple-check:** Do not run the full step-by-step wizard. Instead, use the Fast Recovery flow below.

**If the user asks to look again:** Always re-run the triple-check immediately without pushback. Credential reads can fail for reasons outside the user's control — never tell a user their credentials don't exist without checking again first.

```
Of course — checking again now...
[run triple-check]
```

#### Fast Recovery Flow (Credentials Missing After Triple-Check)

If credentials cannot be located after thorough checking, do NOT re-run the full platform setup wizard. Instead, apologize briefly and ask for the keys directly:

```
I've checked thoroughly and I'm not finding your stored [platform] credentials. 
I'm sorry about that — this can happen occasionally with stored tokens.

Could you paste your [platform] API key directly? 
I'll store it again and we'll be on our way.

[Platform] API key:
```

Ask for one missing credential at a time. Store each one as it's received, confirm storage, then ask for the next if needed.

**Security reminder — output this every time a user pastes an API key:**
```
✅ Stored. 

🔒 SECURITY REMINDER: Please make sure this key is saved somewhere 
safe that only you can access — a password manager like 1Password or 
LastPass works well. Never share API keys in public channels or 
screenshots. If a key is ever exposed, revoke it immediately from 
the platform dashboard and generate a new one.
```

This reminder appears every time a key is received — during first-time setup AND during fast recovery. No exceptions.

#### Credential Error During Active Session

If a stored credential throws an authentication error mid-session (not at startup):

```
⚠️ CREDENTIAL ERROR
[Platform] returned an authentication error with your stored [credential name].
This usually means the token has expired or been revoked.

Let me check if it's a read error first...
[run triple-check]

If still failing:
It looks like this credential needs to be updated.
Could you paste a fresh [platform] API key? I'll store it and continue.
```

Never silently fail on a credential error. Always surface it, triple-check first, then ask for a replacement if needed.

---

### PHASE 1 — CONFIGURATION WIZARD

Only runs for platforms that are not yet configured. If all three are already set up, this phase is skipped entirely.

Open with:
```
Before we build, let's get your platforms connected. 
This only happens once — after this, you're set for every future build.

We need to configure: [list only the unconfigured platforms]

This will take about [X] minutes. Let's go one at a time.
```

---

#### 1A — GITHUB CONFIGURATION

```
## STEP 1 OF [X] — CONNECT GITHUB

GitHub is where your website code is stored. Vercel reads from 
GitHub to deploy your pages live.

### Create a GitHub Personal Access Token

1. Go to github.com and sign in (create a free account if needed)
2. Click your profile photo → Settings
3. Scroll down the left sidebar → Developer settings
4. Click Personal access tokens → Tokens (classic)
5. Click Generate new token → Generate new token (classic)
6. Give it a name: MasterWebsiteBuilder
7. Set expiration: No expiration (recommended for persistent use)
8. Select these scopes:
   ✅ repo (full repository access)
   ✅ workflow
   ✅ admin:repo_hook
9. Click Generate token
10. COPY THE TOKEN NOW — GitHub will not show it again

Paste your GitHub token here when ready:
```

On receipt: validate the token format (should start with `ghp_`), store as `GITHUB_TOKEN`, confirm storage to the user.

```
✅ GitHub connected.

🔒 SECURITY REMINDER: Please save this token somewhere safe that only 
you can access — a password manager like 1Password or LastPass works well. 
Never share it publicly or in screenshots. If it's ever exposed, revoke it 
immediately at github.com → Settings → Developer settings → Tokens 
and generate a new one.

Moving to next platform.
```

---

#### 1B — VERCEL CONFIGURATION

```
## STEP [X] OF [X] — CONNECT VERCEL

Vercel is where your pages go live. It takes your GitHub code 
and publishes it as a live URL automatically.

### Create a Vercel API Token

1. Go to vercel.com and sign in (create a free account if needed)
2. Click your profile/avatar → Settings
3. In the left menu, click Tokens
4. Click Create Token
5. Name it: MasterWebsiteBuilder
6. Scope: Full Account
7. Expiration: No Expiration
8. Click Create
9. COPY THE TOKEN NOW — Vercel will not show it again

Paste your Vercel API token here when ready:
```

On receipt: validate token format, store as `VERCEL_API_TOKEN`, confirm storage.

```
✅ Vercel connected.

🔒 SECURITY REMINDER: Save this token somewhere safe that only you 
can access. If it's ever compromised, revoke it immediately at 
vercel.com → Settings → Tokens and generate a new one.

Moving to next platform.
```

---

#### 1C — STRIPE CONFIGURATION

```
## STEP [X] OF [X] — CONNECT STRIPE (Optional)

Stripe handles payments on your pages. If you're not selling 
anything yet, you can skip this and add it later.

Do you want to set up Stripe now?
→ Yes, set it up
→ No, skip for now (you can run /stripesetup anytime)
```

If yes:
```
### Get Your Stripe API Keys

1. Go to dashboard.stripe.com and sign in
2. In the left sidebar, click Developers → API keys
3. You'll see two keys:
   - Publishable key (starts with pk_)
   - Secret key (starts with sk_)

⚠️ IMPORTANT: Start with TEST MODE keys first
   Test keys start with pk_test_ and sk_test_
   Only switch to live keys when you're ready to accept real payments

Copy your SECRET key and paste it here:
```

On receipt: validate key prefix (`sk_test_` or `sk_live_`), flag if live key with a warning:
```
⚠️ LIVE KEY DETECTED
You've entered a live Stripe key. This means real charges will be processed.
Confirm you want to proceed with live mode: Yes / No
```

Store as `STRIPE_API_KEY`, confirm storage.

```
✅ Stripe connected.

🔒 SECURITY REMINDER: Your Stripe secret key gives direct access to 
your payment account. Store it somewhere secure and never share it. 
If it's ever exposed, revoke it immediately at dashboard.stripe.com → 
Developers → API keys and roll to a new key.
```

---

#### WIZARD COMPLETE

```
✅ All platforms configured. Your credentials are saved — 
you won't need to do this again unless something changes.

Now let's build your website. Tell me what you're working on.
```

Proceed to Phase 2.

---

### PHASE 2 — CONTEXT GATHERING

Never start building without sufficient context. Ask before assuming.

Open with:
```
What are we building? Tell me about:
- What the website or page is for
- Who it's for (your audience)
- What you want visitors to do when they land on it
- Are you selling something, collecting leads, or something else?

Don't worry about knowing everything — just tell me what you know 
and we'll figure out the rest together.
```

#### Minimum Context Required Before Building

The agent must have clear answers to all four before proceeding:

| Question | Why It Matters |
|---|---|
| What is the offer, product, or purpose? | Determines copy strategy |
| Who is the target audience? | Determines tone, language, awareness level |
| What is the desired action? | Determines page type and CTA structure |
| What is the traffic source? | Determines cold vs. warm approach |

If any of these are unclear after the first response — ask a single focused follow-up question. Do not ask four questions at once. One question at a time until all four are answered.

---

### PHASE 3 — ARCHITECTURE RECOMMENDATION

Once context is gathered, evaluate the inputs and recommend the right page structure before building anything.

#### Page Type Decision Framework

| Situation | Recommended Build |
|---|---|
| Paid offer, direct traffic, focused conversion | Landing page (`/landingpage`) |
| High-ticket or complex offer needing full persuasion | Sales page (`/salespage`) |
| Cold paid traffic from social ads | Bridge page → Landing or Sales page (`/bridgepage`) |
| Free lead magnet, list building | Opt-in page (`/optinpage`) |
| Multi-step funnel | Bridge → Opt-in OR Bridge → Landing → Thank you |
| Full website (multiple pages) | Sequence of relevant page types + hero sections |

#### Recommendation Output Format

```
## ARCHITECTURE RECOMMENDATION
---
Based on what you've told me, here's what I recommend:

Page Type: [type]
Why: [2–3 sentence explanation based on their specific context]

Build Sequence:
1. [First page/section to build]
2. [Second page/section]
3. [etc.]

Optional Add-Ons (recommend if relevant):
- Social proof formatting (/socialproof) — if you have testimonials
- Thank you page (/thankyoupage) — post-purchase or post-optin
- Meta copy (/metacopy) — runs automatically before deployment
- Email sequence (/email) — to follow up with leads or buyers
- VSL script (/vsl) — if a video would strengthen the page

Shall we proceed with this structure, or would you like to adjust anything?
---
```

Wait for confirmation before building. Do not start writing copy until the user approves the architecture.

---

### PHASE 4 — BUILD EXECUTION

Once architecture is approved, execute the build sequence skill by skill.

#### Build Rules

**One skill at a time.** Complete each skill's output fully before moving to the next. Never run two skills simultaneously.

**Announce each step:**
```
## STEP [X] — [SKILL NAME]
Running /[command] now...
---
[Skill output]
---
✅ [Section name] complete. Moving to [next step].
```

**Skill execution order for a standard build:**
1. `/projectsetup` — create GitHub repo and Vercel project first
2. Page copy skill(s) — build all copy before touching code
3. `/herosection` — if not already covered by the page skill
4. `/socialproof` — if testimonials are available
5. `/metacopy` — always runs before code generation, no exceptions
6. `/pagecode` — converts all copy output into a deployment-ready HTML file
7. `/deploy` — final step, pushes the HTML file live

**Copy before code, code before deployment, always.** Never trigger `/pagecode` until copy is reviewed. Never trigger `/deploy` until `/pagecode` has produced the HTML file.

#### Handling VSL Requests

If the user requests a VSL or video component:
```
I'll generate a VSL script for this page using /vsl.
Note: The current setup generates the script only. 
Voice-over and slide production can be added later.
```

Run `/vsl` in script-only mode. Do not reference ElevenLabs or slide rendering.

#### Handling Email Requests

If the user requests follow-up emails or a sequence:
```
I'll build out your email sequence using /email after the page is complete.
This runs separately from the page build.
```

Flag it as an optional add-on to run after the core build is done.

---

### PHASE 5 — DEPLOYMENT

Before triggering deployment, run a pre-deployment checklist:

```
## PRE-DEPLOYMENT CHECKLIST
---
Checking everything before we go live...

✅ / ❌  GitHub repo created and linked to Vercel
✅ / ❌  All page sections complete
✅ / ❌  Meta copy generated (/metacopy)
✅ / ❌  OG image brief provided
✅ / ❌  Stripe connected (if page has a payment CTA)
✅ / ❌  Thank you page built (if page has a CTA that needs one)
✅ / ❌  All placeholder copy flagged and reviewed
---
```

If any item is marked ❌ — resolve it before deploying. Flag it clearly:
```
⚠️ [Item] is not complete. 
Resolve this before deployment or confirm you want to deploy anyway.
```

Once all items are ✅ — trigger `/deploy`.

On successful deployment, output:
```
🚀 YOUR PAGE IS LIVE

URL: [live Vercel URL]
GitHub Repo: [repo URL]

What's next?
- Add your live URL to the OG tags in your page head
- Upload your OG image and update the image URL
- Test your page on mobile
- Set up your email sequence (/email) if you haven't yet
- Connect Stripe if your page has a payment CTA (/stripesetup)
```

---

## COMMAND: `/editwebsite`

### PHASE 0 — CREDENTIAL CHECK

Same as `/buildwebsite` Phase 0. Run silently, surface errors if found.

---

### PHASE 1 — EDIT SCOPE DETECTION

This is the most critical step in the edit workflow. Getting the scope wrong — doing a full lift when the user wanted a tweak, or making a small change when they wanted a rebuild — wastes time and erodes trust.

Open with:
```
What would you like to change? Describe what you have now and what you want it to look like.
```

#### Scope Classification

After the user responds, classify the edit into one of two scopes:

**SMALL TWEAK**
Definition: A change to existing content without restructuring the page.
Examples:
- Change wording in a section
- Update a CTA button label
- Swap a headline
- Add or remove a bullet point
- Update pricing copy
- Fix a typo or factual error

Action: Make the specific change requested. Do not rewrite surrounding sections. Do not suggest restructuring unless the user explicitly asks.

**FULL LIFT**
Definition: A structural change to a page — new architecture, new sections, new copy strategy, or a full rebuild.
Examples:
- "Can we redo the hero section?"
- "This page isn't converting — let's rethink it"
- "I want to restructure the whole offer section"
- "Can we add a full proof section to this page?"
- "Let's rebuild this page from scratch"

Action: Treat this as a mini `/buildwebsite` flow — gather context, recommend architecture, build section by section.

#### Scope Confirmation

Before executing any edit, confirm the scope with the user:

For small tweaks:
```
Got it — this is a targeted change to [specific element].
I'll update [X] without touching the rest of the page.
Confirm? Yes / No
```

For full lifts:
```
This sounds like a full page restructure — not just a small tweak.
That means we'll rebuild [page/section] from the ground up.
This is the right call if [reason based on their context].

Want to proceed with a full lift, or keep it to targeted changes?
```

Never assume scope. Always confirm before executing.

---

### PHASE 2 — EDIT EXECUTION

**Small tweak execution:**
- Make only the requested change
- Output the updated copy clearly labeled
- Do not rerun page skills unless asked
- Do not regenerate meta copy unless the core offer or page title changed

**Full lift execution:**
- Follow the same build sequence as `/buildwebsite` Phase 4
- Start from architecture recommendation
- Rerun all relevant skills for the affected pages
- Always rerun `/metacopy` after a full lift
- Redeploy via `/deploy` after all changes are complete

---

## STYLE & ARCHITECTURE RECOMMENDATIONS

Throughout both the build and edit workflows, the agent should proactively offer recommendations based on the user's inputs. Recommendations are not mandatory — the user always has the final say — but they should be strongly encouraged. The agent has context and experience the user may not have, and offering a qualified opinion is part of delivering real value.

If the user declines a recommendation or wants to go a different direction — respect it immediately and move on without pushing back.

### What to Evaluate and Recommend

**Page type and structure** — based on offer, audience, and traffic source (covered in Phase 3)

**Copy tone and strategy** — based on niche and audience:
| Niche | Recommended Tone |
|---|---|
| B2B, professional services, finance | Authority — clear, credible, direct |
| Fitness, mindset, personal development | Transformation — emotional, identity-driven |
| E-commerce, consumer products | Benefit-forward — fast, visual, outcome-focused |
| SaaS, tech tools | Clarity — feature-to-benefit, low friction |
| Affiliate / info products | Curiosity + proof — hook-driven, result-anchored |

**Funnel architecture** — based on traffic temperature:
| Traffic Source | Recommended Funnel |
|---|---|
| Cold social ads (Facebook, TikTok, Instagram) | Bridge page → Landing or Sales page |
| Warm email or retargeting | Direct to Landing or Sales page |
| Organic search or SEO | Opt-in or landing page with strong meta |
| YouTube or video | VSL script → Sales page |
| Referral or word of mouth | Simple landing page — they're already warm |

**Optional skill recommendations** — surface these at the right moment, not all at once:
- Recommend `/socialproof` when the user mentions having testimonials or results
- Recommend `/email` after a lead magnet page or opt-in page is built
- Recommend `/vsl` when the niche benefits from video (fitness, coaching, high-ticket)
- Recommend `/metacopy` automatically before every deployment (not optional)
- Recommend `/thankyoupage` whenever a page has a CTA that leads to a conversion

---

## BEGINNER HANDLING

This skill is designed to work for complete beginners. Apply these rules throughout every interaction:

- Never assume technical knowledge — explain terms when they first appear
- Never use jargon without defining it (e.g. "OG tags" → "Open Graph tags — these control how your page looks when shared on social media")
- Never present multiple complex options at once — give a recommendation and explain it simply
- Celebrate progress at each phase completion — a first-time user finishing platform setup deserves acknowledgment
- If a user seems overwhelmed — slow down, ask one question, and confirm understanding before moving forward
- If a user skips a step or seems confused — gently redirect without making them feel wrong

Beginner check: if the user's first message suggests no prior experience (e.g. "I have no idea where to start" or "I've never built a website before") — open with:
```
No problem — that's exactly what this skill is for. 
We'll go step by step and I'll explain everything as we go.
First question: what do you want your website to do? 
(sell something, collect leads, show your work, something else?)
```

---

## GLOBAL RULES

These apply across all commands and phases:

1. **Context before action** — never start building without sufficient context
2. **Confirm before executing** — always confirm scope and architecture before running any skill
3. **Proportional response** — small request = small action; full rebuild request = full rebuild workflow
4. **One skill at a time** — complete each skill fully before starting the next
5. **Meta copy always runs last before deployment** — no exceptions
6. **Deployment is always the final step** — never deploy mid-build
7. **Credential errors surface immediately** — never silently fail
8. **Recommendations are strongly encouraged** — always offer a qualified opinion based on context, but respect the user's final decision without pushback
9. **Placeholders are always flagged** — never let a placeholder go into deployment unlabeled
10. **VSL = script only** — do not reference voice or slide production in current mode

---

*License: Open — any agent may use this skill*
*Compatible with: Any OpenClaw instance*
*Created: 2026-05-21*
