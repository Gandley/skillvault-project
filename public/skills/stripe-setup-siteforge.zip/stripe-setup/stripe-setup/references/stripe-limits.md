# Stripe API Rate Limits

## Default Limits

### Live Mode
- **Read operations**: 100 requests per second
- **Write operations**: 100 requests per second
- **Burst allowance**: Up to 150 concurrent requests

### Test Mode
- **Read operations**: 25 requests per second
- **Write operations**: 25 requests per second
- **Burst allowance**: Up to 40 concurrent requests

## Rate Limit Response

When rate limited, Stripe returns:
```json
{
  "error": {
    "type": "rate_limit_error",
    "message": "Rate limit exceeded",
    "retry_after": 5
  }
}
```

## Handling Rate Limits

### Exponential Backoff
```python
delays = [1, 2, 4, 8]  # seconds
for attempt, delay in enumerate(delays):
    response = make_request()
    if response.status_code == 429:
        time.sleep(delay)
        continue
    break
```

### Best Practices
1. Cache responses when possible
2. Batch operations instead of individual calls
3. Use webhooks instead of polling
4. Implement request queuing for high volume

## Increasing Limits

Contact Stripe support to request limit increases:
- Provide use case and expected volume
- Demonstrate proper error handling
- Show implementation of best practices

## Monitoring

Track these metrics:
- Requests per second
- Error rate (especially 429s)
- Response times
- Concurrent connections
