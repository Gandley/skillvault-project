# Stripe Security Best Practices

## API Key Security

### Key Storage
- **Never** commit API keys to version control
- **Never** log API keys in plain text
- **Never** expose keys in client-side code
- **Always** use environment variables or encrypted storage

### Key Rotation
- Rotate keys every 90 days
- Immediately rotate if key is compromised
- Use separate keys for different environments

### Access Control
- Limit API key permissions to minimum required
- Use restricted keys when possible
- Monitor API key usage in Stripe Dashboard

## Encryption Standards

### AES-256-GCM
- Industry standard for data encryption
- Provides confidentiality and integrity
- Unique IV per encryption operation

### Key Derivation
- PBKDF2 with SHA-256
- 480,000 iterations minimum
- Unique salt per installation

## PCI Compliance

### Never Store
- Full credit card numbers
- CVV/CVC codes
- Magnetic stripe data
- PIN numbers

### Use Stripe Elements
- Stripe.js for card collection
- Stripe Checkout for hosted payments
- Never handle raw card data

## Monitoring

### Suspicious Activity
- Unexpected charge volumes
- Failed authentication attempts
- Unusual geographic patterns
- Rapid API key usage

### Alerts
- Set up Stripe webhook alerts
- Monitor dashboard for anomalies
- Enable two-factor authentication
