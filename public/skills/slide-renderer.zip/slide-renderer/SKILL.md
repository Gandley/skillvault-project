---
name: slide-renderer
description: Takes PPTX slide content specs from slide-script-architect and produces: a pixel-perfect PPTX file, PNG images of each slide, and Shotstack JSON payloads using image assets. Use this skill whenever the pipeline needs to turn slide content specs into rendered slide images ready for video assembly. Triggers on phrases like "render the slides", "build the PPTX", "generate slide images", or when the pipeline reaches Stage 2.5 after audio URLs are confirmed.
---

# Slide Renderer

Build PPTX files from content specs, convert to PNG images, and generate Shotstack JSON payloads using image assets instead of HTML.

## Why this approach

Shotstack's HTML renderer does not reliably support CSS layout. Using PNG image assets instead of HTML assets produces pixel-perfect slides with zero rendering failures.

## Dependencies

```bash
npm install -g pptxgenjs react-icons react react-dom sharp
pip install Pillow --break-system-packages
```

LibreOffice and pdftoppm are pre-installed in the environment.

---

## Step 1 — Build the PPTX

Use pptxgenjs to generate a `.pptx` file from the content spec. Match the AI Operator brand exactly.

### Brand constants (use these every time — no # prefix on hex)

```javascript
const BRAND = {
  bg:         "0a0f1e",
  accent:     "0099ff",
  cyan:       "00c8ff",
  cardBg:     "0d1b2e",
  cardBorder: "1a3a5c",
  deepBg:     "0a1628",
  footerBg:   "060c17",
  headerBar:  "0066cc",
  white:      "ffffff",
  muted:      "8899aa",
};

const FONT_HEADER = "Trebuchet MS";
const FONT_BODY   = "Calibri";
const LAYOUT      = "LAYOUT_WIDE"; // 13.3" × 7.5"
```

### AI Operator logo

Embed this URL as an image in every slide, bottom-right corner at 0.55" × 0.55", position x: 12.6, y: 6.8:
```
https://res.cloudinary.com/dv3uawzle/image/upload/ai-operator-blueprint/logo/ai-operator-logo.png
```

If logo URL is unavailable, skip gracefully — do not fail the build.

---

### TYPE A — Hero/Intro slide

```javascript
// Background
slide.background = { color: BRAND.bg };

// Left column
// Logo top-left: x:0.3, y:0.25, w:0.9, h:0.9
// "AI OPERATOR" label: x:1.35, y:0.3, bold, white, 11pt, charSpacing:4
// "Blueprint Series" label: x:1.35, y:0.62, muted color, 11pt

// Horizontal accent line below logo area
slide.addShape(pres.shapes.RECTANGLE, { x:0.3, y:1.35, w:4.5, h:0.04, fill:{color:BRAND.accent}, line:{color:BRAND.accent} });

// Phase badge
slide.addShape(pres.shapes.RECTANGLE, { x:0.3, y:1.6, w:1.1, h:0.32, fill:{color:BRAND.accent} });
slide.addText("PHASE X", { x:0.3, y:1.6, w:1.1, h:0.32, fontSize:10, bold:true, color:BRAND.white, align:"center", valign:"middle", margin:0 });

// Large title — LINE 1 white, LINE 2 cyan, bold, 80pt
slide.addText(TITLE_LINE1, { x:0.3, y:2.1, w:6.0, h:1.3, fontSize:80, bold:true, color:BRAND.white, fontFace:FONT_HEADER });
slide.addText(TITLE_LINE2, { x:0.3, y:3.3, w:6.0, h:1.3, fontSize:80, bold:true, color:BRAND.cyan, fontFace:FONT_HEADER });

// Subtitle
slide.addText(SUBTITLE, { x:0.3, y:4.85, w:5.8, h:0.8, fontSize:16, color:BRAND.muted, fontFace:FONT_BODY });

// Vertical divider
slide.addShape(pres.shapes.RECTANGLE, { x:6.85, y:0, w:0.03, h:5.8, fill:{color:BRAND.accent} });

// Right side decorative area (background tinted rectangle)
slide.addShape(pres.shapes.RECTANGLE, { x:6.88, y:0, w:6.42, h:5.8, fill:{color:"060d1a"}, line:{color:"060d1a"} });
// Add subtle grid lines and circle decorations here as shapes

// Stats box — bottom right
slide.addShape(pres.shapes.RECTANGLE, { x:6.88, y:5.0, w:6.42, h:2.25, fill:{color:BRAND.deepBg}, line:{color:BRAND.cardBorder} });
slide.addText(STATS_LABEL, { x:7.2, y:5.15, w:5.8, h:0.35, fontSize:11, bold:true, color:BRAND.accent, charSpacing:3, fontFace:FONT_HEADER });
// Each stat row: large bold white value left, muted label right
// Render 3 stat rows at y: 5.55, 5.95, 6.35

// Footer
slide.addShape(pres.shapes.RECTANGLE, { x:0, y:7.2, w:13.3, h:0.3, fill:{color:BRAND.footerBg} });
slide.addText(FOOTER_LEFT, { x:0.3, y:7.22, w:3, h:0.26, fontSize:11, color:BRAND.muted, fontFace:FONT_BODY });
slide.addText("© 2026 AI Operator", { x:10.0, y:7.22, w:3.0, h:0.26, fontSize:11, color:BRAND.muted, align:"right", fontFace:FONT_BODY });
```

---

### TYPE C — Module overview slide

```javascript
// Background
slide.background = { color: BRAND.bg };

// Header bar full width
slide.addShape(pres.shapes.RECTANGLE, { x:0, y:0, w:13.3, h:1.1, fill:{color:BRAND.accent} });
// Logo in header: x:0.2, y:0.1, w:0.85, h:0.85
// DAY label: x:1.2, y:0.1, bold white 11pt charSpacing:3
// Module title: x:1.8, y:0.1, bold white 28pt centered
// Clock icon + time: top-right

// 5 columns — evenly spaced, x positions: 0.35, 2.9, 5.45, 8.0, 10.55
// Each column width: 2.3", height: 5.8", y start: 1.3
// Column structure:
//   - Dark card background: fill cardBg, border accent top (0.04h), border all sides cardBorder
//   - Cyan filled circle: centered top, w:1.0, h:1.0, fill accent
//   - Number in circle: bold white 28pt
//   - Step name: bold white 16pt, centered, multiline
//   - Time badge: bottom, border accent, white text 12pt

// AI Operator logo: x:12.65, y:6.85, w:0.55, h:0.55
```

---

### TYPE D — Step detail slide

This is the most common slide. Build it exactly as shown in the reference PPTX.

```javascript
// Background
slide.background = { color: BRAND.bg };

// ── HEADER ──────────────────────────────────────────────────
// Header background strip
slide.addShape(pres.shapes.RECTANGLE, { x:0, y:0, w:13.3, h:0.95, fill:{color:"0d1525"}, line:{color:"0d1525"} });
// Blue accent line below header
slide.addShape(pres.shapes.RECTANGLE, { x:0, y:0.95, w:13.3, h:0.04, fill:{color:BRAND.accent}, line:{color:BRAND.accent} });

// DAY X · STEP X badge
slide.addShape(pres.shapes.RECTANGLE, { x:0.3, y:0.2, w:1.5, h:0.38, fill:{color:BRAND.headerBar} });
slide.addText(`${DAY_LABEL} · ${STEP_LABEL}`, { x:0.3, y:0.2, w:1.5, h:0.38, fontSize:10, bold:true, color:BRAND.white, align:"center", valign:"middle", margin:0, charSpacing:1, fontFace:FONT_HEADER });

// Title — centered — rich text array for cyan word
// Parse TITLE for word in [brackets] → render that word in cyan
slide.addText([
  { text: "The Decision ", options: { color: BRAND.white } },
  { text: "Lock",          options: { color: BRAND.cyan } },
  { text: " Rule",         options: { color: BRAND.white } },
], { x:2.0, y:0.12, w:9.0, h:0.72, fontSize:26, bold:true, align:"center", fontFace:FONT_HEADER });

// Time badge — top right
slide.addShape(pres.shapes.RECTANGLE, { x:11.5, y:0.22, w:1.5, h:0.38, fill:{color:"00000000"}, line:{color:BRAND.white, pt:1.5} });
slide.addText(TIME_ESTIMATE, { x:11.5, y:0.22, w:1.5, h:0.38, fontSize:10, bold:true, color:BRAND.white, align:"center", valign:"middle", margin:0, charSpacing:2, fontFace:FONT_HEADER });

// ── LEFT BODY (x: 0.3, width: 6.5") ─────────────────────────
// Italic intro line
slide.addText(INTRO_LINE, { x:0.3, y:1.1, w:6.5, h:0.45, fontSize:14, italic:true, color:BRAND.muted, fontFace:FONT_BODY });

// 4 content cards — stacked, y positions: 1.65, 2.7, 3.75, 4.8
// Each card: h:0.9, fill cardBg
// Left border accent: x same as card, w:0.07, h:0.9, fill accent
// Title: bold white 14pt, y+0.08
// Body: muted 12pt, y+0.38
const cardY = [1.65, 2.7, 3.75, 4.8];
CARDS.forEach((card, i) => {
  slide.addShape(pres.shapes.RECTANGLE, { x:0.3, y:cardY[i], w:6.5, h:0.9, fill:{color:BRAND.cardBg}, line:{color:BRAND.cardBorder, pt:1} });
  slide.addShape(pres.shapes.RECTANGLE, { x:0.3, y:cardY[i], w:0.07, h:0.9, fill:{color:BRAND.accent}, line:{color:BRAND.accent} });
  slide.addText(`› ${card.title}`, { x:0.5, y:cardY[i]+0.08, w:6.1, h:0.32, fontSize:14, bold:true, color:BRAND.white, fontFace:FONT_HEADER, margin:0 });
  slide.addText(card.body, { x:0.5, y:cardY[i]+0.44, w:6.1, h:0.38, fontSize:12, color:BRAND.muted, fontFace:FONT_BODY, margin:0 });
});

// ── RIGHT PANEL (x: 7.0, width: 6.0") ───────────────────────
// Panel background
slide.addShape(pres.shapes.RECTANGLE, { x:7.0, y:1.05, w:6.0, h:6.2, fill:{color:BRAND.cardBg}, line:{color:BRAND.cardBorder, pt:1.5} });
// Top cyan accent line on panel
slide.addShape(pres.shapes.RECTANGLE, { x:7.0, y:1.05, w:6.0, h:0.05, fill:{color:BRAND.accent}, line:{color:BRAND.accent} });

// "THE RULE" label
slide.addText(RIGHT_PANEL_LABEL, { x:7.25, y:1.25, w:5.5, h:0.3, fontSize:11, bold:true, color:BRAND.accent, charSpacing:3, fontFace:FONT_HEADER });

// Formula box
slide.addShape(pres.shapes.RECTANGLE, { x:7.25, y:1.65, w:5.5, h:0.75, fill:{color:BRAND.deepBg}, line:{color:BRAND.accent, pt:1.5} });
slide.addText(FORMULA, { x:7.25, y:1.65, w:5.5, h:0.75, fontSize:17, bold:true, color:BRAND.white, align:"center", valign:"middle", fontFace:FONT_HEADER });

// "WHY IT WORKS" label
slide.addText(SECONDARY_LABEL, { x:7.25, y:2.55, w:5.5, h:0.3, fontSize:11, bold:true, color:BRAND.accent, charSpacing:3, fontFace:FONT_HEADER });

// 4 bullet points — y positions: 2.95, 3.55, 4.15, 4.75
// Each: cyan › arrow + white text, separator line below
const bulletY = [2.95, 3.55, 4.15, 4.75];
BULLETS.forEach((bullet, i) => {
  slide.addText([
    { text: "›  ", options: { color: BRAND.cyan, bold: true } },
    { text: bullet, options: { color: BRAND.white } },
  ], { x:7.25, y:bulletY[i], w:5.5, h:0.5, fontSize:13, fontFace:FONT_BODY });
  if (i < 3) slide.addShape(pres.shapes.LINE, { x:7.25, y:bulletY[i]+0.52, w:5.5, h:0, line:{color:BRAND.cardBorder, pt:0.75} });
});

// Quote box
slide.addShape(pres.shapes.RECTANGLE, { x:7.25, y:5.45, w:5.5, h:0.65, fill:{color:BRAND.deepBg}, line:{color:BRAND.cardBorder, pt:1} });
slide.addText(QUOTE, { x:7.25, y:5.45, w:5.5, h:0.65, fontSize:13, italic:true, color:BRAND.muted, align:"center", valign:"middle", fontFace:FONT_BODY });

// ── FOOTER ───────────────────────────────────────────────────
slide.addShape(pres.shapes.RECTANGLE, { x:0, y:7.2, w:13.3, h:0.3, fill:{color:BRAND.footerBg} });
slide.addText(FOOTER_LEFT, { x:0.3, y:7.22, w:3, h:0.26, fontSize:11, color:BRAND.muted, fontFace:FONT_BODY });
slide.addText("© 2026 AI Operator", { x:10.0, y:7.22, w:3.0, h:0.26, fontSize:11, color:BRAND.muted, align:"right", fontFace:FONT_BODY });

// AI Operator logo
slide.addImage({ path: LOGO_URL, x:12.65, y:6.8, w:0.55, h:0.55 });
```

---

## Step 2 — Convert PPTX to PNGs

After writing the PPTX file, convert each slide to a PNG image. Run these commands:

```bash
# Convert PPTX to PDF
libreoffice --headless --convert-to pdf output.pptx

# Convert PDF pages to JPG images at 1920px wide equivalent
pdftoppm -jpeg -r 200 output.pdf slide

# List output files
ls -1 "$PWD"/slide-*.jpg
```

This produces one image per slide: `slide-01.jpg`, `slide-02.jpg`, etc.

**Quality check:** View each image before uploading. If any slide looks wrong, fix the pptxgenjs code and re-render. Do not upload broken slides.

---

## Step 3 — Upload PNGs to Cloudinary

For each slide image, upload to Cloudinary using the `cloudinary` skill:

```
folder: ai-operator-blueprint/phaseX/slides
public_id: [segment-id]-slide
resource_type: image
```

Example:
```
ai-operator-blueprint/phase1/slides/phase1-03-decision-lock-slide
```

Collect the `secure_url` for each slide. These are the image URLs for Shotstack.

---

## Step 4 — Generate Shotstack JSON

For each segment, generate a simple Shotstack JSON using the PNG image as an image asset. This is the ONLY Shotstack JSON format to use — never use HTML assets for slide content.

```json
{
  "timeline": {
    "background": "#0a0f1e",
    "soundtrack": {
      "src": "AUDIO_URL",
      "effect": "fadeIn"
    },
    "tracks": [
      {
        "clips": [{
          "asset": {
            "type": "image",
            "src": "SLIDE_IMAGE_URL"
          },
          "start": 0,
          "length": DURATION,
          "fit": "cover",
          "transition": { "in": "fade", "out": "fade" }
        }]
      }
    ]
  },
  "output": {
    "format": "mp4",
    "resolution": "hd",
    "size": { "width": 1920, "height": 1080 }
  }
}
```

Replace:
- `AUDIO_URL` — Cloudinary secure_url of the MP3
- `SLIDE_IMAGE_URL` — Cloudinary secure_url of the slide PNG
- `DURATION` — actual audio duration in seconds (number, not string)

---

## Output summary

After completing all 4 steps, return:

```
✅ Slides rendered for [module name]

Segments:
| Segment ID | Slide PNG URL | Shotstack JSON ready |
|---|---|---|
| phase1-03-decision-lock | https://res.cloudinary.com/.../decision-lock-slide.jpg | ✅ |

All Shotstack JSONs ready for video-assembler.
```

---

## Critical rules

- NEVER use HTML assets in Shotstack JSON — image assets only
- NEVER skip the visual QA step — view every slide image before uploading
- NEVER upload a slide that has layout errors, overlapping text, or missing elements
- DURATION must be a number not a string (`30` not `"30"`)
- No JSON comments in any Shotstack payload
- Re-render the PPTX and re-export if any slide fails QA — do not work around it

## What this skill does NOT do

- Does not generate narration scripts — that is slide-script-architect's job
- Does not generate audio — that is elevenlabs-voice's job
- Does not submit to Shotstack — that is video-assembler's job
- Does not stitch segments — that is video-stitcher's job
