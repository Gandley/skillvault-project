---
name: video-cue
description: >
  Telegram-based video pipeline: Search videos → Approve via Telegram → Clip with Vizard → Approve clips via Telegram → Publish to social via Blotato.
  No Control Board. No PostStream. Everything runs through Telegram.
  Activate when someone types /video cue, /search videos, /clip videos, or /vid to post.
---

# Video Cue v3.0.0

Full video content pipeline via Telegram + Vizard + Blotato. No external dashboards required.

```
[Any command — first use]
        ↓
Setup Wizard (runs ONCE only, never again):
  → Telegram bot token + chat ID
  → Vizard API key
  → Blotato API key + fetch connected accounts
  → Default topic + platform + clips per video + target platforms
  → Config saved to disk
        ↓
[/video cue]
        ↓
Stage 1: Search videos (yt-dlp) → send to Telegram → approve/reject
        ↓
Stage 2: Send approved videos to Vizard → poll for clips → send clips to Telegram → approve/reject
        ↓
Stage 3: Publish approved clips via Blotato → Telegram confirmation
```

---

## Trigger

`/video cue`

**Commands:**
- `/video cue` → Full pipeline
- `/search videos` → Stage 1 only (search + approve via Telegram)
- `/clip videos` → Stage 2 only (clip via Vizard + approve via Telegram)
- `/vid to post` → Stage 3 only (publish approved clips via Blotato)

---

## Installation Success Message

```
🎬 Video Cue v3.0.0 Installed!

Telegram-based video pipeline. No dashboards needed.

📺 SEARCH → Find videos on YouTube
✂️  CLIP   → Generate short clips via Vizard
✅ APPROVE → Review everything in Telegram
🚀 POST    → Publish clips to 9+ platforms via Blotato

Run /video cue to get started.
First run walks you through a one-time setup wizard.
```

---

## Setup Wizard (First Use Only)

**Trigger:** Runs automatically on ANY first command if `config.json` does not exist.
**Never runs again** once `setup_complete: true` is saved.

```powershell
$configPath = "$env:USERPROFILE\.openclaw\workspace\video_cue\config.json"
if (-not (Test-Path $configPath)) {
    # Run full setup wizard
}
```

### Wizard Step 1: Telegram

> "🎬 Welcome to Video Cue!
>
> One-time setup — takes about 2 minutes. Never asked again.
>
> **Step 1 of 4 — Telegram**
>
> I'll send you videos and clips here for approval.
>
> **Don't have a bot yet?**
> 1. Open Telegram → search @BotFather
> 2. Send /newbot → follow prompts → copy your token
>
> **Already have a bot?** Paste your token below."

```powershell
$envPath  = "$env:USERPROFILE\.openclaw\workspace\.env.personal"
$botToken = "{user_input}"
Add-Content -Path $envPath -Value "TELEGRAM_BOT_TOKEN=$botToken"

# Auto-fetch chat ID
$updates = Invoke-RestMethod -Uri "https://api.telegram.org/bot$botToken/getUpdates"
$chatId  = $updates.result[-1].message.chat.id

if (-not $chatId) {
    Write-Host "Please send any message to your bot in Telegram, then press Enter..."
    Read-Host
    $updates = Invoke-RestMethod -Uri "https://api.telegram.org/bot$botToken/getUpdates"
    $chatId  = $updates.result[-1].message.chat.id
}

Add-Content -Path $envPath -Value "TELEGRAM_CHAT_ID=$chatId"
```

> "✅ Telegram connected! (Chat ID: {chatId})"

**Note:** If `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID` already exist in `.env.personal` (from another skill), skip this step silently.

---

### Wizard Step 2: Vizard

> "**Step 2 of 4 — Vizard (Video Clipping)**
>
> Vizard automatically clips long videos into short, shareable clips.
>
> Get your API key at: https://vizard.ai → Settings → API
>
> Paste your Vizard API key:"

```powershell
$vizardKey = "{user_input}"
Add-Content -Path $envPath -Value "VIZARD_API_KEY=$vizardKey"
```

> "✅ Vizard connected!"

---

### Wizard Step 3: Blotato

> "**Step 3 of 4 — Blotato (Social Publishing)**
>
> Blotato publishes your clips to Instagram, TikTok, YouTube, X, LinkedIn, and more.
>
> Get your API key at: https://my.blotato.com/settings → API
>
> Paste your Blotato API key:"

```powershell
$blotatoKey = "{user_input}"
Add-Content -Path $envPath -Value "BLOTATO_API_KEY=$blotatoKey"

# Fetch and display connected accounts
$accounts = Invoke-RestMethod -Uri "https://backend.blotato.com/v2/users/me/accounts" `
    -Headers @{ "blotato-api-key" = $blotatoKey }
```

Display connected accounts:
> "Connected accounts:
> 1. Instagram - @{handle}
> 2. TikTok - @{handle}
> 3. YouTube - {name}
> 4. X/Twitter - @{handle}
> ...
>
> Which platforms do you want to publish clips to by default?
> (Enter numbers, e.g. 1,2,3)"

Save selected platform `accountId`s + platform names to config.

> "✅ Blotato connected! {n} platforms selected."

---

### Wizard Step 4: Defaults

> "**Step 4 of 4 — Your Defaults**"

Ask in sequence:

1. > "What topic should I search videos about by default?
   > (e.g. 'AI tools', 'fitness', 'marketing')"
   - Save as `default_topic`

2. > "How many videos to find per run? (recommended: 3–5)"
   - Save as `default_video_count`

3. > "How many clips to generate per video in Vizard? (recommended: 3)"
   - Save as `default_clips_per_video`

---

### Save Config

```powershell
$config = @{
    setup_complete        = $true
    default_topic         = "{topic}"
    default_video_count   = {count}
    default_clips_per_video = {clips}
    platforms             = @(
        @{ accountId = "{id}"; platform = "{name}"; handle = "{handle}" }
    )
    approved_videos       = @()
    approved_clips        = @()
    cron_ids              = @{}
} | ConvertTo-Json -Depth 5

New-Item -ItemType Directory -Force -Path "$env:USERPROFILE\.openclaw\workspace\video_cue" | Out-Null
$config | Set-Content $configPath
```

Send Telegram confirmation:
```powershell
Invoke-RestMethod -Uri "https://api.telegram.org/bot$botToken/sendMessage" -Method POST -Body @{
    chat_id    = $chatId
    text       = "✅ Video Cue is ready!`n`nI'll send you videos and clips here for approval.`n`nReply *approve* or *reject* to each one.`n`nStarting your first pipeline now..."
    parse_mode = "Markdown"
}
```

> "🎉 Setup complete! Starting pipeline..."

---

## Command: `/video cue`

Check setup → runs Stage 1 → Stage 2 → Stage 3 in sequence.

---

## Command: `/search videos`

**Purpose:** Stage 1 — Search YouTube, send videos to Telegram for approval

### Step 1: Check setup
```powershell
$config = Get-Content $configPath -ErrorAction SilentlyContinue | ConvertFrom-Json
if (-not $config -or -not $config.setup_complete) { # Run setup wizard }
```

### Step 2: Load config or prompt change
> "Current config:
> Topic: {default_topic}
> Videos per run: {default_video_count}
>
> 1. 🚀 Run with current config
> 2. ⚙️ Change for this run only
> 3. 🔧 Update defaults"

### Step 3: Check yt-dlp
```powershell
try {
    $v = & yt-dlp --version 2>$null
    if ($LASTEXITCODE -ne 0) { throw }
} catch {
    Write-Host "Installing yt-dlp..."
    pip install yt-dlp --break-system-packages 2>$null
    if ($LASTEXITCODE -ne 0) {
        Invoke-WebRequest -Uri "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe" -OutFile "$env:USERPROFILE\.openclaw\bin\yt-dlp.exe"
    }
    Write-Host "✅ yt-dlp installed"
}
```

### Step 4: Search YouTube
```bash
yt-dlp "ytsearch{count}:{topic}" --flat-playlist \
  --print "%(id)s|||%(title)s|||%(webpage_url)s|||%(channel)s|||%(duration_string)s|||%(view_count)s|||" \
  --no-warnings
```

Extract per video: `id`, `title`, `url`, `channel`

**Deduplicate:** check local DB at `~/.openclaw/workspace/video_cue/db/videos.json` — skip any `video_id` already seen.

### Step 5: Send videos to Telegram for approval

Send all found videos as a single numbered list message, then poll for replies:
```powershell
$botToken = (Get-Content $envPath | Select-String "TELEGRAM_BOT_TOKEN=").ToString().Split("=")[1]
$chatId   = (Get-Content $envPath | Select-String "TELEGRAM_CHAT_ID=").ToString().Split("=")[1]

# Build numbered list
$list = "📺 *Found {total} videos — reply with numbers to approve (e.g. 1,3) or 'all' or 'none'*`n`n"
$n = 1
foreach ($video in $foundVideos) {
    $list += "$n. *$($video.title)*`n   🎙 $($video.channel)`n   🔗 $($video.url)`n`n"
    $n++
}

Invoke-RestMethod -Uri "https://api.telegram.org/bot$botToken/sendMessage" -Method POST -Body @{
    chat_id    = $chatId
    text       = $list
    parse_mode = "Markdown"
}

# Poll for reply (10 min timeout)
$timeout = 600
$start   = Get-Date
while ((Get-Date) -lt $start.AddSeconds($timeout)) {
    $updates = Invoke-RestMethod -Uri "https://api.telegram.org/bot$botToken/getUpdates?offset=$offset"
    $reply   = $updates.result | Where-Object { $_.message.text } | Select-Object -Last 1
    if ($reply) {
        $input  = $reply.message.text.Trim().ToLower()
        $offset = $reply.update_id + 1

        if ($input -eq "all") {
            $approvedVideos = $foundVideos
        } elseif ($input -eq "none") {
            $approvedVideos = @()
        } else {
            $indices = $input -split "," | ForEach-Object { [int]$_.Trim() - 1 }
            $approvedVideos = $indices | ForEach-Object { $foundVideos[$_] }
        }
        break
    }
    Start-Sleep -Seconds 3
}
```

- `approve` → add to `$approvedVideos`
- `reject` / timeout → skip

### Step 6: Save approved videos + local DB
```powershell
$config.approved_videos = $approvedVideos
$config | ConvertTo-Json -Depth 10 | Set-Content $configPath

# Append to local DB
$db = Get-Content "$env:USERPROFILE\.openclaw\workspace\video_cue\db\videos.json" -ErrorAction SilentlyContinue | ConvertFrom-Json
$db += $allFoundVideos
$db | ConvertTo-Json | Set-Content "$env:USERPROFILE\.openclaw\workspace\video_cue\db\videos.json"
```

Telegram summary:
```
✅ Search complete
• Approved: X videos
• Rejected: Y videos

Sending approved videos to Vizard now...
```

### Step 7: Cron scheduling (optional)
Delegate to cron-scheduler:
- Name: `video-cue-search`
- Payload: `/search videos`
- Channel: telegram
- To: `$chatId`

---

## Command: `/clip videos`

**Purpose:** Stage 2 — Send approved videos to Vizard, send clips to Telegram for approval

### Step 1: Check setup + load approved videos
```powershell
$config = Get-Content $configPath | ConvertFrom-Json
$videos = $config.approved_videos

if (-not $videos -or $videos.Count -eq 0) {
    Write-Host "No approved videos. Run /search videos first."
    exit
}
```

### Step 2: Load Vizard key
```powershell
$vizardKey = (Get-Content $envPath | Select-String "VIZARD_API_KEY=").ToString().Split("=")[1]
```

### Step 3: Send each video to Vizard

```powershell
foreach ($video in $videos) {
    # Create Vizard project
    $body = @{
        videoUrl    = $video.url
        videoType   = 2
        lang        = "auto"
        preferLength = @(0)
        getClips    = 1
        projectName = $video.title
    } | ConvertTo-Json

    $project = Invoke-RestMethod `
        -Uri "https://elb-api.vizard.ai/hvizard-server-front/open-api/v1/project/create" `
        -Headers @{ "VIZARDAI_API_KEY" = $vizardKey; "Content-Type" = "application/json" } `
        -Method POST `
        -Body $body

    $projectId = $project.data.projectId

    # Send Telegram status
    Invoke-RestMethod -Uri "https://api.telegram.org/bot$botToken/sendMessage" -Method POST -Body @{
        chat_id = $chatId
        text    = "✂️ Clipping: *{title}*`nVizard is processing... I'll send clips when ready (usually 2–5 min)"
        parse_mode = "Markdown"
    }

    # Poll Vizard for completion
    $maxWait = 600  # 10 minutes
    $waited  = 0
    $clips   = $null

    while ($waited -lt $maxWait) {
        Start-Sleep -Seconds 30
        $waited += 30

        $status = Invoke-RestMethod `
            -Uri "https://elb-api.vizard.ai/hvizard-server-front/open-api/v1/project/query/$projectId" `
            -Headers @{ "VIZARDAI_API_KEY" = $vizardKey }

        if ($status.data.code -eq 2000 -and $status.data.videos) {
            $clips = $status.data.videos
            break
        }
    }

    if (-not $clips) {
        Invoke-RestMethod -Uri "https://api.telegram.org/bot$botToken/sendMessage" -Method POST -Body @{
            chat_id = $chatId
            text    = "⚠️ Vizard timed out for: {title}. Skipping."
        }
        continue
    }

    # Send each clip to Telegram for approval
    $clipNum = 1
    foreach ($clip in $clips) {
        Invoke-RestMethod -Uri "https://api.telegram.org/bot$botToken/sendVideo" -Method POST -Body @{
            chat_id    = $chatId
            video      = $clip.url
            caption    = "✂️ *Clip {clipNum} of {total} — {title}*`n`n⏱ Duration: {clip.duration}`n`nReply *approve* or *reject*"
            parse_mode = "Markdown"
        }

        # Poll for reply (5 min timeout)
        $timeout = 300
        $start   = Get-Date
        while ((Get-Date) -lt $start.AddSeconds($timeout)) {
            $updates = Invoke-RestMethod -Uri "https://api.telegram.org/bot$botToken/getUpdates?offset=$offset"
            $reply   = $updates.result | Where-Object { $_.message.text -match "^(approve|reject)$" } | Select-Object -Last 1
            if ($reply) {
                $decision = $reply.message.text.ToLower()
                $offset   = $reply.update_id + 1
                break
            }
            Start-Sleep -Seconds 3
        }

        if ($decision -eq "approve") {
            $approvedClips += @{
                title    = "$($video.title) — Clip $clipNum"
                url      = $clip.url
                duration = $clip.duration
            }
        }
        $clipNum++
    }
}
```

### Step 4: Save approved clips
```powershell
$config.approved_clips = $approvedClips
$config | ConvertTo-Json -Depth 10 | Set-Content $configPath

# Append to local DB
$db = Get-Content "$env:USERPROFILE\.openclaw\workspace\video_cue\db\clipped.json" -ErrorAction SilentlyContinue | ConvertFrom-Json
$db += $approvedClips
$db | ConvertTo-Json | Set-Content "$env:USERPROFILE\.openclaw\workspace\video_cue\db\clipped.json"
```

Telegram summary:
```
✂️ Clipping complete
• Videos processed: X
• Clips approved: Y
• Clips rejected: Z

Ready to publish. Running /vid to post now...
```

### Step 5: Cron scheduling (optional)
Delegate to cron-scheduler:
- Name: `video-cue-clip`
- Payload: `/clip videos`
- Channel: telegram
- To: `$chatId`

---

## Command: `/vid to post`

**Purpose:** Stage 3 — Publish approved clips via Blotato

### Step 1: Load approved clips
```powershell
$config = Get-Content $configPath | ConvertFrom-Json
$clips  = $config.approved_clips

if (-not $clips -or $clips.Count -eq 0) {
    Write-Host "No approved clips. Run /clip videos first."
    exit
}
```

### Step 2: Load Blotato key
```powershell
$blotatoKey = (Get-Content $envPath | Select-String "BLOTATO_API_KEY=").ToString().Split("=")[1]
```

### Step 3: Publish each clip to each platform

```powershell
foreach ($clip in $clips) {
    foreach ($platform in $config.platforms) {

        $body = @{
            post = @{
                accountId = $platform.accountId
                content   = @{
                    text      = $clip.title
                    mediaUrls = @($clip.url)
                    platform  = $platform.platform
                }
                target    = @{
                    targetType = $platform.platform
                }
            }
        } | ConvertTo-Json -Depth 6

        $response = Invoke-RestMethod `
            -Uri "https://backend.blotato.com/v2/posts" `
            -Headers @{ "blotato-api-key" = $blotatoKey; "Content-Type" = "application/json" } `
            -Method POST `
            -Body $body

        Write-Host "✅ Published: $($clip.title) → $($platform.platform)"
    }
}
```

### Step 4: Save to local DB + clear approved clips
```powershell
$db = Get-Content "$env:USERPROFILE\.openclaw\workspace\video_cue\db\posted.json" -ErrorAction SilentlyContinue | ConvertFrom-Json
$db += $clips
$db | ConvertTo-Json | Set-Content "$env:USERPROFILE\.openclaw\workspace\video_cue\db\posted.json"

# Clear approved clips from config now that they're published
$config.approved_clips = @()
$config | ConvertTo-Json -Depth 10 | Set-Content $configPath
```

### Step 5: Telegram confirmation
```powershell
$summary = "🚀 *Clips published!*`n`n"
foreach ($clip in $clips) { $summary += "• $($clip.title)`n" }
$summary += "`nPlatforms: {platforms}`nTotal: {count} clips published"

Invoke-RestMethod -Uri "https://api.telegram.org/bot$botToken/sendMessage" -Method POST -Body @{
    chat_id    = $chatId
    text       = $summary
    parse_mode = "Markdown"
}
```

### Step 6: Cron scheduling (optional)
Delegate to cron-scheduler:
- Name: `video-cue-post`
- Payload: `/vid to post`
- Channel: telegram
- To: `$chatId`

---

## Cron-Scheduler Integration

```powershell
if (!(Test-Path "$env:USERPROFILE\.openclaw\workspace\skills\cron-scheduler")) {
    Expand-Archive `
        -Path "$env:USERPROFILE\.openclaw\workspace\skills\video-cue\bundled\cron-scheduler.zip" `
        -DestinationPath "$env:USERPROFILE\.openclaw\workspace\skills\cron-scheduler" -Force
    Write-Host "✅ cron-scheduler installed"
}
```

---

## Full Pipeline Summary

| Stage | Command | What happens |
|-------|---------|-------------|
| Setup (first use only) | Auto | Telegram + Vizard + Blotato setup → save config |
| 1 | `/search videos` | Search YouTube → send to Telegram → approve/reject → save approved |
| 2 | `/clip videos` | Send to Vizard → poll for clips → send clips to Telegram → approve/reject → save approved |
| 3 | `/vid to post` | Publish approved clips via Blotato → Telegram confirmation |

---

## Required Credentials

| Variable | Description | When asked |
|----------|-------------|------------|
| `TELEGRAM_BOT_TOKEN` | Telegram bot token | Setup wizard (step 1) |
| `TELEGRAM_CHAT_ID` | Your Telegram chat ID | Setup wizard (step 1) |
| `VIZARD_API_KEY` | Vizard API key | Setup wizard (step 2) |
| `BLOTATO_API_KEY` | Blotato API key | Setup wizard (step 3) |

All stored in `~/.openclaw/workspace/.env.personal`. Never asked again after setup.

---

## File Structure

```
~/.openclaw/workspace/
  .env.personal                          ← All API keys
  skills/video-cue/
    SKILL.md                             ← This file
    bundled/
      cron-scheduler.zip
  video_cue/
    config.json                          ← setup_complete, defaults, platforms, approved_videos, approved_clips, cron_ids
    db/
      videos.json                        ← all searched videos (dedup)
      clipped.json                       ← all clipped videos
      posted.json                        ← all published clips
```

---

## Notes

- **Setup wizard runs once** — triggered on first use, never again after `setup_complete: true`
- **Telegram config shared** — if already set up from another skill, step 1 of wizard is skipped silently
- **No Control Board** — all approval in Telegram (videos AND clips)
- **No PostStream** — Blotato handles 9+ platforms via one API
- **Vizard stays** — it's the clipping engine, no replacement needed
- **Local DB deduplication** — never processes the same video twice
- **All credentials in `.env.personal`** — never hardcoded, never asked twice
- **Auto-installs yt-dlp** if missing
