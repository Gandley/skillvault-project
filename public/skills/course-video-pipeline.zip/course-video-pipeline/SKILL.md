---
name: course-video-pipeline
description: Orchestrates the full course video production pipeline from topic idea to final rendered MP4. Use this skill whenever the user wants to produce a course video, run the full pipeline for a module or phase, or automate the end-to-end process from course design to finished video. Triggers on phrases like "make the video for phase X", "run the pipeline", "produce module X", "build the course video", "start video production", or any request to go from a course topic or existing COURSE-OVERVIEW.md to a finished video. This skill manages all handoffs between course-architect, slide-script-architect, slide-renderer, elevenlabs-voice, cloudinary, video-assembler, and video-stitcher.
---

# Course Video Pipeline

Orchestrate the full video production pipeline — from course topic to final phase MP4.

## Preflight wizard

**The preflight wizard runs automatically every time the pipeline is invoked — before anything else.** It checks all credentials, software dependencies, and optional connections. Nothing starts until the wizard completes.

---

### PREFLIGHT STEP 1 — Credential check

Check for the presence of all required environment variables. Do not test API calls yet — just confirm the variables exist and are non-empty.

```
Checking credentials...

[ ] ELEVENLABS_API_KEY
[ ] CLOUDINARY_CLOUD_NAME
[ ] CLOUDINARY_API_KEY
[ ] CLOUDINARY_API_SECRET
[ ] SHOTSTACK_API_KEY
```

Mark each as ✅ (found) or ❌ (missing).

If any are missing, stop and show:

```
❌ PREFLIGHT FAILED — Missing credentials

The following credentials are not configured:
- [list each missing one]

Open SETUP.md for instructions on where to get each credential and how to store it.
Reply RETRY once credentials are added.
```

Do not proceed until all 5 credentials are present.

---

### PREFLIGHT STEP 2 — Software check

Check for required software by running version commands in bash:

```bash
libreoffice --version 2>/dev/null && echo "ok" || echo "missing"
pdftoppm -v 2>/dev/null && echo "ok" || echo "missing"
node --version 2>/dev/null && echo "ok" || echo "missing"
python3 --version 2>/dev/null && echo "ok" || echo "missing"
npm list -g pptxgenjs 2>/dev/null && echo "ok" || echo "missing"
```

Mark each as ✅ or ❌.

If anything is missing, show the exact install command:

```
❌ PREFLIGHT FAILED — Missing software

[ ] LibreOffice — install: sudo apt install libreoffice
[ ] pdftoppm    — install: sudo apt install poppler-utils
[ ] Node.js     — install: https://nodejs.org (v18+ recommended)
[ ] Python 3    — install: sudo apt install python3
[ ] pptxgenjs   — install: npm install -g pptxgenjs

Install the missing items and reply RETRY.
```

Do not proceed until all software checks pass.

---

### PREFLIGHT STEP 3 — Google Drive wizard

After credentials and software pass, ask about Google Drive:

```
🔧 PREFLIGHT — Google Drive (Optional)

Google Drive lets you automatically organize and store all course videos
in a structured Drive folder at the end of each phase.

Is Google Drive connected?
→ Reply YES if it's already connected
→ Reply CONNECT if you'd like help connecting it now
→ Reply SKIP to proceed without Google Drive (chat delivery only)
```

---

**If user replies YES:**

Verify the connection is live by attempting a simple Drive MCP call (e.g. list root folder). If it succeeds:

```
✅ Google Drive — connected
```

Proceed to Preflight Step 4.

If the call fails despite the user saying yes:

```
⚠️ Google Drive appears to be disconnected or unauthorized.

Follow the CONNECT steps below to re-authorize, or reply SKIP to proceed without it.
```

Then show the CONNECT steps.

---

**If user replies CONNECT — run the connection wizard:**

```
📋 GOOGLE DRIVE CONNECTION WIZARD

Follow these steps to connect Google Drive:

STEP 1 — Open MCP Settings
  In your Claude interface, go to:
  Settings → Connections → MCP Apps

STEP 2 — Find Google Drive
  Look for "Google Drive" in the available connectors list.
  If you don't see it, search for "Google Drive" or "gdrive".

STEP 3 — Click Connect
  Click the Connect button next to Google Drive.
  You'll be redirected to a Google authorization page.

STEP 4 — Authorize access
  Sign in with the Google account where you want videos saved.
  Grant the requested permissions (read + write access to Drive).

STEP 5 — Confirm
  Once authorized, return here and reply CONNECTED.
  I'll verify the connection before we proceed.
```

When user replies CONNECTED, run the verification call. If it passes:

```
✅ Google Drive — connected and verified
```

Proceed to Preflight Step 4.

If verification fails:

```
⚠️ Connection attempt failed. Common causes:

- Authorization was not fully completed — try the steps again
- Wrong Google account selected — make sure you authorized the right account
- MCP server needs a moment — wait 30 seconds and reply RETRY

Or reply SKIP to proceed without Google Drive for now.
```

---

**If user replies SKIP:**

```
⏭️ Google Drive — skipped
Videos will be delivered via chat link only.
```

Save `google_drive_enabled: false` to pipeline state. Proceed to Preflight Step 4.

---

### PREFLIGHT STEP 4 — All clear

Once all checks pass, show the full preflight summary and launch:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ PREFLIGHT COMPLETE — ALL SYSTEMS GO

Credentials:
  ✅ ELEVENLABS_API_KEY
  ✅ CLOUDINARY_CLOUD_NAME
  ✅ CLOUDINARY_API_KEY
  ✅ CLOUDINARY_API_SECRET
  ✅ SHOTSTACK_API_KEY

Software:
  ✅ LibreOffice
  ✅ pdftoppm
  ✅ Node.js
  ✅ Python 3
  ✅ pptxgenjs

Google Drive: [✅ Connected / ⏭️ Skipped]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Starting pipeline...
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

Pipeline proceeds automatically from here into Stage 0.

---

## Overview

This skill coordinates seven skills in sequence:

```
0. course-architect       → COURSE-OVERVIEW.md
1. slide-script-architect → narration scripts + slide content specs
2. elevenlabs-voice       → audio generation (MP3 per segment)
3. cloudinary             → audio hosting (permanent public URLs)
4. slide-renderer         → PPTX → PNG → Shotstack JSON per segment
5. video-assembler        → segment MP4 rendering via Shotstack
6. video-stitcher         → final phase video from all segment MP4s
```

---

## Three approval checkpoints

**Checkpoint 0 — After course structure:**
Stop and show the full `COURSE-OVERVIEW.md` before any video production begins. Wait for explicit approval.

**Checkpoint 1 — After narration scripts:**
Stop and show all narration scripts before generating audio. Wait for explicit approval.

**Checkpoint 2 — After all segments render:**
Stop and show all segment MP4 URLs before stitching. Wait for explicit approval.

Never skip checkpoints. Never auto-approve on behalf of the user.

---

## Invocation

### Full pipeline from topic:
```
/coursevideopipeline [topic or niche]
```
Example: `/coursevideopipeline AI automation for freelancers`

### Pipeline from existing COURSE-OVERVIEW.md:
```
/coursevideopipeline Phase [X]
/coursevideopipeline Module [X.X]
```
Examples:
```
/coursevideopipeline Phase 1
/coursevideopipeline Module 2.3
```

If a `COURSE-OVERVIEW.md` already exists in the working directory, skip Stage 0 and start at Stage 1.

---

## Pipeline stages

---

### STAGE 0 — Course design

**Trigger:** User provides a topic or niche with no existing `COURSE-OVERVIEW.md`.

**Action:** Run `course-architect` with the provided topic.

course-architect will:
1. Assess the topic on audience clarity, outcome specificity, market viability, and deliverability
2. Present business recommendations (format, price, platform, course length) for approval
3. On approval, produce the full `COURSE-OVERVIEW.md`

**⛔ CHECKPOINT 0**

Present the following to the user:

```
📋 COURSE STRUCTURE READY — APPROVAL REQUIRED

Course: [title]
Phases: [count]
Modules: [total count]
Estimated total length: [hours]
Recommended price: $[X]
Recommended platform: [platform]

[Display full COURSE-OVERVIEW.md contents]

Do you approve this course structure?
→ YES to proceed to video production
→ NO + [what to change] to revise
```

Do not proceed to Stage 1 until the user explicitly approves.

---

### STAGE 1 — Script + slide specs

**Trigger:** User approves course structure, or existing `COURSE-OVERVIEW.md` found.

**Action:** Run `slide-script-architect` on the specified module from `COURSE-OVERVIEW.md`.

**Output:**
- Segment map (all segment IDs and estimated durations)
- Narration script per segment
- ElevenLabs generation commands per segment
- PPTX slide content spec per segment (AUDIO_URL and DURATION as placeholders)

**⛔ CHECKPOINT 1**

```
📋 NARRATION SCRIPTS READY — APPROVAL REQUIRED

Module: [module name]
Segments: [count]
Estimated total runtime: [sum of durations]

[List each segment ID + first 2 sentences of narration]

Do you approve these scripts?
→ YES to proceed to audio generation
→ NO to request edits (specify which segments to change)
```

Do not proceed until user explicitly approves.

---

### STAGE 2 — Audio generation

**Trigger:** User approves narration scripts.

**Action:** Run `elevenlabs-voice` for each segment in order.

For each segment:
```
elevenlabs-voice tts:
  text: [narration script]
  voice_id: [configured voice ID from slide-script-architect]
  model: eleven_multilingual_v2
  stability: 0.5
  similarity_boost: 0.75
  output: [segment-id].mp3
```

Process one segment at a time. Verify each MP3 is non-zero size before moving to the next. If a segment fails, retry once, then flag to the user.

**Output:** List of generated MP3 files with actual durations.

---

### STAGE 3 — Audio hosting

**Trigger:** All MP3s generated successfully.

**Action:** Run `cloudinary` to upload each MP3.

```
cloudinary upload:
  file: [segment-id].mp3
  resource_type: video
  folder: ai-operator-blueprint/phaseX/audio
  public_id: [segment-id]
```

**Output:** Audio URL map.

| Segment ID | Cloudinary Audio URL | Duration |
|---|---|---|
| phase1-01-intro | https://res.cloudinary.com/.../phase1-01-intro.mp3 | 25s |

---

### STAGE 4 — Slide rendering

**Trigger:** All audio URLs confirmed in Cloudinary.

**Action:** Run `slide-renderer` for each segment.

For each segment:
1. Inject confirmed Cloudinary audio URL and actual duration into the slide content spec
2. Build PPTX using pptxgenjs matching AI Operator brand
3. Convert PPTX to PNG: `libreoffice --headless --convert-to pdf [file].pptx` then `pdftoppm -jpeg -r 200`
4. View each slide image — confirm no layout errors before uploading
5. Upload PNG to Cloudinary: `folder: ai-operator-blueprint/phaseX/slides`
6. Generate Shotstack JSON using `type: "image"` asset

**Output:** Per segment — Cloudinary slide image URL + finalized Shotstack JSON.

---

### STAGE 5 — Segment rendering

**Trigger:** All Shotstack JSON payloads finalized.

**Action:** Run `video-assembler` for each segment in order.

For each segment:
1. Verify both Cloudinary URLs (audio + image) are publicly accessible before submitting
2. POST Shotstack JSON to render API
3. Poll every 10 seconds until status is `done`
4. Extract temp MP4 URL
5. Immediately upload to Cloudinary via URL upload
6. Store permanent Cloudinary MP4 URL in segment render log
7. Move to next segment — do not submit next until current is `done`

**Segment render log:**

| Segment ID | Render ID | Duration | Permanent MP4 URL |
|---|---|---|---|
| phase1-01-intro | abc123 | 25s | https://res.cloudinary.com/.../phase1-01-intro.mp4 |

---

**⛔ CHECKPOINT 2**

```
🎬 ALL SEGMENTS RENDERED — APPROVAL REQUIRED

Phase: [phase name]
Segments rendered: [count]
Total runtime: [sum of durations]

[List each segment ID + Cloudinary MP4 URL + duration]

Review each segment before the final stitch.

Do you approve all segments?
→ YES to stitch final phase video
→ NO + [which segments] to re-render specific segments
```

Do not proceed until user explicitly approves.

---

### STAGE 6 — Delivery preference

**Trigger:** User approves all segment renders at Checkpoint 2.

**Action:** Ask the user how they want the finished video delivered. Present this exactly:

```
📦 DELIVERY PREFERENCE

How would you like your finished video delivered?

1. Chat only — I'll post the final video URL directly in this conversation
2. Google Drive only — I'll organize everything into a Drive folder (requires Google Drive connected)
3. Both — URL in chat + uploaded to Google Drive

Reply with 1, 2, or 3.
```

Wait for the user's reply before proceeding. Save the preference to pipeline state as `delivery_preference: "chat" | "drive" | "both"`.

If the user selects 2 or 3 and Google Drive MCP is not connected, flag it immediately:
```
⚠️ Google Drive is not connected. Connect it in your MCP settings and reply again,
or reply with 1 to deliver via chat only.
```

Do not proceed to stitching until delivery preference is confirmed.

---

### STAGE 7 — Final stitch

**Trigger:** Delivery preference confirmed.

**Action:** Run `video-stitcher` with all permanent segment MP4 URLs in segment ID order.

- Calculate cumulative start times from actual durations
- Apply fade transitions between segments
- POST to Shotstack, poll until done (allow up to 5 minutes for full phase)

---

### STAGE 8 — Final hosting

**Trigger:** Stitch render complete.

**Action:** Upload final MP4 to Cloudinary permanently.

```
cloudinary upload from URL:
  file: [Shotstack final MP4 URL]
  resource_type: video
  folder: ai-operator-blueprint/phaseX/video
  public_id: phaseX-final
```

Do this immediately — Shotstack URLs expire in 24 hours.

---

### STAGE 9 — Delivery

Execute based on the confirmed `delivery_preference`:

---

**If `chat` or `both`:** Post this in conversation:

```
✅ PHASE X VIDEO COMPLETE

Final video: https://res.cloudinary.com/.../phaseX-final.mp4
Total runtime: [duration]
Segments: [count]

Segment breakdown:
- phase1-01-intro (25s)
- phase1-03-decision-lock (75s)
- ...
- phase1-XX-outro (20s)

Next: Proceed to Phase [X+1] or upload to your course platform.
```

---

**If `drive` or `both`:** Run `google-drive-delivery`:

1. Create folder structure: `[Course Title]/Phase X/final` and `[Course Title]/Phase X/segments`
2. Upload final phase MP4 to `final/`
3. Upload all segment MP4s to `segments/`
4. Return Drive folder link

Then post in conversation:

```
📁 GOOGLE DRIVE DELIVERY COMPLETE

Course folder: [Drive link]
Phase X final: [Drive link to phaseX-final.mp4]
Segments: [count] uploaded

Next: Proceed to Phase [X+1] or upload to your course platform.
```

---

**If `both`:** Post the chat summary first, then the Drive confirmation below it.

---

## State tracking

Maintain this state object throughout the run. Resume from the last completed stage if interrupted.

```json
{
  "course_title": null,
  "phase": null,
  "module": null,
  "stage": "current stage name",
  "checkpoint_0_approved": false,
  "checkpoint_1_approved": false,
  "checkpoint_2_approved": false,
  "delivery_preference": null,
  "google_drive_enabled": false,
  "segments": [
    {
      "id": "phase1-01-intro",
      "narration": null,
      "duration_estimated": null,
      "duration_actual": null,
      "audio_url": null,
      "slide_image_url": null,
      "shotstack_json": null,
      "render_id": null,
      "segment_mp4_url": null
    }
  ],
  "final_mp4_url": null
}
```

---

## Error handling

| Error | Stage | Action |
|---|---|---|
| `COURSE-OVERVIEW.md` missing | Stage 0 | Run course-architect first |
| ElevenLabs generation fails | Stage 2 | Retry once, then flag to user |
| MP3 file is 0 bytes | Stage 2 | API returned error body — check response, retry |
| Cloudinary upload fails | Stage 3/4/7 | Retry once, then flag to user |
| Slide visual QA fails | Stage 4 | Fix pptxgenjs, re-render, re-export, re-upload |
| Shotstack render `failed` | Stage 5 | Verify both Cloudinary URLs accessible, fix and resubmit |
| Shotstack stuck in `fetching` | Stage 5 | Re-check image and audio URLs are public |
| Stitch render fails | Stage 6 | Verify all segment URLs accessible, resubmit |
| User rejects at checkpoint | Any | Ask what to fix, re-run only affected segments, re-present checkpoint |

## What this skill does NOT do

- Does not generate audio — that is elevenlabs-voice's job
- Does not build slides or render images — that is slide-renderer's job
- Does not submit to Shotstack directly — that is video-assembler and video-stitcher's job
- Does not upload assets to Cloudinary — that is cloudinary's job
- Does not design the course structure — that is course-architect's job
- Does not write narration scripts — that is slide-script-architect's job
- Does not permanently store videos without Google Drive connected — Shotstack URLs expire in 24 hours
- Does not upload finished videos to course platforms (Teachable, Kajabi, Gumroad, etc.) — that is a manual step after delivery

Re-run only the rejected segments. For each:
1. Re-run `slide-script-architect` only if content changed
2. Re-run `elevenlabs-voice` only if narration changed
3. Re-upload audio to Cloudinary only if audio changed
4. Re-run `slide-renderer` (always — ensures fresh PNG + JSON)
5. Re-run `video-assembler`
6. Re-upload segment MP4 to Cloudinary
7. Update render log and re-present Checkpoint 2

Do not re-render segments the user already approved.
