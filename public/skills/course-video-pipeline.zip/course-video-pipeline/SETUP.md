# Course Video Pipeline — Setup Guide

Complete this guide before running any skill in this pack. Every stage depends on at least one of these credentials. Missing one will cause a silent failure mid-pipeline.

---

## Required credentials

| Credential | Used by | Where to get it |
|---|---|---|
| `ELEVENLABS_API_KEY` | elevenlabs-voice | [elevenlabs.io/app/settings/api-key](https://elevenlabs.io/app/settings/api-key) |
| `CLOUDINARY_CLOUD_NAME` | cloudinary | [cloudinary.com/console](https://cloudinary.com/console) — shown on dashboard |
| `CLOUDINARY_API_KEY` | cloudinary | Cloudinary dashboard → API Keys |
| `CLOUDINARY_API_SECRET` | cloudinary | Cloudinary dashboard → API Keys |
| `SHOTSTACK_API_KEY` | video-assembler, video-stitcher | [dashboard.shotstack.io](https://dashboard.shotstack.io) → API Keys |

Store all credentials in your environment config (e.g. `.env` file or OpenClaw config). Never hardcode them in scripts.

```bash
# Example .env
ELEVENLABS_API_KEY=your_key_here
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret
SHOTSTACK_API_KEY=your_shotstack_key
```

---

## Required software

| Software | Used by | Install |
|---|---|---|
| `curl` | elevenlabs-voice, cloudinary, video-assembler | Pre-installed on most systems. `sudo apt install curl` if missing. |
| `python3` | elevenlabs-voice | `sudo apt install python3` |
| `LibreOffice` | slide-renderer | `sudo apt install libreoffice` |
| `pdftoppm` | slide-renderer | `sudo apt install poppler-utils` |
| `node` + `npm` | slide-renderer | [nodejs.org](https://nodejs.org) — v18+ recommended |

### npm packages (slide-renderer)
```bash
npm install -g pptxgenjs
```

---

## Skills in this pack

Run them in this order for full course video production:

```
1. course-architect       → produces COURSE-OVERVIEW.md
2. slide-script-architect → narration scripts + slide specs
3. elevenlabs-voice       → audio generation
4. cloudinary             → asset hosting
5. slide-renderer         → PPTX → PNG → Shotstack JSON
6. video-assembler        → renders each segment MP4
7. video-stitcher         → stitches segments into final phase video
8. course-video-pipeline  → orchestrates all of the above automatically
```

You don't need to run skills 1–7 manually. The `course-video-pipeline` orchestrator manages all handoffs. Run `course-architect` first to produce `COURSE-OVERVIEW.md`, then hand off to `course-video-pipeline`.

---

## Quick-start

```
1. Complete all credentials above
2. Install all required software
3. Run course-architect with your course topic
4. Approve the course structure
5. Run course-video-pipeline with the phase you want to produce
```

That's it.
