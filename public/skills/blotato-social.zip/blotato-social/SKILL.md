---
name: Blotato Social Media Manager
slug: blotato-social
author: OpenClaw Community
source: https://github.com/openclaw/skills/blotato-social
description: Create and publish social media posts across 9+ platforms using the Blotato API. Supports Instagram, Twitter/X, LinkedIn, TikTok, YouTube, Facebook, Threads, Pinterest, and Bluesky.
version: 3.0.0
---

# Blotato Social Media Manager

Create, schedule, and publish social media posts across 9+ platforms via the Blotato API.

## Supported Platforms

📸 Instagram | 🐦 Twitter/X | 💼 LinkedIn | 🎥 TikTok | 📺 YouTube | 👥 Facebook | 🧵 Threads | 📌 Pinterest | 🦋 Bluesky

## Quick Start

### Prerequisites

1. Blotato account (paid plan required for API): https://my.blotato.com
2. API key from: https://my.blotato.com/settings → API
3. Social accounts connected in Blotato dashboard
4. Account IDs fetched (see Step 1 below)

### Configuration

**Required environment variable:**

```bash
BLOTATO_API_KEY=your_api_key_here
```

**OpenClaw Config:**

```json
{
  "skills": {
    "entries": {
      "blotato-social": {
        "apiKey": "{{ env.BLOTATO_API_KEY }}"
      }
    }
  }
}
```

## Supported Commands

- ✅ "Post to [platform]"
- ✅ "Create a post"
- ✅ "Schedule a post for [time]"
- ✅ "Share on social media"
- ✅ "Tweet this" / "Post to Instagram"
- ✅ "Post everywhere"

**Refusal behavior:**
- Will not post without user confirmation on caption/media
- Will not post to platforms the user hasn't connected in Blotato
- Will refuse commands outside social media posting scope

---

## Workflow

### Step 0: Configuration Check

```powershell
$envPath  = "$env:USERPROFILE\.openclaw\workspace\.env.personal"
$apiKey   = (Get-Content $envPath -ErrorAction SilentlyContinue | Select-String "BLOTATO_API_KEY=").ToString().Split("=")[1]

if (-not $apiKey) {
    Write-Host "⚠️ Blotato API key not configured."
    Write-Host "1. Get key from: https://my.blotato.com/settings → API"
    Write-Host "2. Add to .env.personal: BLOTATO_API_KEY=your_key"
    exit
}
```

---

### Step 1: Fetch Connected Accounts

**Always fetch accounts first to get `accountId` values before posting.**

```powershell
$accounts = Invoke-RestMethod `
    -Uri "https://backend.blotato.com/v2/users/me/accounts" `
    -Headers @{ "blotato-api-key" = $apiKey }
```

Display connected accounts:
```
Connected accounts:
1. Instagram - @{handle}     (accountId: {id})
2. X/Twitter - @{handle}     (accountId: {id})
3. LinkedIn  - {name}        (accountId: {id})
4. TikTok    - @{handle}     (accountId: {id})
...
```

**Graceful failure:**
- 401 → "Invalid API key. Check your Blotato settings."
- 500 → "Blotato API unavailable. Try again later."
- Network error → "Cannot connect to Blotato. Check your internet."

---

### Step 2: Gather Content & Validate Media

**Platform media requirements:**

| Platform | Media Required? | Max Image Size | Max Video Size |
|----------|----------------|----------------|----------------|
| Instagram | ✅ Required | 8 MB | 100 MB |
| TikTok | ✅ Required (video) | N/A | 287 MB |
| YouTube | ✅ Required (video) | N/A | 256 GB |
| Twitter/X | ❌ Optional | 5 MB | 512 MB |
| LinkedIn | ❌ Optional | 10 MB | 200 MB |
| Facebook | ❌ Optional | 10 MB | 200 MB |
| Threads | ❌ Optional | 8 MB | 100 MB |
| Pinterest | ✅ Required (image) | 20 MB | N/A |
| Bluesky | ❌ Optional | **1 MB** ⚠️ | 50 MB |

**⚠️ Bluesky has a strict 1MB image limit — always warn upfront.**

**Media validation:**
1. Check file size before posting
2. Warn if exceeds platform limits
3. If posting to multiple platforms, validate against strictest limit
4. Facebook CDN URLs (`fbcdn.net`) will fail on non-Meta platforms — download and rehost first

**Uploading local files:**
If image/video is a local file without a public URL, upload to Blotato first:
```powershell
$upload = Invoke-RestMethod `
    -Uri "https://backend.blotato.com/v2/media" `
    -Headers @{ "blotato-api-key" = $apiKey } `
    -Method POST `
    -Form @{ file = Get-Item $localFilePath }

$mediaUrl = $upload.url
```

---

### Step 3: Create & Publish Post

**Publish immediately:**

```powershell
$body = @{
    post = @{
        accountId = "{accountId}"
        content   = @{
            text      = "{caption}"
            mediaUrls = @("{mediaUrl}")   # empty array if no media
            platform  = "{platform}"
        }
        target    = @{
            targetType = "{platform}"
        }
    }
} | ConvertTo-Json -Depth 6

$response = Invoke-RestMethod `
    -Uri "https://backend.blotato.com/v2/posts" `
    -Headers @{ "blotato-api-key" = $apiKey; "Content-Type" = "application/json" } `
    -Method POST `
    -Body $body
```

**Schedule for a specific time:**

```powershell
$body = @{
    post = @{
        accountId = "{accountId}"
        content   = @{
            text      = "{caption}"
            mediaUrls = @("{mediaUrl}")
            platform  = "{platform}"
        }
        target    = @{
            targetType = "{platform}"
        }
    }
    scheduledTime = "2026-06-01T15:00:00Z"   # ISO 8601 UTC
} | ConvertTo-Json -Depth 6
```

**Use next available calendar slot:**

```powershell
$body = @{
    post          = @{ ... }
    useNextFreeSlot = $true    # top-level field, not inside post
} | ConvertTo-Json -Depth 6
```

**Post to multiple platforms:** Make one API call per platform (one `accountId` per call). Loop through selected accounts.

```powershell
foreach ($account in $selectedAccounts) {
    $body = @{
        post = @{
            accountId = $account.id
            content   = @{
                text      = $caption
                mediaUrls = @($mediaUrl)
                platform  = $account.platform
            }
            target    = @{
                targetType = $account.platform
            }
        }
    } | ConvertTo-Json -Depth 6

    $result = Invoke-RestMethod `
        -Uri "https://backend.blotato.com/v2/posts" `
        -Headers @{ "blotato-api-key" = $apiKey; "Content-Type" = "application/json" } `
        -Method POST `
        -Body $body

    Write-Host "✅ Posted to $($account.platform)"
}
```

**Platform `targetType` values (use exactly as shown):**
- `instagram`
- `twitter`
- `linkedin`
- `tiktok`
- `youtube`
- `facebook`
- `threads`
- `pinterest`
- `bluesky`

---

### Step 4: Post a Twitter/X Thread

```powershell
$body = @{
    post = @{
        accountId = "{accountId}"
        content   = @{
            text      = "First tweet in the thread."
            mediaUrls = @()
            platform  = "twitter"
            additionalPosts = @(
                @{ text = "Second tweet."; mediaUrls = @() },
                @{ text = "Third tweet."; mediaUrls = @() }
            )
        }
        target    = @{
            targetType = "twitter"
        }
    }
} | ConvertTo-Json -Depth 8
```

---

### Step 5: Report Results

**Always report platform-by-platform:**

```
📊 Publish Results:

✅ Successfully posted to:
- Instagram (@handle)
- LinkedIn (Name)
- X/Twitter (@handle)

❌ Failed:
- Bluesky: image too large (1.75MB, max 1MB) — compress image and retry

Would you like me to retry failed platforms?
```

---

## Common Errors & Solutions

### 1. Missing API Key
```
Error: 401 Unauthorized
Fix: Check BLOTATO_API_KEY in .env.personal
```

### 2. Platform Not Connected
```
Error: accountId not found
Fix: Connect account at https://my.blotato.com/settings → Social Accounts
     Then re-fetch accounts to get new accountId
```

### 3. Bluesky File Size Error
```
Error: blob too big (maximum 1000000)
Fix: Image exceeds 1MB limit — compress or use smaller image
```

### 4. Facebook CDN Fetch Failed
```
Error: fetch failed on fbcdn.net URL
Fix: Download image locally, upload via /v2/media endpoint, use returned URL
```

### 5. Invalid Media URL
```
Error: media fetch failed
Fix: Ensure URL is publicly accessible (no auth required)
     Use Blotato upload endpoint for local files
```

---

## API Reference

**Base URL:** `https://backend.blotato.com/v2`
**Auth Header:** `blotato-api-key: YOUR_KEY`

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/users/me/accounts` | GET | List connected social accounts + accountIds |
| `/posts` | POST | Create and publish/schedule a post |
| `/media` | POST | Upload local media file, returns public URL |

**Full API docs:** https://help.blotato.com/api/start

---

## Platform Requirements Reference

| Platform | Emoji | Media | Character Limit |
|----------|-------|-------|----------------|
| Instagram | 📸 | Required (image/video) | 2,200 |
| TikTok | 🎥 | Required (video) | 2,200 |
| YouTube | 📺 | Required (video) | 5,000 (title: 100) |
| Twitter/X | 🐦 | Optional | 280 (25k Premium) |
| LinkedIn | 💼 | Optional | 3,000 |
| Facebook | 👥 | Optional | 63,206 |
| Threads | 🧵 | Optional | 500 |
| Pinterest | 📌 | Required (image) | 500 |
| Bluesky | 🦋 | Optional | ~300 |

---

## Best Practices

1. ✅ **Always fetch accounts first** — get fresh `accountId` values before posting
2. ✅ **Validate media size** against platform limits before posting
3. ✅ **One API call per platform** — loop through accounts
4. ✅ **Report platform-by-platform results** — partial success is common
5. ✅ **Warn about Bluesky 1MB limit** upfront when it's a target platform
6. ✅ **Upload local files** via `/v2/media` before posting
7. ✅ **Rehost Facebook CDN images** before posting to non-Meta platforms
8. ✅ **Offer retry** on partial failures

---

## Additional Resources

- **Platform Guidelines**: See `references/platform-guidelines.md`
- **Blotato API Docs**: https://help.blotato.com/api/start
- **Blotato Dashboard**: https://my.blotato.com

---

## Safety Notes

⚠️ **API calls use PowerShell `Invoke-RestMethod`** (no shell injection risk)

**External services called:**
- Blotato API (backend.blotato.com) — authenticated with user's API key
- No other external services

**No secrets in this repo** — API keys configured via `.env.personal` only.

---

## Version History

- **3.0.0** — Migrated from PostStream to Blotato. Updated all endpoints, auth header, account ID pattern, multi-platform loop approach
- **2.0.0** — PostStream version with mandatory status checking
- **1.0.0** — Initial release
