# VSL SCRIPT COMMAND — PROTOCOL

**Trigger:** `/vsl`

This skill generates a complete, deployment-ready Video Sales Letter script. Output is a spoken-language script formatted for direct recording — not written copy, not a slide deck, not a video file.

---

## STEP 1 — GATHER INPUTS

Ask the user for one of the following:

**Option A — Sales Page URL**
> "What's the URL of the sales page for this offer?"

Fetch the page and extract: product name, core mechanism, primary outcome, price, audience, proof points, and guarantee.

**Option B — Product Brief**
If no URL exists, collect:
- Product name
- Target audience (who is this for?)
- Core mechanism (what makes it work?)
- Primary outcome (what result does the buyer get?)
- Price point
- Key proof (results, testimonials, stats — whatever exists)
- Guarantee (if any)

Do not proceed until you have enough information to write a specific, accurate script. Vague inputs produce vague scripts.

---

## STEP 2 — CONFIRM SCRIPT PARAMETERS

Before writing, confirm:

| Parameter | Default | User Can Change |
|---|---|---|
| Target length | 5 minutes (~1,200–1,500 words) | Yes |
| Format | One phrase per line | No — required for teleprompter use |
| Structure | 10-part framework (below) | No |
| Tone | Conversational, direct, confident | Yes |

Output a brief confirmation:
> "I'll write a [X]-minute VSL script for [product name], targeting [audience], focused on [primary outcome]. Ready to build?"

---

## STEP 3 — WRITE THE SCRIPT

### SCRIPT STRUCTURE — 10-PART FRAMEWORK

Build the script in this exact sequence. Each section has a word count target to maintain pacing.

---

**PART 1 — HOOK (first 15 seconds / ~50 words)**

Open with a bold statement, provocative question, or pattern interrupt that forces the viewer to keep watching.

Rules:
- Must address the viewer's primary frustration or desire immediately
- Do not introduce the product yet
- Create tension — the viewer should feel something is at stake
- Examples of strong openers: a surprising fact, a bold claim, a relatable failure moment

---

**PART 2 — PROBLEM AGITATION (~100 words)**

Expand on the pain. Make the viewer feel understood before offering anything.

Rules:
- Name the specific problem — not a vague category of problems
- Use language the viewer would use themselves — casual, real
- Identify the emotional cost, not just the practical cost
- Do not introduce the solution yet — agitate first

---

**PART 3 — COMMON SOLUTIONS + WHY THEY FAIL (~100 words)**

Acknowledge what they've probably already tried and why it didn't work.

Rules:
- Name 2–3 real alternatives (other products, methods, approaches)
- Explain specifically why each one fails for this viewer
- This section creates differentiation without naming your product yet
- Tone: empathetic — not mocking the viewer for trying those things

---

**PART 4 — DISCOVERY MOMENT (~100 words)**

Introduce the turning point — how the solution was found. This can be personal story, client story, or research breakthrough.

Rules:
- Must feel real and specific — not generic
- Names a clear before/after moment
- Sets up the mechanism without fully explaining it yet
- Creates forward momentum: "and then I found something..."

---

**PART 5 — MECHANISM INTRODUCTION (~150 words)**

Introduce the core mechanism — what makes this work differently than everything else.

Rules:
- Name the mechanism specifically
- Explain the logic: why it works where other things don't
- Keep it simple — this is a spoken explanation, not a technical document
- The viewer should think: "that actually makes sense"

---

**PART 6 — PROOF + RESULTS (~150 words)**

Deliver the evidence. This is where skeptics become believers.

Rules:
- Lead with the most specific, impressive result available
- Include at least one testimonial or case study (real or early adopter)
- Use numbers, timeframes, and specifics wherever possible
- If proof is limited, use process proof: "here's exactly what happened when we tested this..."

---

**PART 7 — WHAT YOU GET — THE OFFER (~200 words)**

Present the complete offer clearly. Walk through every component with benefits attached.

Rules:
- Name every component of the offer
- For each component: "[What it is] — so you can [specific benefit]"
- Include price reveal — do not hide it
- If there are bonuses, give each one its own line with a benefit
- Optional: value stack showing what each component is worth

---

**PART 8 — OBJECTION HANDLING (~150 words)**

Address the 3–5 most likely objections for this specific audience.

Rules:
- Choose objections based on the audience — what would someone like them actually think?
- Address each with logic first, then reassurance
- Keep responses tight — 2–3 sentences per objection
- Tone: confident, not defensive

---

**PART 9 — URGENCY + GUARANTEE (~100 words)**

Present the real urgency and remove the risk.

Rules:
- Urgency must be real — state what specifically creates the time pressure
- Guarantee: state the timeframe, what it covers, and how simple it is to use
- These two together answer: "why now?" and "what if it doesn't work?"

---

**PART 10 — CLOSE + CALL TO ACTION (~100 words)**

Close with clarity and a direct action step.

Rules:
- Remind them what they're getting in one sentence
- Tell them exactly what to do right now
- Final identity line: who they become when they say yes
- The last line before the CTA should create forward momentum, not pressure

---

### SCRIPT FORMATTING RULES

These are non-negotiable — they exist because VSL scripts are read aloud, not read silently.

```
One phrase per line.

Short lines convert.

Like this.

Not like a paragraph that goes on for multiple sentences because it gets confusing
when the speaker has to find their place or figure out where to pause.
```

- Maximum 8 words per line
- Blank line between every line (breathing room)
- No bullet points or headers in the final script — this is spoken word
- Emphasis words in ALL CAPS where natural: "This is NOT a course. This is a SYSTEM."
- Stage directions in [brackets]: [pause] [slow down here] [direct to camera]

---

## STEP 4 — DELIVER THE SCRIPT

Output:

```
## VSL SCRIPT — [PRODUCT NAME]
## Target Length: [X] minutes (~[word count] words)
## Format: Teleprompter / Recording-Ready

---

[Full script — one phrase per line, blank lines between]

---

## SCRIPT NOTES
[Any flags, placeholder markers, or recommendations for strengthening before recording]
```

Flag clearly any sections that use placeholder proof or placeholder testimonials with:
`[PLACEHOLDER — replace with real result before recording]`

---

## WHAT THIS SKILL DOES NOT DO

This skill generates the script only.

To turn the script into a finished video, you need:
- A voice synthesis tool (ElevenLabs or similar) configured with your voice ID
- A slide generator or teleprompter tool
- A video renderer (Remotion, FFmpeg pipeline, or screen recording setup)

Those steps are handled by separate tools outside this skill.

---

*License: Open — any agent may use this skill*
*Created: 2026-05-21*
