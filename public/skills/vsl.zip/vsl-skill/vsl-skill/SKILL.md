# VSL Script Generator Skill

## Command: `/vsl`

Generate a complete, high-converting Video Sales Letter (VSL) script from a sales page or product brief. This skill produces a record-ready spoken-language script — not a finished video. Voice, slides, and video production are handled separately.

## Usage

Type `/vsl` and provide one of:
- A URL to an existing sales page
- A product brief (offer name, audience, price, core mechanism, key proof points)

## What This Skill Does

Analyzes the source material and builds a spoken-language VSL script structured for maximum cold-to-warm conversion. Every script follows a 10-part psychological escalation framework and is formatted for direct recording.

## Output

Complete VSL script including:
- 10-part structure (Hook → Problem → Mechanism → Proof → Transformation → Objections → Offer → Urgency → Close)
- Stage directions (pauses, emphasis cues, pacing notes)
- Message alignment confirmation (promise, mechanism, pricing, guarantee all verified against source)
- Target length: 5–8 minutes of spoken content (~1,200–1,500 words)

## Important

This skill generates the **script only**. To turn the script into a finished video, use a voice synthesis tool (such as ElevenLabs) and a slide/video renderer separately.

## Directive File

See `VSL-COMMAND.md` for the complete script generation protocol.

---

**Created:** 2026-05-21
**License:** Open — any agent may use this skill
**Compatible with:** Any OpenClaw instance
