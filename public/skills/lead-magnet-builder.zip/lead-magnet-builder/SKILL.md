---
name: lead-magnet-builder
description: >
  Creates downloadable lead capture assets for Nova's funnel. Activate immediately when the user
  types /lead magnet, /build a lead magnet, /create a freebie, /make a checklist, /build a guide,
  /make a swipe file, or asks anything like "build me something to capture leads", "create a free
  resource for my audience", "I need a lead magnet for [topic]", "make a freebie", "build an opt-in
  asset", or "create a [checklist / guide / playbook / swipe file / mini-course / quiz]". Also
  activate when a content calendar slot is labeled LEAD MAGNET PROMO — Nova needs the asset built
  before she can promote it. This skill produces complete, ready-to-export lead magnet assets
  including title, hook, full body content, and CTA — formatted for PDF export via the PDF skill.
  Also outputs an opt-in hook line and short description for use in landing page and social copy.
  Always ask for niche, audience pain point, and desired outcome before building. Never produce
  a generic lead magnet — every output must be specific, actionable, and premium-feeling.
---

# Lead Magnet Builder

Builds complete lead capture assets from scratch. Takes a topic, audience, and outcome — outputs
a full lead magnet ready for PDF export plus the opt-in copy to promote it.

## Primary command

`/lead magnet` — Guided build wizard for any lead magnet format.

## Supporting commands

- `/lead magnet checklist [topic]` — Build a checklist directly
- `/lead magnet guide [topic]` — Build a PDF guide directly
- `/lead magnet swipe file [topic]` — Build a swipe file directly
- `/lead magnet playbook [topic]` — Build a mini-playbook directly
- `/lead magnet audit [topic]` — Build a self-audit or scorecard
- `/lead magnet titles [topic]` — Generate 10 lead magnet title options without building
- `/lead magnet promo [title]` — Generate the opt-in copy for an existing lead magnet

---

## Lead magnet formats

Nova supports six formats. Each has a specific use case and audience match.

### FORMAT 1 — CHECKLIST
**Best for:** Audiences who want a fast, actionable reference they'll use repeatedly.
**Sweet spot:** 10–20 items. One page. Dense with value.
**Niche fit:** AI automation setup steps, business launch checklists, content creation checklists.
**Conversion strength:** ⭐⭐⭐⭐⭐ — Highest opt-in rate. Fast to consume, high perceived value.

### FORMAT 2 — GUIDE (PDF)
**Best for:** Audiences who want depth on a topic they're actively trying to solve.
**Sweet spot:** 600–1,200 words. 4–8 sections. Scannable headers.
**Niche fit:** How-to guides on AI agent setup, automation frameworks, monetization strategies.
**Conversion strength:** ⭐⭐⭐⭐ — Strong opt-in. Best when the topic is specific and urgent.

### FORMAT 3 — SWIPE FILE
**Best for:** Audiences who want steal-and-use templates they can implement immediately.
**Sweet spot:** 5–15 templates, prompts, scripts, or examples with brief context for each.
**Niche fit:** AI prompt libraries, caption templates, outreach scripts, email sequences.
**Conversion strength:** ⭐⭐⭐⭐⭐ — Extremely high perceived value. "Done for you" appeal.

### FORMAT 4 — MINI-PLAYBOOK
**Best for:** Audiences who want a step-by-step system, not just information.
**Sweet spot:** 3–5 phases or stages with actions in each. 800–1,500 words.
**Niche fit:** AI agent deployment playbook, 30-day automation playbook, content system playbook.
**Conversion strength:** ⭐⭐⭐⭐ — High value signal. Positions the brand as systematic.

### FORMAT 5 — AUDIT / SCORECARD
**Best for:** Audiences who want to know where they stand before they take action.
**Sweet spot:** 10–20 yes/no or scored questions across 3–5 categories. Score interpretation.
**Niche fit:** AI readiness audit, automation gap audit, content strategy scorecard.
**Conversion strength:** ⭐⭐⭐⭐ — High engagement. Creates personalized urgency.

### FORMAT 6 — RESOURCE LIST
**Best for:** Audiences who want a curated toolkit they don't have to build themselves.
**Sweet spot:** 15–30 resources with a one-line description and use case for each.
**Niche fit:** Best AI tools for business, top automation platforms, creator tool stack.
**Conversion strength:** ⭐⭐⭐ — Good opt-in. Lower barrier to create but competes with free lists online.

---

## Build workflow

When `/lead magnet` is triggered without a format specified, run the guided wizard.

---

### STAGE 1 — Input gathering

Ask all three questions in one message. Do not ask one at a time.

```
🧲 LEAD MAGNET BUILDER

To build the right asset, I need three things:

1. Topic — What is this lead magnet about? Be specific.
   (e.g. "setting up your first AI agent" not just "AI agents")

2. Audience — Who is downloading this? What do they do, what stage are they at?
   (e.g. "business owners who know AI exists but haven't automated anything yet")

3. Pain point or desired outcome — What problem does this solve or what result does it deliver?
   (e.g. "they waste hours on tasks an AI agent could handle in minutes")

Answer all three and I'll recommend the best format and build it.
```

Wait for user response before proceeding.

---

### STAGE 2 — Format recommendation

Based on the inputs, recommend the best format with a one-sentence reason.

```
📋 FORMAT RECOMMENDATION

Best fit: [FORMAT NAME]
Why: [One sentence — specific to their topic and audience]

Alternative: [Second format] — [When this would be better instead]

Build with [recommended format]? Or switch to the alternative?
```

Wait for confirmation before building.

---

### STAGE 3 — Title generation

Before writing the full asset, generate 5 title options. Titles are the most important
conversion lever on a lead magnet — a weak title kills opt-in rate regardless of content quality.

**Title formula rules:**

Every title must include at least one of:
- A specific number ("7 Steps", "10-Point", "The 5-Part")
- A time element ("in 30 Days", "This Week", "in 72 Hours")
- A specificity signal ("for [Audience]", "Without [Pain]", "Even If [Objection]")
- A result or transformation ("That Gets You [Outcome]", "To [Desired State]")

**Output format:**
```
🏷️ TITLE OPTIONS

1. [Title]
2. [Title]
3. [Title]
4. [Title]
5. [Title]

Which title? (Pick one or say "none — give me 5 more")
```

Do not proceed to Stage 4 until user selects or approves a title.

---

### STAGE 4 — Build the asset

Build the full lead magnet based on the confirmed format and title.
Follow the format-specific build instructions below exactly.

---

## Format build instructions

---

### CHECKLIST build

Structure:
```
[TITLE]
[One-line subtitle — what they'll be able to do after using this]

INTRODUCTION (2–3 sentences)
Why this checklist exists. What problem it solves. What they'll have when done.

---

[SECTION HEADER — if checklist has categories]

☐  [Item 1 — action-oriented, starts with a verb]
    → [Optional: one line of context if the item needs brief explanation]

☐  [Item 2]
    → [Context if needed]

[Repeat for all items — aim for 12–18 total]

---

WHAT TO DO NEXT
[2–3 sentences. Soft CTA toward the offer — do not hard sell.
Reference the next logical step after completing the checklist.]

[Brand/offer line — e.g. "Want help implementing this? [Brand] builds and deploys AI agents
for businesses like yours. [Link placeholder]"]
```

Rules:
- Every item starts with an action verb (Set up, Install, Configure, Write, Define, Test, etc.)
- No item is vague ("think about your strategy" is banned — "Define your primary automation goal
  in one sentence and write it here: ___" is correct)
- Context lines are optional but use them for items that will confuse a beginner
- Section headers optional — use if items naturally group into 3–4 categories

---

### GUIDE build

Structure:
```
[TITLE]
[Subtitle — outcome-focused, one line]

━━━━━━━━━━━━━━━━━━━

WHO THIS IS FOR
[2–3 sentences. Be specific. Tell the wrong person this isn't for them —
it increases trust with the right person.]

WHAT YOU'LL WALK AWAY WITH
• [Outcome 1]
• [Outcome 2]
• [Outcome 3]

━━━━━━━━━━━━━━━━━━━

[SECTION 1 HEADER]
[150–200 words. One core idea. Teach it clearly. End with a micro-action or insight.]

[SECTION 2 HEADER]
[150–200 words.]

[SECTION 3 HEADER]
[150–200 words.]

[SECTION 4 HEADER — optional 4th and 5th section if topic requires it]

━━━━━━━━━━━━━━━━━━━

THE BOTTOM LINE
[3–4 sentences. Synthesis of the key takeaway. Not a summary — a conclusion that
creates momentum toward the next step.]

NEXT STEP
[Soft CTA. What does someone do after reading this? Point to the offer naturally.
"If you want [outcome] without [pain], [Brand] can [brief value prop]. [Link placeholder]"]
```

Rules:
- No section under 100 words — thin sections signal low value
- Each section must have a standalone takeaway — reader should learn something from each section
  even if they skip the rest
- No academic language, no jargon without definition, no passive voice
- Subheaders within sections are allowed if a section naturally splits into two ideas

---

### SWIPE FILE build

Structure:
```
[TITLE]
[Subtitle — "X ready-to-use [templates/prompts/scripts] for [specific use case]"]

HOW TO USE THIS SWIPE FILE
[3–4 sentences. Tell them to copy, adapt, and make it their own.
Remind them context matters — they should adjust for their voice and audience.]

━━━━━━━━━━━━━━━━━━━

[CATEGORY HEADER — if templates group naturally]

## [Template/Prompt/Script #1 — descriptive name]
USE WHEN: [One line on the specific situation]

[The actual template — formatted clearly, with [BRACKETS] for fill-in-the-blank sections]

---

## [Template/Prompt/Script #2]
USE WHEN: [One line]

[Template]

---

[Repeat for all templates — minimum 7, maximum 20]

━━━━━━━━━━━━━━━━━━━

NEXT STEP
[Soft CTA. Reference offer naturally.]
```

Rules:
- Every template must be immediately usable — no "write your own version of this" placeholders
- [BRACKETS] mark every fill-in-the-blank clearly
- USE WHEN line is mandatory — without it the reader doesn't know when to deploy each template
- Quality over quantity — 8 excellent templates beats 20 mediocre ones

---

### MINI-PLAYBOOK build

Structure:
```
[TITLE]
[Subtitle — "A [X]-Phase System for [Outcome]"]

THE SYSTEM AT A GLANCE
Phase 1: [Name] — [One line]
Phase 2: [Name] — [One line]
Phase 3: [Name] — [One line]
[Phase 4 and 5 if applicable]

━━━━━━━━━━━━━━━━━━━

PHASE 1 — [NAME]
Goal: [What this phase accomplishes]
Time investment: [Realistic time estimate]

Step 1: [Action]
[2–3 sentences of instruction. Specific enough to execute, not so detailed it overwhelms.]

Step 2: [Action]
[Instruction]

Step 3: [Action]
[Instruction]

✓ Phase 1 complete when: [Clear completion criteria]

━━━━━━━━━━━━━━━━━━━

[Repeat for each phase]

━━━━━━━━━━━━━━━━━━━

YOU'VE GOT THE SYSTEM. NOW EXECUTE IT.
[3–4 sentences. Call out the gap between knowing and doing. Create urgency to start.
Soft CTA toward offer for those who want implementation support.]
```

Rules:
- Completion criteria at the end of every phase — reader must know when they're done
- Time estimates must be realistic — false promises ("5 minutes!") destroy trust
- Steps are actions, not concepts — "Define your automation goal" is a step,
  "Understanding automation" is a chapter heading
- Maximum 5 phases — anything longer needs to be a course, not a lead magnet

---

### AUDIT / SCORECARD build

Structure:
```
[TITLE]
[Subtitle — "Score your [area] and find out where to focus first"]

HOW TO USE THIS AUDIT
[3 sentences. Rate yourself honestly. No judgment. The score tells you where to start.]

━━━━━━━━━━━━━━━━━━━

CATEGORY 1 — [NAME] (X points possible)

Score each item: 0 = Not started | 1 = In progress | 2 = Done/Yes

[ ] [Statement they score themselves on]                    ___ / 2
[ ] [Statement]                                             ___ / 2
[ ] [Statement]                                             ___ / 2
[ ] [Statement]                                             ___ / 2
[ ] [Statement]                                             ___ / 2

Category 1 Score: ___ / 10

[Repeat for 3–5 categories]

━━━━━━━━━━━━━━━━━━━

YOUR TOTAL SCORE

Add up your category scores: ___ / [Total]

[SCORE RANGE 1 — e.g. 0–15]: [Label + 2 sentences on what this means and where to start]
[SCORE RANGE 2 — e.g. 16–30]: [Label + 2 sentences]
[SCORE RANGE 3 — e.g. 31–40]: [Label + 2 sentences]

━━━━━━━━━━━━━━━━━━━

NEXT STEP
[Score-aware CTA. Reference the offer as the natural next step for their score range.]
```

Rules:
- 0/1/2 scoring is simpler and more honest than 1–5 scales
- Every statement is specific and binary enough to self-score accurately
  ("I have defined my primary automation use case in writing" — not "I understand automation")
- Score ranges must have distinct labels that make the reader feel seen, not judged
- 4–5 categories, 5 items each = 40–50 total points — right size for a lead magnet

---

## STAGE 5 — Opt-in copy output

After the lead magnet is built, always output the opt-in copy package without being asked.

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📣 OPT-IN COPY PACKAGE

HEADLINE (for opt-in page or link-in-bio):
[Direct, benefit-forward, under 10 words]

SUBHEADLINE:
[One sentence — what they get + who it's for]

BULLET POINTS (for opt-in page body):
• [Benefit 1 — what they'll be able to do]
• [Benefit 2]
• [Benefit 3]

SOCIAL CAPTION HOOK (for promoting on Instagram/LinkedIn):
[2–3 line hook that creates curiosity without giving it all away.
Ends with a CTA to grab the freebie.]

CTA BUTTON TEXT OPTIONS:
1. [Option 1 — action-oriented]
2. [Option 2]
3. [Option 3]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Next step: Run /social post pipeline to create the promo content for this lead magnet,
or use the PDF skill to export the lead magnet for distribution.
```

---

## Quality rules — enforced on every output

**Specificity rule:** Every piece of advice, every checklist item, every template must be specific
to the stated niche and audience. "Think about your goals" is banned. "Write your primary
automation goal in one sentence using this format: [I want to automate X so that Y]" is correct.

**Premium feel rule:** The lead magnet must feel like something worth paying for. If it reads like
a generic blog post broken into bullets, rebuild it. The test: would someone pay $7 for this?
If yes, it's good enough to give away for free in exchange for an email.

**No fluff rule:** Every sentence earns its place. Cut anything that doesn't teach, guide, or
move the reader forward. Introductions are 2–3 sentences max. Sign-off sections are 3–4 sentences max.

**CTA rule:** Every lead magnet ends with a soft CTA. Never hard sell inside a free asset.
The CTA references the next logical step — if someone finished this checklist, what do they
need next? Point there. If that thing is the offer, name it without pressure.

## What this skill does NOT do

- Does not export to PDF — use the PDF skill to convert the output
- Does not build the opt-in landing page — hand off to Jake (Website Agent)
- Does not schedule or publish promo content — hand off to Social Post Pipeline
- Does not run ads to the lead magnet — out of scope for Nova
- Does not track opt-in conversion rates — that is the Analytics Feedback Loop skill's job
