# OPENCLAW LANDING PAGE DIRECTIVE

**Purpose:** Generate a complete, conversion-optimized landing page for any product or offer. This is not a long-form sales page and not just a hero section — it is a focused, mid-length page built to convert a specific audience at a specific price point.

**Core Principle:** Every section earns its place. No filler. No vague claims. No copy that exists just to fill space. Each section moves the reader one step closer to clicking the CTA.

---

## INPUT VARIABLES

Before building, collect and hold these five inputs. Every copy decision flows from them.

| Variable | Purpose |
|---|---|
| `product_name` | What is being sold |
| `target_audience` | Who this is for (be specific) |
| `price_point` | Sets the resistance level and required proof |
| `primary_outcome` | The single most important result the buyer gets |
| `traffic_source` | `cold` = more context needed / `warm` = can move faster |

**Traffic source rule:** Cold traffic needs more problem agitation and proof before the offer. Warm traffic can get to the mechanism faster. Adjust section depth accordingly.

---

## SECTION 01 — HERO

**Goal:** Stop the reader. Make them feel seen. Make them want to keep reading.

**Structure:**
```
[Pattern Interrupt Headline — 3–7 words, bold, punchy]
[Mechanism or Outcome Line — what this is and how it works]
[Identity/Outcome Shift — what this means for them]
[Supporting proof line — 1 sentence, specific]
[CTA Button — action-oriented label]
[Micro reassurance — remove friction below the button]
```

**Rules:**
- The headline must answer: "Why should I care?" in under 7 words
- The second line must answer: "What is this?"
- The third line must answer: "What does this do for me?"
- Do not make all three lines answer the same question
- No hype words: "revolutionary," "game-changing," "incredible"
- Cold traffic: lean into the problem or fear in the headline
- Warm traffic: lean into the outcome or identity in the headline

---

## SECTION 02 — PROBLEM STATEMENT

**Goal:** Agitate the pain the reader already feels. Make them feel understood before selling anything.

**Structure:**
```
[Problem headline — name the frustration directly]
[2–3 short paragraphs or a tight bullet list of pain points]
[Transition line that pivots toward the solution]
```

**Rules:**
- Name specific, real problems — not vague complaints
- Use the reader's own language — plain, not polished
- Do not introduce the product yet
- End with a line that implies a better way exists without naming it
- Cold traffic: spend more time here (3 pain points minimum)
- Warm traffic: keep it tight (1–2 pain points, fast pivot)

---

## SECTION 03 — MECHANISM / HOW IT WORKS

**Goal:** Introduce the product and explain the core mechanism that makes it work. This is the "aha" moment.

**Structure:**
```
[Mechanism headline — name what makes this different]
[1–2 paragraph explanation of how it works]
[3–5 step breakdown OR feature-to-benefit list]
[Optional: brief "why other solutions fail" contrast]
```

**Rules:**
- Lead with the mechanism, not the product name
- Each step or feature must connect to a specific benefit
- Do not list features without payoff — always: "[Feature] so you can [Benefit]"
- Keep technical detail proportional to the audience's sophistication
- Avoid making this section feel like an instruction manual

---

## SECTION 04 — SOCIAL PROOF BLOCK

**Goal:** Eliminate doubt with evidence. Proof must feel real and specific.

**Structure:**
```
[Section headline — e.g., "What Others Are Saying" or "Real Results"]
[2–3 formatted testimonials OR result callouts]
[Optional: logos, stats, or media mentions if available]
```

**Testimonial format:**
```
[Bold outcome statement — the result in their words]
[1–2 sentences of context — who they are, where they started]
[Attribution — first name, descriptor (optional photo reference)]
```

**Rules:**
- If real testimonials are available, use them verbatim and format them
- If placeholders are needed, label them clearly as `[TESTIMONIAL PLACEHOLDER]`
- No vague proof: "I loved it!" is worthless — results or specifics only
- Match proof to the price point: higher price = more specific proof required
- Cold traffic: place proof earlier and make it more detailed
- Warm traffic: can be lighter here — they already have context

---

## SECTION 05 — OFFER + CTA STACK

**Goal:** Present the complete offer clearly. Tell them exactly what they get and make the value obvious.

**Structure:**
```
[Offer headline — name what they're getting]
[What's included — bulleted list, benefit-first]
[Value stack if applicable — show total value vs. price]
[Primary CTA button]
[Urgency or scarcity line if applicable]
```

**Rules:**
- Every item in the list must have a clear benefit attached — not just a title
- If using a value stack, each line needs a dollar figure and a reason it's worth that
- The CTA button label must be action-oriented and outcome-focused
  - Bad: "Buy Now" / "Submit"
  - Good: "Get Instant Access" / "Start Building Today" / "Claim Your Spot"
- Urgency must be real — do not manufacture false scarcity
- Price must appear here clearly — never hide the price

---

## SECTION 06 — GUARANTEE

**Goal:** Remove the last objection. Make saying yes feel risk-free.

**Structure:**
```
[Guarantee headline — name the protection clearly]
[2–4 sentences explaining what the guarantee covers]
[Reassurance line — confirm the commitment]
```

**Rules:**
- State the timeframe clearly (e.g., 7-day, 30-day)
- Explain what "guaranteed" actually means — refund, results, access, etc.
- Keep it confident, not defensive — this is a strength, not an apology
- Do not over-promise in the guarantee what the product cannot deliver

---

## SECTION 07 — FINAL CTA

**Goal:** Close with clarity and momentum. The reader who made it here is close — don't lose them with a weak ending.

**Structure:**
```
[Closing headline — recap the transformation or outcome]
[2–3 sentence close — remind them what they're getting and why now]
[Final CTA button — same label as Section 05 for consistency]
[Micro reassurance — same line as hero or a reinforcing variant]
```

**Rules:**
- Do not introduce new information here
- Speak to the version of themselves they want to become
- The final line before the button should create forward momentum
- End on certainty — not pressure

---

## TONE DIRECTIVE

**Voice:**
- Clear and direct
- Confident without arrogance
- Empathetic without being soft
- Specific — never vague
- Matches the audience's language level

**Avoid:**
- Hype language and superlatives
- Hollow phrases: "unlock your potential," "transform your life," "the secret to..."
- Passive voice
- Walls of text — vary rhythm, use white space

**Adjust for price point:**
- Under $50: lighter, faster, benefit-forward
- $50–$200: balance proof and mechanism
- $200+: heavier on proof, identity, and mechanism detail

---

## OUTPUT FORMAT

Deliver the page in clearly labeled sections:

```
## [SECTION NAME]
---
[Copy for that section]
---
```

Each section must be self-contained so it can be handed off and deployed independently.

Do not summarize. Do not compress. Write every section in full.

---

*License: Open — any agent may use this skill*
*Created: 2026-05-21*
