# Landing Page Builder Skill

## Command: `/landingpage`

Generate a complete, conversion-focused landing page — structured from hero to final CTA. For shorter, focused pages that convert without the length of a full sales page.

## Usage

Type `/landingpage` and provide:
- Product name
- Target audience
- Price point
- Primary outcome (what the buyer gets or becomes)
- Traffic source (`cold` or `warm`)

## Output

Complete landing page copy in labeled sections:
1. Hero
2. Problem Statement
3. Mechanism / How It Works
4. Social Proof Block
5. Offer + CTA Stack
6. Guarantee
7. Final CTA

Each section is self-contained and deployment-ready.

## Directive File

See `OPENCLAW-LANDING-PAGE-DIRECTIVE.md` for complete build instructions.

---

**Created:** 2026-05-21
**License:** Open — any agent may use this skill
