---
name: video-assembler
description: POSTs Shotstack JSON payloads to the Shotstack render API and polls for completion. Use this skill whenever the user wants to render a course segment video, submit a Shotstack JSON to the API, check render status, or get the MP4 URL for a completed segment. Triggers on phrases like "render this segment", "submit to Shotstack", "assemble the video", "render phase X segment", or any request to turn a Shotstack JSON payload into an actual MP4 file.
---

# Video Assembler

Submit Shotstack JSON payloads to the render API and retrieve the final MP4 URL per segment.

## Credentials required

- `SHOTSTACK_API_KEY` — must be stored in OpenClaw's environment config

## API endpoints

- **Render:** `POST https://api.shotstack.io/v1/render`
- **Status:** `GET https://api.shotstack.io/v1/render/{id}`

Use `v1` for production. Use `stage` for testing (free, watermarked).

## Shotstack JSON format

All segment JSONs use image assets — never HTML assets for slide content.
The correct format produced by slide-renderer is:

```json
{
  "timeline": {
    "background": "#0a0f1e",
    "soundtrack": {
      "src": "CLOUDINARY_AUDIO_URL",
      "effect": "fadeIn"
    },
    "tracks": [
      {
        "clips": [{
          "asset": {
            "type": "image",
            "src": "CLOUDINARY_SLIDE_IMAGE_URL"
          },
          "start": 0,
          "length": DURATION,
          "fit": "cover",
          "transition": { "in": "fade", "out": "fade" }
        }]
      }
    ]
  },
  "output": {
    "format": "mp4",
    "resolution": "hd",
    "size": { "width": 1920, "height": 1080 }
  }
}
```

If a submitted JSON contains `"type": "html"` for slide content, reject it and request a corrected JSON from slide-renderer before proceeding.

## Before rendering — checklist

1. Slide image is uploaded to Cloudinary and URL is confirmed accessible
2. ElevenLabs audio is uploaded to Cloudinary and URL is confirmed accessible
3. `DURATION` is a number not a string (`30` not `"30"`)
4. JSON is valid — no trailing commas, no missing brackets, no comments

## Step 1 — Submit render

```bash
curl -X POST https://api.shotstack.io/v1/render \
  -H "Content-Type: application/json" \
  -H "x-api-key: $SHOTSTACK_API_KEY" \
  -d '{SHOTSTACK_JSON_PAYLOAD}'
```

Expected response:
```json
{
  "success": true,
  "message": "Created",
  "response": {
    "message": "Render Successfully Queued",
    "id": "RENDER_ID"
  }
}
```

Save the `id` — needed for polling.

## Step 2 — Poll for completion

Render takes 10-60 seconds. Poll every 10 seconds:

```bash
curl -X GET https://api.shotstack.io/v1/render/RENDER_ID \
  -H "x-api-key: $SHOTSTACK_API_KEY"
```

Status values:
- `queued` — waiting to start
- `fetching` — downloading assets
- `rendering` — actively rendering
- `saving` — uploading output
- `done` — complete, URL available
- `failed` — error, check response for details

## Step 3 — Extract MP4 URL

When status is `done`:
```json
{
  "response": {
    "status": "done",
    "url": "https://cdn.shotstack.io/au/v1/YOUR_ACCOUNT/RENDER_ID.mp4"
  }
}
```

Save this URL — pass immediately to cloudinary for permanent hosting. Shotstack URLs expire in 24 hours.

## Render one segment at a time

Do not submit multiple renders simultaneously. Render, confirm `done`, save URL, then move to next segment.

## Segment render log

| Segment ID | Render ID | Status | Temp MP4 URL | Permanent Cloudinary URL |
|---|---|---|---|---|
| phase1-01-intro | abc123 | done | https://cdn.shotstack.io/... | https://res.cloudinary.com/... |

## Error handling

| Error | Likely cause | Fix |
|---|---|---|
| `failed` status | Bad image URL, bad audio URL | Verify both Cloudinary URLs are publicly accessible |
| 401 | Wrong API key | Check SHOTSTACK_API_KEY in config |
| 422 | Malformed JSON | Validate JSON, check for trailing commas or comments |
| `fetching` stuck | Cloudinary URL not accessible | Re-check image and audio URLs |

## What this skill does NOT do

- Does not generate Shotstack JSON — that is slide-renderer's job
- Does not build slides or images — that is slide-renderer's job
- Does not generate audio — that is the elevenlabs-voice skill's job
- Does not stitch segments together — that is video-stitcher's job
- Does not permanently host the MP4 — pass URL to cloudinary immediately after render
