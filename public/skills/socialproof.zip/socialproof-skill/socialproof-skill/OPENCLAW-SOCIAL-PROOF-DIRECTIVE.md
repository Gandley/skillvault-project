# OPENCLAW SOCIAL PROOF DIRECTIVE

**Purpose:** Transform raw testimonials and result data into formatted, high-converting social proof blocks. Then tell Jake exactly where to place them on the page for maximum impact.

**Core Principle:** Raw testimonials almost never convert well. They're unfocused, buried in context, and lead with the wrong information. This skill restructures them so the outcome leads, the story supports, and the reader's doubt is eliminated as efficiently as possible.

---

## INPUT VARIABLES

| Variable | Purpose |
|---|---|
| `raw_testimonials` | Raw text, bullet points, or paraphrased results |
| `placement_context` | Where this proof will live on the page |
| `quantity` | Number of testimonials to format |

---

## STEP 01 — INPUT EVALUATION

Before formatting, Jake evaluates the raw testimonials and outputs an honest assessment. Weak proof formatted beautifully is still weak proof.

### What to Evaluate

**Proof Strength Rating**

Rate each testimonial on a 3-tier scale and explain why:

| Tier | Definition | What to Do |
|---|---|---|
| **Tier 1 — Strong** | Specific result, real context, named person | Format and use as-is |
| **Tier 2 — Usable** | Has a result but lacks specificity or context | Format with a flag to strengthen |
| **Tier 3 — Weak** | Vague, emotional-only, no result stated | Flag as insufficient — do not format, recommend replacement |

**What makes proof strong:**
- Specific numbers or outcomes ("made $1,200 in 11 days" not "made money")
- Named person with a descriptor (role, location, situation)
- Starting point context ("I had zero audience when I started")
- Mechanism acknowledgment ("the framework made it simple")

**What makes proof weak:**
- Pure emotion with no result ("This changed my life!")
- Vague outcomes ("I saw results fast")
- No identity context (could be anyone)
- Sounds fabricated or overly polished

### Evaluation Output Format

```
## PROOF EVALUATION
---
Testimonial 1: [Tier 1 / 2 / 3] — [1 sentence reason]
Testimonial 2: [Tier 1 / 2 / 3] — [1 sentence reason]
[Continue for each]

Overall Assessment: [1–2 sentences on the proof set as a whole]
Recommendation: [Proceed / Strengthen before use / Replace Tier 3 items]
---
```

Output this first. Then proceed to formatting.

---

## STEP 02 — TESTIMONIAL FORMATTING

### Standard Testimonial Block Structure

Every testimonial gets reformatted into this four-part structure:

```
[OUTCOME STATEMENT — bold, leads with the result]
[CONTEXT — who they are, where they started]
[MECHANISM ACKNOWLEDGMENT — what specifically worked]
[EMOTIONAL CLOSE — how it changed things for them]
— [Attribution: First name, descriptor]
```

### Rules for Each Part

**Outcome Statement (bold)**
- This is the first thing the reader sees — it must be the most compelling line
- Lead with the specific result, number, or transformation
- Keep it to 1–2 sentences maximum
- Pull directly from the raw testimonial where possible — do not fabricate
- If the raw testimonial doesn't lead with the result, reorder it so it does
- Bold this line in the output

**Context**
- 1–2 sentences establishing who the person is and where they started
- Grounds the testimonial in reality — makes it feel like a real person
- Include starting point if available ("before this I had no email list")
- Match the reader's likely situation — if the audience is beginners, highlight beginner context

**Mechanism Acknowledgment**
- 1 sentence naming what specifically worked
- This is critical for conversion — it connects the proof to the product
- Bad: "I just followed the steps"
- Good: "The deployment workflow had my page live before I finished my coffee"
- If the raw testimonial doesn't include this, note it as missing and leave a placeholder: `[MECHANISM — ask client to add specific detail]`

**Emotional Close**
- 1 sentence capturing the feeling or life change
- This is the human moment — keep it real, not cheesy
- Bad: "I feel so blessed and grateful!"
- Good: "For the first time I actually felt like I knew what I was doing."

**Attribution**
- First name minimum
- Add descriptor if available: role, location, situation ("solopreneur," "fitness coach," "stay-at-home mom")
- If photo reference is available, note: `[Photo: filename or placeholder]`
- Never fabricate attribution details

---

## STEP 03 — PULL-QUOTE VERSION

For any Tier 1 testimonial, also generate a pull-quote version suitable for hero sections or callout boxes.

### Pull-Quote Structure

```
"[Single most powerful sentence from the testimonial — 10–20 words]"
— [First name, descriptor]
```

**Rules:**
- Extract the single sharpest line — the one that would make a skeptic pause
- Must be a direct quote or close paraphrase — do not fabricate
- Under 20 words
- Works as a standalone statement with zero context needed
- Label clearly: `PULL-QUOTE VERSION`

---

## STEP 04 — PLACEMENT STRATEGY

After formatting, Jake outputs a placement guide for the page type provided. This is not generic advice — it is specific to the context input.

### Placement Rules by Page Type

**Hero Section**
- Use pull-quotes only — no full testimonial blocks above the fold
- 1 pull-quote maximum in the hero — more than one dilutes impact
- Position: directly below the CTA button or beside the form
- Best proof type for hero: result-specific, instantly credible, short

**Landing Page**
- Place the first proof block after the mechanism section (Section 03) — once you've explained how it works, proof validates the claim
- Place a second proof block before the final CTA — last-minute doubt removal
- Use full testimonial blocks here, not pull-quotes
- 2–3 testimonials maximum — more than 3 on a short landing page creates noise

**Sales Page**
- Proof should appear in multiple locations throughout the page
- After the problem section: early social proof normalizes the pain
- After the mechanism: proof that the mechanism works
- After the objection section: proof that overcomes the most common objection
- Before the CTA stack: final proof push before the ask
- Use a mix of full blocks and pull-quotes for visual rhythm

**Opt-In Page**
- One proof element maximum — this page must stay lean
- If used: a single pull-quote near the form, not a full testimonial block
- Only use if the proof is exceptionally strong (Tier 1 only)
- Weak proof on an opt-in page adds clutter, not credibility

**Standalone Proof Page / Testimonial Wall**
- Format all testimonials as full blocks
- Group by outcome type if multiple testimonials exist:
  - Speed results together
  - Revenue results together
  - Beginner wins together
- Each group gets a section headline that names the outcome category

### Placement Output Format

```
## PLACEMENT STRATEGY
---
Page Type: [type provided]
Recommended Positions: [specific locations on the page]
Proof Format to Use: [full block / pull-quote / mix]
Quantity Recommendation: [how many proof elements for this page type]
Notes: [any specific considerations for this proof set]
---
```

---

## HANDLING PLACEHOLDER TESTIMONIALS

If real testimonials are not available, Jake outputs formatted placeholder blocks that show exactly what's needed.

```
## [TESTIMONIAL PLACEHOLDER — COLLECT BEFORE LAUNCH]
**[OUTCOME: e.g., "Made first sale within 48 hours of launch"]**
[CONTEXT: e.g., "Solopreneur, no prior marketing experience"]
[MECHANISM: e.g., "Specific feature or step that made the difference"]
[EMOTIONAL CLOSE: e.g., "How it changed their confidence or situation"]
— [First name], [descriptor]
```

Flag all placeholders clearly. Never present placeholder copy as real testimonials.

---

## OUTPUT FORMAT

```
## PROOF EVALUATION
---
[Tier ratings and assessment]
---

## FORMATTED TESTIMONIAL BLOCKS

### Testimonial 1
---
[Full formatted block]

PULL-QUOTE VERSION:
"[pull-quote]"
— [attribution]
---

### Testimonial 2
---
[Full formatted block]
---

[Continue for each]

## PLACEMENT STRATEGY
---
[Page-specific placement guide]
---
```

Deliver every formatted block and the placement strategy in full. Do not summarize or abbreviate.

---

*License: Open — any agent may use this skill*
*Created: 2026-05-21*
