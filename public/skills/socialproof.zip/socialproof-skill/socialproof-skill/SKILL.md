# Social Proof / Testimonial Formatter Skill

## Command: `/socialproof`

Take raw testimonials or result data and format them into high-converting social proof blocks. Includes placement strategy — Jake tells you where on the page each proof block belongs and why.

## Usage

Type `/socialproof` and provide:
- Raw testimonial text OR bullet points of results
- Placement context: `hero` / `sales page` / `landing page` / `opt-in page` / `standalone`
- Number of testimonials to format (if multiple)

## Output

- Input evaluation and placement recommendations
- Reformatted testimonial block(s) with bolded outcome line
- Pull-quote version for hero placement (when applicable)
- Placement strategy guide for the page type provided

## Directive File

See `OPENCLAW-SOCIAL-PROOF-DIRECTIVE.md` for complete build instructions.

---

**Created:** 2026-05-21
**License:** Open — any agent may use this skill
