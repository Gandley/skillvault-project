---
name: content-calendar
description: >
  Content calendar and weekly posting strategy for Nova. Activate immediately when the user types
  /content calendar, /calendar, /plan my content, /content plan, /what should I post this week,
  /build my schedule, or asks anything like "plan out my posts", "give me a content schedule",
  "what should Nova post this week/month", "build a posting plan", or "map out my content".
  Also activate after a Trend Brief has been generated — the content calendar is the natural next
  step after /trends and should be suggested automatically. This skill takes trend intelligence,
  brand context, and content pillars and produces a structured weekly or monthly posting calendar
  with platform assignments, content types, topics, angles, and copy directions — ready to feed
  directly into the Social Post Pipeline for execution. Do not let Nova execute content without
  a calendar in place. Always run /trends first if a trend brief is not already available in the
  current session.
---

# Content Calendar & Strategy

Builds Nova's weekly or monthly content calendar from trend intelligence and brand context.
Outputs a structured posting plan ready to hand off to the Social Post Pipeline.

## Primary command

`/content calendar` — Build a full 7-day content calendar.

## Supporting commands

- `/content calendar 30` — Build a 30-day content calendar
- `/content calendar [platform]` — Platform-specific calendar (e.g. `/content calendar instagram`)
- `/content pillar check` — Review current content pillars and rebalance if needed
- `/content mix` — Show the current content type distribution without building a full calendar

---

## Brand context

Nova operates for a brand in the AI agent deployment and automation space targeting business owners,
entrepreneurs, and operators. The brand voice is direct, practical, and outcome-focused — no hype,
no vague futurism, real results and real implementation. Content bridges two niches:

**Primary:** AI Agent Deployment & Management for Business
**Secondary:** Entrepreneur / Make Money Online

The offer ecosystem this content supports:
- Lead magnets (checklists, guides, playbooks)
- Courses and training programs
- Done-for-you or productized services
- Community or membership access

Every piece of content Nova produces should move the audience closer to one of these offers,
even if it never mentions the offer directly.

---

## Content pillars

All content maps to one of four pillars. Every calendar must have representation across all four.
No pillar should exceed 35% of total posts in any given week.

### Pillar 1 — EDUCATE
Teach the audience something actionable about AI agents, automation, or building an online business.
Goal: build authority and trust. Audience takes away a skill or insight they can use.
Content types: tutorials, how-tos, frameworks, breakdowns, myth-busting, tool comparisons.

### Pillar 2 — ENTERTAIN
Hook attention and build brand personality. Not comedy for comedy's sake — entertainment that
reinforces positioning. Relatable frustrations, satisfying transformations, behind-the-scenes.
Goal: increase reach, shares, and saves. New audience discovery.
Content types: trending audio Reels, before/after, day-in-the-life, opinion takes, hot takes.

### Pillar 3 — CONVERT
Move warm audience members toward the offer. Direct or soft conversion content.
Goal: lead magnet downloads, DMs, clicks to offer page.
Content types: case studies, results posts, testimonials, lead magnet promos, CTA-forward posts.

### Pillar 4 — ENGAGE
Invite conversation and build community signals. Two-way content.
Goal: comments, replies, saves — algorithm fuel and relationship building.
Content types: polls, questions, controversial takes, "agree or disagree", hot takes with a hook.

---

## Platform posting cadence

Use these as the default cadence. Adjust based on trend brief recommendations.

| Platform  | Posts/Week | Best Days          | Best Times (local) |
|-----------|------------|--------------------|--------------------|
| Instagram | 4–5x       | Mon, Tue, Thu, Fri | 8–10am, 6–8pm      |
| YouTube   | 2–3x       | Tue, Thu, Sat      | 12–3pm             |
| LinkedIn  | 3–4x       | Tue, Wed, Thu      | 7–9am, 5–6pm       |

**YouTube note:** Shorts count separately from long-form. Target 2x Shorts + 1x long-form per week
when capacity allows. Start with Shorts only if the channel is under 1,000 subscribers.

---

## Content type definitions

Use these exact labels in calendar output so they map cleanly to Nova's pipelines.

| Label              | Format                    | Platform(s)              | Pipeline          |
|--------------------|---------------------------|--------------------------|-------------------|
| REEL               | Short video (≤30s)        | Instagram                | Video Cue         |
| CAROUSEL           | 5–10 slide swipe post     | Instagram, LinkedIn      | Social Post Pipeline |
| SINGLE             | Static image + caption    | Instagram, LinkedIn      | Social Post Pipeline |
| TEXT POST          | Text only                 | LinkedIn                 | Social Post Pipeline |
| YOUTUBE SHORT      | Short video (≤60s)        | YouTube                  | Video Cue         |
| YOUTUBE LONG       | Long-form video (5–20min) | YouTube                  | Video Cue         |
| LINKEDIN CAROUSEL  | PDF document upload       | LinkedIn                 | Social Post Pipeline |
| STORY              | Ephemeral story frame     | Instagram                | Social Post Pipeline |
| LEAD MAGNET PROMO  | Any format promoting LM   | Any                      | Social Post Pipeline + Lead Magnet Builder |

---

## Calendar build workflow

When `/content calendar` is triggered, run these stages in order.

---

### STAGE 1 — Trend brief check

Check if a Trend Brief was generated in the current session.

**If yes:** Proceed to Stage 2. Reference the brief throughout calendar build.

**If no:**
```
⚠️ No Trend Brief found for this session.

For the best calendar, run /trends first so Nova can build around
what's actually performing right now.

Options:
1. Run /trends now (recommended — takes 2–3 minutes)
2. Build calendar from baseline strategy only (no trend data)

Which would you like?
```

Wait for user choice. If they choose option 2, proceed with baseline strategy and note
"Built without trend data — run /trends before next calendar cycle" in the output.

---

### STAGE 2 — Duration and platform scope

If not already specified in the command, confirm:

```
📅 CONTENT CALENDAR SETUP

Duration: 7-day or 30-day?
Platforms: All (Instagram + YouTube + LinkedIn) or specific platform?

[If 7-day, proceed immediately after confirmation]
[If 30-day, note that week 1 is fully detailed and weeks 2–4 are topic-mapped only]
```

---

### STAGE 3 — Pillar and content mix calculation

Before building the calendar, calculate the slot distribution.

**For a 7-day calendar (approx. 9–12 total posts across all platforms):**

| Pillar   | Target % | 9-post count | 12-post count |
|----------|----------|--------------|---------------|
| EDUCATE  | 35%      | 3            | 4             |
| ENTERTAIN| 25%      | 2–3          | 3             |
| CONVERT  | 20%      | 2            | 2–3           |
| ENGAGE   | 20%      | 2            | 2–3           |

Show the mix to the user before building. Flag if any pillar is over 35%.

---

### STAGE 4 — Assign content slots

Map each slot to: Day + Platform + Pillar + Content Type + Topic/Angle.

Rules for slot assignment:
- No platform gets two posts on the same day unless one is a Story
- Lead with Educate and Entertain early in the week (Mon–Tue) — builds reach before Convert posts
- Convert posts go mid-to-late week (Wed–Fri) when audience is warmed
- Cross-Niche Opportunities from the trend brief get the highest-reach slot (best day + best time)
- Every Instagram Reel slot maps to Video Cue pipeline
- Every carousel or text post maps to Social Post Pipeline

---

### STAGE 5 — Output the calendar

Output the full calendar in the structured format below.

---

## Calendar output format — 7-day

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📅 NOVA CONTENT CALENDAR
Week of [Date Range] | [Platforms covered]
Built [with trend data / without trend data]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CONTENT MIX THIS WEEK
Educate: [X posts] | Entertain: [X] | Convert: [X] | Engage: [X]
Total posts: [X] across [X] platforms

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## MONDAY

### Post 1 — [Platform] | [Content Type] | [Pillar]
Topic: [Clear topic statement]
Angle: [The specific take or hook]
Format notes: [Any format-specific instructions — e.g. "open with a question", "use trending audio"]
Pipeline: [Social Post Pipeline / Video Cue / Lead Magnet Builder]
Priority: [🔴 HIGH / 🟡 MEDIUM / 🟢 FLEXIBLE]

---

## TUESDAY
[Same structure]

---

[Continue through Sunday]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## ⚡ CROSS-NICHE PLAYS THIS WEEK
[List any Cross-Niche Opportunities from the trend brief that are scheduled this week,
with the day and platform they're assigned to]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## EXECUTION ORDER

Create content in this order for maximum efficiency:

1. [Post] — [Why first — e.g. "needs video sourcing via Video Cue"]
2. [Post] — [Why second]
3. [Post] — [e.g. "carousel — fastest to build"]
...

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Next step: Run /social post pipeline to start creating the first post,
or run /video cue to source content for Reel and Short slots.
```

📲 *Telegram push — send when calendar is built and ready for review:*
```
📅 Nova Content Calendar Ready

[Date range] — [X] posts planned
Instagram: [X] | YouTube: [X] | LinkedIn: [X]
⚡ Cross-niche plays: [count]

Open Nova to start creating → /social post pipeline
```

---

## 30-day calendar format

For `/content calendar 30`:

- Week 1: Fully detailed (same format as 7-day above)
- Weeks 2–4: Topic map only — list the pillar, platform, content type, and topic for each slot
  without full angle and format notes. User runs `/content calendar` again at the start of each
  week to get the detailed plan with fresh trend data.

```
## WEEKS 2–4 TOPIC MAP

| Week | Day | Platform | Type | Pillar | Topic |
|------|-----|----------|------|--------|-------|
| 2    | Mon | Instagram | REEL | EDUCATE | [Topic] |
| 2    | Mon | LinkedIn | TEXT POST | ENGAGE | [Topic] |
...
```

Note at bottom: "Run /trends + /content calendar at the start of each week to get detailed
execution plans with current trend data."

---

## Pillar check command

### `/content pillar check`

Review the last 2 weeks of content. Ask the user to paste their recent post list
(or pull from PostStream via /analytics if available) and calculate actual pillar distribution.

Output:
```
📊 PILLAR CHECK — Last 14 Days

Educate:  [X posts] ([X]%) — [✅ On target / ⚠️ Over / ⚠️ Under]
Entertain:[X posts] ([X]%) — [status]
Convert:  [X posts] ([X]%) — [status]
Engage:   [X posts] ([X]%) — [status]

Diagnosis: [One sentence on what's off and why it matters]
Fix: [Specific recommendation for next week's calendar to rebalance]
```

---

## Content mix command

### `/content mix`

Show the recommended content type distribution for the current week without building a full
calendar. Useful for quick planning check-ins.

Output:
```
📋 RECOMMENDED CONTENT MIX — This Week

Instagram (4 posts): 2 Reels · 1 Carousel · 1 Single
YouTube (2 posts): 2 Shorts
LinkedIn (3 posts): 1 Carousel · 1 Text Post · 1 Text Post

Total: 9 posts | Est. creation time: ~3–4 hours with Nova
```

---

## Calendar rules Nova must follow

- Never schedule a Convert post as the first post of the week — audience needs to be warmed first
- Cross-Niche Opportunities always get the highest-reach slot that week
- If trend brief shows an algorithm update, adjust format recommendations immediately —
  do not stick to baseline if the platform has shifted
- LinkedIn carousels and Instagram carousels are different formats — never assign a single
  carousel spec to both platforms without format adaptation
- YouTube Shorts and Instagram Reels are different pipelines — Shorts go through Video Cue,
  Reels can be sourced via Video Cue or created natively via Social Post Pipeline
- Every week must have at least one lead magnet promo or CTA-forward post (Convert pillar)
- Story slots are supplementary — they do not count toward the weekly post total
  but should be planned for days with high-reach posts

## What this skill does NOT do

- Does not write captions or create content — hand off to Social Post Pipeline
- Does not source or clip videos — hand off to Video Cue
- Does not build lead magnets — hand off to Lead Magnet Builder
- Does not publish anything — all publishing goes through PostStream
- Does not track what performed — that is the Analytics Feedback Loop skill's job
- Does not replace the strategy agent — when a Content Strategy Agent exists, this skill
  receives strategy briefs from it rather than generating strategy independently
