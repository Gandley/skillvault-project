---
name: google-drive-delivery
description: Delivers completed course video assets to Google Drive at the end of the video pipeline. Creates a structured folder hierarchy for the course, uploads the final phase MP4 and segment MP4s, and returns shareable Drive links. Use this skill whenever the pipeline needs to deliver finished videos to Google Drive. Triggers on phrases like "send to Drive", "upload to Google Drive", "save to Drive", or when the course-video-pipeline delivery stage runs with Drive selected.
---

# Google Drive Delivery

Deliver completed course video assets to Google Drive with a clean, organized folder structure.

## Requires

- Google Drive MCP connected and verified (run the preflight wizard in course-video-pipeline first)
- Completed segment render log with permanent Cloudinary MP4 URLs
- Final phase MP4 URL from video-stitcher

---

## Important — multiple Google accounts

If you have more than one Google account, make sure the Drive MCP was authorized with the correct account before this skill runs. The pipeline will upload to whichever account was used during MCP authorization. To verify:

```
Check your Google Drive MCP connection in Settings → Connections → MCP Apps.
The authorized account email will be shown there.
```

If the wrong account is connected, disconnect and re-authorize with the correct one before proceeding.

---

## Folder structure

All course assets are organized under one root course folder:

```
[Course Title]/
  Phase 1/
    final/
      phase1-final.mp4
    segments/
      phase1-01-intro.mp4
      phase1-02-overview.mp4
      ...
  Phase 2/
    final/
      phase2-final.mp4
    segments/
      ...
  Phase 3/
    ...
```

Create this structure if it doesn't exist. Never upload to Drive root.

---

## Step 1 — Verify Drive connection

Before creating any folders, confirm the Drive MCP is live with a test call:

```
Google Drive MCP: list files in root folder
```

If this fails, stop immediately and show:

```
⚠️ Google Drive connection failed.
Go to Settings → Connections → MCP Apps and reconnect Google Drive.
Then reply RETRY, or reply SKIP to deliver via chat only.
```

Do not attempt any uploads until the connection is verified.

---

## Step 2 — Create folder structure

Using the Google Drive MCP, create the following folders in order:

```
1. Root: [Course Title]                    (skip if already exists)
2. Phase folder: [Course Title]/Phase X    (skip if already exists)
3. Final folder: [Course Title]/Phase X/final
4. Segments folder: [Course Title]/Phase X/segments
```

Check for existing folders before creating — do not create duplicates.

---

## Step 3 — Upload final phase video

Upload the permanent Cloudinary final phase MP4 to:
```
[Course Title]/Phase X/final/phaseX-final.mp4
```

Source is the Cloudinary URL — upload by URL, not local file.

---

## Step 4 — Upload segment videos

Upload each permanent Cloudinary segment MP4 to:
```
[Course Title]/Phase X/segments/[segment-id].mp4
```

Upload in segment ID order. Confirm each upload before moving to the next.

---

## Step 5 — Return Drive links

After all uploads complete, return:

```
📁 GOOGLE DRIVE DELIVERY COMPLETE

Course folder: [Drive link to root course folder]
Phase X final: [Drive link to phaseX-final.mp4]
Segments uploaded: [count]

Tip: Right-click the course folder in Drive and select
"Share" to give your team or VA access.
```

---

## Error handling

| Error | Cause | Fix |
|---|---|---|
| Connection fails at verification | MCP not authorized or expired | Reconnect Google Drive in MCP settings |
| Wrong account | Multiple Google accounts — wrong one authorized | Disconnect, re-authorize with correct account |
| Folder creation fails | Insufficient Drive permissions | Verify MCP has read + write access during authorization |
| Upload fails mid-run | Drive storage quota exceeded or network timeout | Check Drive storage, free up space, reply RETRY |
| Duplicate folder warning | Folder already exists from previous run | Skip creation silently, upload into existing folder |
| File not found | Cloudinary URL expired or incorrect | Verify Cloudinary URL is still accessible before retrying |

---

## What this skill does NOT do

- Does not render or process videos — assets must be fully rendered before delivery
- Does not upload to any platform other than Google Drive
- Does not delete or replace existing files — always adds new uploads
- Does not handle course platform uploads (Teachable, Kajabi, etc.) — that is a separate step
