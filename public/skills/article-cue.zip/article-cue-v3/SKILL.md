---
name: article-cue
description: >
  Telegram-based content pipeline: Search articles → Approve via Telegram → Write blog or newsletter article → Deliver as file.
  Activate when someone types /article cue, /search articles, or /write article.
  /article cue runs the full pipeline. Individual stage commands run standalone.
  Also handles scheduled runs triggered by cron.
---

# Article Cue v3.0.0

Runs a sequential 3-stage content pipeline entirely through Telegram. No external publishing platform required.

```
[Search Articles]
      ↓
[Telegram: Show articles one by one → User replies approve/reject]
      ↓
[Write article in chosen format (blog or newsletter)]
      ↓
[Deliver to Telegram as formatted message + downloadable file]
```

**Output formats:** `blog` | `newsletter` (user sets default in wizard, can change anytime)

---

## Trigger

`/article cue`

**Commands:**
- `/article cue` → Full pipeline wizard
- `/search articles` → Stage 1 (Search + approve via Telegram)
- `/write article` → Stage 2 (Write + deliver — uses last approved article)

---

## Installation Success Message

```
📝 Article Cue v3.0.0 Installed Successfully!

Telegram-based content pipeline — no external platforms needed.

🔍 SEARCH  → Find articles on any topic
✅ APPROVE → Review and approve via Telegram
✍️  WRITE   → AI writes full blog or newsletter article
📦 DELIVER → Get your article as a formatted file

Quick Start:
• /article cue      → Run full pipeline
• /search articles  → Search + approve only
• /write article    → Write from last approved article

All configs saved to: ~/.openclaw/workspace/article_cue/
```

---

## Stage 0: Telegram Bot Setup

**Check Telegram config FIRST before anything else.**

### Step 1: Check for existing Telegram config
```powershell
$envPath = "$env:USERPROFILE\.openclaw\workspace\.env.personal"
$botToken = (Get-Content $envPath -ErrorAction SilentlyContinue | Select-String "TELEGRAM_BOT_TOKEN=").ToString().Split("=")[1]
$chatId = (Get-Content $envPath -ErrorAction SilentlyContinue | Select-String "TELEGRAM_CHAT_ID=").ToString().Split("=")[1]
```

### Step 2: If BOTH found → skip setup, proceed to pipeline
> "✅ Telegram connected. Running pipeline..."

### Step 3: If NOT found → run setup wizard

> "📱 **Telegram Setup Required**
>
> I need your Telegram bot token and chat ID to send you articles for approval.
>
> **Step 1 — Create a bot (skip if you have one):**
> 1. Open Telegram → search **@BotFather**
> 2. Send `/newbot`
> 3. Follow prompts → copy the token it gives you
>
> **Already have a bot?** Just paste your token below."

- Save token to `.env.personal` as `TELEGRAM_BOT_TOKEN`

> "**Step 2 — Get your Chat ID:**
> 1. Send any message to your bot
> 2. I'll fetch your chat ID automatically."

```powershell
# Fetch chat ID from recent updates
$updates = Invoke-RestMethod -Uri "https://api.telegram.org/bot$botToken/getUpdates"
$chatId = $updates.result[-1].message.chat.id
```

- If found: confirm with user
- If NOT found: ask user to message the bot first, then retry

> "**Chat ID found: `{chatId}`**
> Saving config..."

Save both to `.env.personal`:
```powershell
Add-Content -Path $envPath -Value "TELEGRAM_BOT_TOKEN={token}"
Add-Content -Path $envPath -Value "TELEGRAM_CHAT_ID={chatId}"
```

> "✅ Telegram connected! Let's run the pipeline."

---

## Command: `/article cue`

**Purpose:** Full pipeline — Search → Approve → Write → Deliver

**Behavior:**
1. Run Stage 0 (Telegram check)
2. Run `/search articles` wizard
3. On approval complete → run `/write article` automatically
4. Deliver output

---

## Command: `/search articles`

**Purpose:** Stage 1 — Search for articles and send to Telegram for approval

### Step 1: Telegram check
Run Stage 0.

### Step 2: Check config
```powershell
$config = Get-Content "$env:USERPROFILE\.openclaw\workspace\article_cue\config.json" -ErrorAction SilentlyContinue | ConvertFrom-Json
```

If config exists:
> "Current config:
> Topic: {topic}
> Sources: {sources}
> Articles per run: {count}
> Default format: {format}
>
> 1. 🚀 Run with current config
> 2. ⚙️ Reconfigure
> 3. 🆕 Start fresh"

If NO config or user selects Reconfigure/Start fresh → run wizard:

**Wizard questions (ask one at a time):**

1. > "What topic should I search for articles about?"
   - Save as `topic`

2. > "How many articles should I find per run? (recommended: 5)"
   - Save as `count` (default: 5)

3. > "What's your default output format?
   > 1. 📝 Blog article
   > 2. 📧 Newsletter
   >
   > You can change this anytime mid-pipeline."
   - Save as `default_format` (`blog` or `newsletter`)

Save config:
```powershell
$config = @{
    topic = "{topic}"
    count = {count}
    default_format = "{format}"
    sources = ["Google News", "Medium", "industry blogs"]
} | ConvertTo-Json
$config | Set-Content "$env:USERPROFILE\.openclaw\workspace\article_cue\config.json"
```

### Step 3: Search articles
Search using web_search with queries:
```
web_search: {topic} news latest
web_search: {topic} site:medium.com
web_search: {topic} blog article
```

Extract for each article:
- `title`
- `url`
- `description` (snippet)
- `source` (domain name)
- `imageUrl` (og:image via web_fetch, fallback to favicon)

**Content moderation — filter before sending:**
```powershell
$flaggedKeywords = @("violence","killing","murder","blood","gore","attack","terrorist","sexual","porn","nude","drugs","cocaine","heroin","racist","hate speech")

$approvedArticles = $foundArticles | Where-Object {
    $combined = ($_.title + " " + $_.description).ToLower()
    -not ($flaggedKeywords | Where-Object { $combined.Contains($_) })
}
```

### Step 4: Send articles to Telegram for approval

Send each article as a Telegram message:

```powershell
$message = "📰 *Article {n} of {total}*`n`n*{title}*`n`n{description}`n`n🔗 {url}`n`nReply *approve* or *reject*"

Invoke-RestMethod -Uri "https://api.telegram.org/bot$botToken/sendMessage" -Method POST -Body @{
    chat_id = $chatId
    text = $message
    parse_mode = "Markdown"
}
```

If article has image, send photo first:
```powershell
Invoke-RestMethod -Uri "https://api.telegram.org/bot$botToken/sendPhoto" -Method POST -Body @{
    chat_id = $chatId
    photo = $imageUrl
    caption = "*{title}*"
    parse_mode = "Markdown"
}
```

### Step 5: Poll for user replies
```powershell
# Poll for reply after each article
$timeout = 300 # 5 minutes per article
$start = Get-Date

while ((Get-Date) -lt $start.AddSeconds($timeout)) {
    $updates = Invoke-RestMethod -Uri "https://api.telegram.org/bot$botToken/getUpdates?offset=$offset"
    $reply = $updates.result | Where-Object { $_.message.text -match "^(approve|reject)$" } | Select-Object -Last 1

    if ($reply) {
        $decision = $reply.message.text.ToLower()
        $offset = $reply.update_id + 1
        break
    }
    Start-Sleep -Seconds 3
}
```

- `approve` → add to `$approvedList`
- `reject` → skip, send next article
- No reply in 5 min → skip, send next article

### Step 6: Approval summary
After all articles processed:

```
✅ Approval complete
• Approved: X articles
• Rejected: Y articles

Ready to write. Running /write article now...
```

Save approved articles to config:
```powershell
$config.approvedArticles = $approvedList
$config | ConvertTo-Json | Set-Content "$env:USERPROFILE\.openclaw\workspace\article_cue\config.json"
```

### Step 7: Cron scheduling (optional)
> "🔍 Search complete!
>
> Schedule future searches?
> - **one-time** — Run manually
> - **every 6h** — Every 6 hours
> - **every 24h** — Daily
> - **skip** — Don't schedule"

If recurring: delegate to cron-scheduler skill:
- **Name:** `article-cue-search`
- **Payload:** `/search articles`
- **Schedule:** User interval
- **Channel:** telegram
- **To:** `$chatId`

---

## Command: `/write article`

**Purpose:** Stage 2 — Write full article from approved articles and deliver via Telegram

### Step 1: Load approved articles
```powershell
$config = Get-Content "$env:USERPROFILE\.openclaw\workspace\article_cue\config.json" | ConvertFrom-Json
$articles = $config.approvedArticles
```

If no approved articles:
> "No approved articles found. Run `/search articles` first."
> Exit

### Step 2: Confirm format
> "Writing in **{default_format}** format.
>
> Want to change?
> 1. 📝 Blog article
> 2. 📧 Newsletter
> 3. ✅ Keep current ({default_format})"

### Step 3: Fetch full article content
For each approved article:
```powershell
web_fetch: {url}
# Extract: full text, headings, key quotes, statistics
```

### Step 4: Write the article

**If format = blog:**
Write a full blog article with:
- Compelling headline
- Introduction (hook + thesis)
- 3-5 body sections with subheadings
- Key insights and takeaways from source articles
- Conclusion with call to action
- Word count: 800-1500 words
- Tone: informative, engaging, authoritative

**If format = newsletter:**
Write a newsletter with:
- Subject line
- Friendly opener (2-3 sentences)
- Main story summary (3-4 paragraphs)
- Key takeaways (bullet points)
- Quick hits (2-3 additional article summaries, 2-3 sentences each)
- Sign-off
- Word count: 400-700 words
- Tone: conversational, scannable, valuable

### Step 5: Deliver to Telegram

**Send formatted preview (first 500 chars):**
```powershell
$preview = "✍️ *Article Ready*`n`n*{headline}*`n`n{first_500_chars}...`n`n📎 Full article attached below"

Invoke-RestMethod -Uri "https://api.telegram.org/bot$botToken/sendMessage" -Method POST -Body @{
    chat_id = $chatId
    text = $preview
    parse_mode = "Markdown"
}
```

**Save full article as file:**
```powershell
# Save as markdown
$filename = "{topic}-{date}.md"
$filepath = "$env:USERPROFILE\.openclaw\workspace\article_cue\output\$filename"
New-Item -ItemType Directory -Force -Path (Split-Path $filepath)
$fullArticle | Set-Content $filepath

# Send as document via Telegram
$form = @{
    chat_id = $chatId
    document = Get-Item $filepath
    caption = "📄 Full {format}: {headline}"
}
Invoke-RestMethod -Uri "https://api.telegram.org/bot$botToken/sendDocument" -Method POST -Form $form
```

**Completion message:**
```
✅ Article delivered!
• Format: {format}
• Word count: ~{count}
• Sources used: {n}
• File: {filename}

Run /article cue again anytime for a new piece.
```

---

## Cron-Scheduler Integration

**Check and install cron-scheduler:**
```powershell
if (!(Test-Path "$env:USERPROFILE\.openclaw\workspace\skills\cron-scheduler")) {
    Expand-Archive -Path "$env:USERPROFILE\.openclaw\workspace\skills\article-cue\bundled\cron-scheduler.zip" `
        -DestinationPath "$env:USERPROFILE\.openclaw\workspace\skills\cron-scheduler" -Force
    Write-Host "✅ cron-scheduler installed automatically"
}
```

---

## Full Pipeline Summary

| Stage | Command | What happens |
|-------|---------|-------------|
| 0 | Auto | Telegram bot check / setup wizard |
| 1 | `/search articles` | Search → content moderation → send to Telegram → user approves/rejects |
| 2 | `/write article` | Fetch content → write in chosen format → deliver to Telegram as file |

---

## File Structure

```
~/.openclaw/workspace/
  .env.personal                          ← TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID
  skills/article-cue/
    SKILL.md                             ← This file
    bundled/
      cron-scheduler.zip                 ← Auto-installed if missing
  article_cue/
    config.json                          ← topic, format, approved articles, cron IDs
    output/
      {topic}-{date}.md                  ← Generated articles
```

---

## Notes

- **No external publishing platform required** — output is a portable `.md` file
- **Platform agnostic** — paste output into Beehiiv, Substack, WordPress, Ghost, anywhere
- **Telegram bot auto-detected** — reuses existing bot config if already set up
- **Format switchable anytime** — default saved in config, overridable per run
- **Content moderation** — inappropriate articles filtered before Telegram approval step
- **Lazy credential loading** — only asks for what it needs, when it needs it
