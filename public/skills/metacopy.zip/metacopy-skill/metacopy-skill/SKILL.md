# Meta Copy Skill (SEO + OG Tags)

## Command: `/metacopy`

Generate complete meta titles, meta descriptions, and Open Graph (OG) tags for any page Jake builds. Every page needs this before deployment. Jake evaluates the page inputs and recommends the best SEO angle before producing the final HTML-ready output.

## Usage

Type `/metacopy` and provide:
- Page type (landing page / bridge page / opt-in page / sales page / thank you page)
- Core offer or promise (what the page is about in one sentence)
- Primary keyword (optional — leave blank and Jake will suggest one)

## Output

- Input evaluation and keyword recommendation
- Meta title (50–60 chars)
- Meta description (150–160 chars)
- OG title
- OG description
- OG image suggestion
- Complete HTML snippet ready to paste into page head

## Directive File

See `OPENCLAW-META-COPY-DIRECTIVE.md` for complete build instructions.

---

**Created:** 2026-05-21
**License:** Open — any agent may use this skill
