# OPENCLAW META COPY DIRECTIVE

**Purpose:** Generate complete, deployment-ready meta titles, meta descriptions, and Open Graph tags for every page Jake builds. This runs as the final copy step before handoff to the deployment workflow.

**Core Principle:** Jake is not an SEO specialist. This skill is not about ranking — it is about two things: (1) making sure every page has clean, correct meta copy so nothing deploys naked, and (2) making sure the OG tags create a compelling preview when the page is shared on social. Both matter. Neither is optional.

---

## INPUT VARIABLES

| Variable | Purpose |
|---|---|
| `page_type` | What kind of page this is |
| `core_offer` | What the page is about — the promise or offer in one sentence |
| `primary_keyword` | Optional — the main search term this page should be associated with |

---

## STEP 01 — INPUT EVALUATION & RECOMMENDATIONS

Before writing any meta copy, Jake evaluates the inputs and outputs two recommendations.

### 1. Keyword Recommendation

If a keyword is provided — evaluate it:

| Situation | Recommendation |
|---|---|
| Keyword is specific and matches the offer | Use it — confirm and proceed |
| Keyword is too broad (e.g. "marketing") | Flag it — suggest a more specific variant |
| Keyword is too narrow or jargon-heavy | Flag it — suggest a more searchable version |

If no keyword is provided — recommend one based on the page type and core offer:
- Extract the most searchable phrase from the core offer
- Prioritize specificity over volume — a precise keyword that fits the page beats a broad one that doesn't
- Output 2 keyword options and recommend one with a reason

### 2. Page Type SEO Posture

Different page types have different meta copy goals. Jake confirms the right posture before writing:

| Page Type | SEO Posture |
|---|---|
| Landing page | Conversion-focused — meta copy should match the headline intent |
| Bridge page | Curiosity-focused — meta copy creates intrigue without overselling |
| Opt-in page | Benefit-focused — lead with the free offer and what they get |
| Sales page | Outcome-focused — lead with the transformation or result |
| Thank you page | Neutral / blocked — thank you pages should typically be noindexed |

**Thank you page rule:** Jake automatically adds `<meta name="robots" content="noindex, nofollow">` to thank you page output and flags this to the user with a note explaining why (thank you pages should not appear in search results).

### Evaluation Output Format

```
## INPUT EVALUATION
---
Keyword: [confirmed / recommended] — [keyword] — [1 sentence reason]
Page Type Posture: [posture type] — [1 sentence note]
Special Flags: [any noindex flags or issues noted]
---
```

---

## STEP 02 — META TITLE

**Goal:** Appear in browser tabs and search results. Communicate the page's core value in under 60 characters.

```
[Meta title — 50–60 characters]
```

### Rules

- Hard character limits: 50 characters minimum, 60 characters maximum
  - Under 50: too short, wasted opportunity
  - Over 60: gets truncated in search results — unacceptable
- Lead with the primary keyword where natural — do not force it
- Include the brand name at the end if space allows: `| Brand Name`
- Must read as a complete, compelling statement — not a keyword dump
- Different posture by page type:
  - Landing/sales: outcome or transformation ("Launch Your First Offer in 37 Minutes")
  - Opt-in: free offer + benefit ("Free Checklist: Build Your Email List This Week")
  - Bridge: curiosity or bold claim ("Most Marketers Get This Wrong")

**Output format:**
```
Meta Title: [copy]
Character count: [X/60]
```

---

## STEP 03 — META DESCRIPTION

**Goal:** Appear below the title in search results and link previews. Expand on the title and create a reason to click.

```
[Meta description — 150–160 characters]
```

### Rules

- Hard character limits: 150 characters minimum, 160 characters maximum
  - Under 150: wasted space
  - Over 160: gets truncated — unacceptable
- Must expand on the meta title — do not repeat it
- Include a soft CTA or forward-momentum phrase at the end
- Include the primary keyword naturally — do not stuff
- Write for a human reader, not a crawler
- Match the tone of the page — a bridge page meta description should feel different from a sales page one

**Soft CTA examples for meta descriptions:**
- "Find out how →"
- "See the full breakdown."
- "Get instant access."
- "Discover what's changed."

**Output format:**
```
Meta Description: [copy]
Character count: [X/160]
```

---

## STEP 04 — OPEN GRAPH TAGS

**Goal:** Control how the page looks when shared on Facebook, LinkedIn, Twitter/X, Slack, iMessage, and other platforms that read OG tags.

OG tags are separate from meta tags. They do not affect SEO — they control the social sharing preview. Both are required.

### OG Title

```
[OG title — can be slightly longer or more creative than meta title]
```

**Rules:**
- Does not have a hard character limit like meta title — but keep it under 90 characters
- Can be more conversational or curiosity-driven than the meta title
- Think: "what would make someone stop scrolling and click this link in a feed?"
- Can match the meta title if it's already strong — do not change it just for the sake of it

### OG Description

```
[OG description — 2–3 sentences, social-share optimized]
```

**Rules:**
- Longer than meta description is acceptable here — up to 200 characters
- Write for a social feed context — someone is seeing this shared by a friend or in an ad
- More conversational tone than meta description
- End with a forward-momentum line

### OG Image Suggestion

Jake cannot generate images — but he provides a specific creative brief for what the OG image should contain.

```
[OG image brief — dimensions, content description, text overlay suggestion]
```

**Standard OG image specs:**
- Dimensions: 1200 x 630px
- Format: JPG or PNG
- Safe zone for text: keep text within the center 1000 x 480px area

**Brief format:**
```
OG Image Brief:
- Background: [color, style, or photo direction]
- Text overlay: [headline or key phrase to display on the image]
- Visual element: [product mockup, person, icon, or graphic suggestion]
- Tone: [clean/minimal / bold/high-contrast / warm/lifestyle / dark/premium]
```

---

## STEP 05 — HTML OUTPUT

Jake outputs the complete HTML snippet formatted and ready to paste directly into the `<head>` section of the page.

```html
<!-- Primary Meta Tags -->
<title>[Meta Title]</title>
<meta name="title" content="[Meta Title]">
<meta name="description" content="[Meta Description]">

<!-- Robots (if applicable) -->
<meta name="robots" content="[index, follow / noindex, nofollow]">

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website">
<meta property="og:url" content="[PAGE URL PLACEHOLDER]">
<meta property="og:title" content="[OG Title]">
<meta property="og:description" content="[OG Description]">
<meta property="og:image" content="[OG IMAGE URL PLACEHOLDER]">

<!-- Twitter / X -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="[PAGE URL PLACEHOLDER]">
<meta property="twitter:title" content="[OG Title]">
<meta property="twitter:description" content="[OG Description]">
<meta property="twitter:image" content="[OG IMAGE URL PLACEHOLDER]">
```

**Placeholder rules:**
- `[PAGE URL PLACEHOLDER]` — flag for the deployment team to fill with the live URL
- `[OG IMAGE URL PLACEHOLDER]` — flag for the deployment team to fill once the OG image is uploaded
- Never leave placeholders unflagged — every placeholder must be visible and labeled

---

## STEP 06 — FINAL CHECKLIST

Before outputting, Jake runs this internal checklist and flags any failures:

- [ ] Meta title is between 50–60 characters
- [ ] Meta description is between 150–160 characters
- [ ] Primary keyword appears in meta title
- [ ] OG title is distinct from or an improvement on meta title
- [ ] OG image brief is specific enough to execute
- [ ] Thank you pages have noindex tag
- [ ] All placeholders are clearly labeled
- [ ] HTML snippet is complete and paste-ready

If any item fails — fix it before outputting. Do not output a checklist with failures.

---

## OUTPUT FORMAT

```
## INPUT EVALUATION
---
[Keyword and posture assessment]
---

## META COPY

Meta Title: [copy] ([X]/60 chars)
Meta Description: [copy] ([X]/160 chars)

OG Title: [copy]
OG Description: [copy]
OG Image Brief: [brief]

---

## HTML SNIPPET
---
[Complete paste-ready HTML]
---
```

Clean, complete, deployment-ready. Every time.

---

*License: Open — any agent may use this skill*
*Created: 2026-05-21*
