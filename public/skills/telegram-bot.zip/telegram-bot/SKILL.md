---
name: telegram-bot
description: >
  Telegram bot setup and communication standard for OpenClaw agents.
  Defines how agents connect to Telegram, format messages, present content,
  run approval flows, send notifications, and poll for replies.
  All other skills that use Telegram should reference this skill for consistency.
  Activate when someone types /telegram setup, /telegram test, or /telegram status.
---

# Telegram Bot v1.0.0

The communication layer for all OpenClaw agent pipelines. Defines how your agent connects to Telegram and how every type of message should be formatted and delivered.

**This skill does two things:**
1. **Setup** — connects your Telegram bot once, shared across all skills
2. **Standards** — defines exactly how agents present content, approvals, notifications, and results

---

## Trigger

`/telegram setup`

**Commands:**
- `/telegram setup` → Run setup wizard (or re-run if already configured)
- `/telegram test` → Send a test message to verify connection
- `/telegram status` → Show current bot config

---

## Installation Success Message

```
📱 Telegram Bot v1.0.0 Installed!

This skill connects your agent to Telegram and sets the communication standard for all pipelines.

Run /telegram setup to connect your bot.
Takes about 2 minutes. Only done once.
```

---

## Setup Wizard

### When to run
Runs automatically on first use of ANY skill that requires Telegram, OR manually via `/telegram setup`.

**Check first:**
```powershell
$envPath  = "$env:USERPROFILE\.openclaw\workspace\.env.personal"
$token    = (Get-Content $envPath -ErrorAction SilentlyContinue | Select-String "TELEGRAM_BOT_TOKEN=").ToString().Split("=")[1]
$chatId   = (Get-Content $envPath -ErrorAction SilentlyContinue | Select-String "TELEGRAM_CHAT_ID=").ToString().Split("=")[1]

if ($token -and $chatId) {
    Write-Host "✅ Telegram already configured. Bot token and chat ID found."
    Write-Host "Run /telegram test to verify, or /telegram setup to reconfigure."
    exit
}
```

---

### Step 1: Get Bot Token

> "📱 **Telegram Setup**
>
> I need a Telegram bot token to send you messages.
>
> **Don't have a bot yet? Create one in 60 seconds:**
> 1. Open Telegram → search **@BotFather**
> 2. Send `/newbot`
> 3. Choose a name (e.g. *My Agent Bot*)
> 4. Choose a username ending in `bot` (e.g. *myagent_bot*)
> 5. BotFather gives you a token — copy it
>
> **Already have a bot?** Paste your token below."

```powershell
$botToken = Read-Host "Paste your bot token"

# Validate token format
if ($botToken -notmatch "^\d+:[A-Za-z0-9_-]{35,}$") {
    Write-Host "⚠️ That doesn't look like a valid bot token. Expected format: 123456789:ABCdef..."
    # Re-prompt
}

# Verify with Telegram
$verify = Invoke-RestMethod -Uri "https://api.telegram.org/bot$botToken/getMe" -ErrorAction SilentlyContinue
if (-not $verify.ok) {
    Write-Host "❌ Token rejected by Telegram. Please check and try again."
    exit
}

Write-Host "✅ Bot verified: @$($verify.result.username)"
Add-Content -Path $envPath -Value "TELEGRAM_BOT_TOKEN=$botToken"
```

---

### Step 2: Get Chat ID

> "**Step 2 — Connect your chat**
>
> Now send any message to your bot in Telegram.
> (Just open the bot and type anything — even a single letter.)
>
> Press Enter here when you've done that."

```powershell
Read-Host "Press Enter after sending a message to your bot"

# Fetch chat ID from latest update
$updates = Invoke-RestMethod -Uri "https://api.telegram.org/bot$botToken/getUpdates"
$chatId  = $updates.result | Select-Object -Last 1 | ForEach-Object { $_.message.chat.id }

if (-not $chatId) {
    Write-Host "⚠️ No message found. Make sure you sent a message to your bot first."
    Write-Host "Try again: send any message to @$($verify.result.username) in Telegram, then press Enter."
    Read-Host "Press Enter to retry"

    $updates = Invoke-RestMethod -Uri "https://api.telegram.org/bot$botToken/getUpdates"
    $chatId  = $updates.result | Select-Object -Last 1 | ForEach-Object { $_.message.chat.id }
}

if (-not $chatId) {
    Write-Host "❌ Still couldn't find your chat ID. Check that you messaged the correct bot."
    exit
}

Add-Content -Path $envPath -Value "TELEGRAM_CHAT_ID=$chatId"
Write-Host "✅ Chat ID saved: $chatId"
```

---

### Step 3: Send Confirmation Message

```powershell
$msg = "✅ *Telegram connected!*`n`nYour agent can now send messages, approvals, and notifications here.`n`nReply *approve* or *reject* when prompted during pipelines."

Invoke-RestMethod -Uri "https://api.telegram.org/bot$botToken/sendMessage" -Method POST -Body @{
    chat_id    = $chatId
    text       = $msg
    parse_mode = "Markdown"
}

Write-Host ""
Write-Host "🎉 Setup complete!"
Write-Host "Bot: @$($verify.result.username)"
Write-Host "Chat ID: $chatId"
Write-Host ""
Write-Host "Run /telegram test anytime to verify the connection."
```

---

## Command: `/telegram test`

Sends a test message to confirm the connection is working.

```powershell
$envPath  = "$env:USERPROFILE\.openclaw\workspace\.env.personal"
$botToken = (Get-Content $envPath | Select-String "TELEGRAM_BOT_TOKEN=").ToString().Split("=")[1]
$chatId   = (Get-Content $envPath | Select-String "TELEGRAM_CHAT_ID=").ToString().Split("=")[1]

if (-not $botToken -or -not $chatId) {
    Write-Host "❌ Telegram not configured. Run /telegram setup first."
    exit
}

$msg = "🔔 *Test message*`n`nYour Telegram connection is working correctly.`n`n_Sent by your OpenClaw agent._"

$result = Invoke-RestMethod -Uri "https://api.telegram.org/bot$botToken/sendMessage" -Method POST -Body @{
    chat_id    = $chatId
    text       = $msg
    parse_mode = "Markdown"
}

if ($result.ok) {
    Write-Host "✅ Test message sent successfully."
} else {
    Write-Host "❌ Failed to send test message: $($result.description)"
}
```

---

## Command: `/telegram status`

```powershell
$botToken = (Get-Content $envPath | Select-String "TELEGRAM_BOT_TOKEN=").ToString().Split("=")[1]
$chatId   = (Get-Content $envPath | Select-String "TELEGRAM_CHAT_ID=").ToString().Split("=")[1]

if ($botToken -and $chatId) {
    $bot = Invoke-RestMethod -Uri "https://api.telegram.org/bot$botToken/getMe"
    Write-Host "✅ Telegram connected"
    Write-Host "Bot: @$($bot.result.username)"
    Write-Host "Chat ID: $chatId"
} else {
    Write-Host "❌ Telegram not configured. Run /telegram setup."
}
```

---

## Message Formatting Standards

All OpenClaw skills that send Telegram messages MUST follow these standards.

### Core Rules

- **No images, thumbnails, or media attachments** — text only
- **Markdown formatting** — always pass `parse_mode: Markdown`
- **Bold** for titles and labels: `*text*`
- **Italic** for secondary info: `_text_`
- **Code** for IDs, paths, commands: `` `text` ``
- **Links** shown as raw URLs — never masked or hidden
- **Emojis** used sparingly for status indicators only
- **Keep messages concise** — one idea per message, no walls of text

### Status Emojis (standard set — use only these)

| Emoji | Meaning |
|-------|---------|
| ✅ | Success / approved / done |
| ❌ | Failed / rejected / error |
| ⚠️ | Warning / needs attention |
| 🔔 | Notification / alert |
| ⏳ | Processing / waiting |
| 📋 | List / summary |
| 🚀 | Published / launched |
| ✂️ | Clipped / processed |
| 📝 | Article / writing |
| 📱 | Social post |
| 🎬 | Video |

---

## Content Presentation Formats

### Format 1: Single Item Card
Use when presenting one item for approval.

```
[emoji] *[Title]*

[type label]: [value]
[type label]: [value]
[type label]: [value]

🔗 [URL]

Reply *approve* or *reject*
```

**Example — Article:**
```
📝 *AI Tools Are Reshaping Marketing in 2026*

Author: Matt Wolfe
Source: Future Tools Weekly
Topic: AI Marketing

🔗 https://futuretools.io/articles/ai-marketing-2026

Reply *approve* or *reject*
```

**Example — Video:**
```
🎬 *How I Built a $10K/Month AI Business*

Channel: Greg Isenberg
Duration: 14:32
Views: 84,200

🔗 https://youtube.com/watch?v=abc123

Reply *approve* or *reject*
```

---

### Format 2: Numbered List
Use when presenting multiple items at once for bulk approval.

```
[emoji] *Found [N] [items] — reply with numbers to approve*
_(e.g. 1,3,5 — or 'all' — or 'none')_

1. *[Title]*
   [label]: [value]
   🔗 [URL]

2. *[Title]*
   [label]: [value]
   🔗 [URL]

3. *[Title]*
   [label]: [value]
   🔗 [URL]
```

**Example — Video list:**
```
🎬 *Found 5 videos — reply with numbers to approve*
_(e.g. 1,3 — or 'all' — or 'none')_

1. *How to Build AI Agents in 2026*
   Channel: Matt Wolfe
   🔗 https://youtube.com/watch?v=abc123

2. *The Future of Automation*
   Channel: Liam Ottley
   🔗 https://youtube.com/watch?v=def456

3. *I Replaced My Team with AI*
   Channel: Greg Isenberg
   🔗 https://youtube.com/watch?v=ghi789
```

---

### Format 3: Stage Complete Notification
Use at the end of each pipeline stage.

```
✅ *[Stage name] complete*

• [Metric]: [value]
• [Metric]: [value]
• [Metric]: [value]

[Next action description if applicable]
```

**Example:**
```
✅ *Search complete*

• Found: 8 videos
• Approved: 5
• Rejected: 3

Sending approved videos to Vizard now...
```

---

### Format 4: Pipeline Complete
Use at the very end of a full pipeline run.

```
🚀 *[Pipeline name] complete*

[emoji] [Item 1 title]
[emoji] [Item 2 title]
[emoji] [Item 3 title]

Platforms: [list]
Total: [N] [items] published
```

**Example:**
```
🚀 *Social posts published*

📱 5 AI Tools You Need in 2026
📱 Why Automation Beats Hiring
📱 The Creator Stack That Prints Money

Platforms: Instagram, X, LinkedIn
Total: 3 posts published
```

---

### Format 5: Error / Warning
Use when something fails or needs attention.

```
⚠️ *[What failed]*

Reason: [plain language explanation]
Fix: [what to do]
```

**Example:**
```
⚠️ *Vizard timed out*

Reason: Video took longer than 10 minutes to process
Fix: Run /clip videos again — it will retry the same video
```

---

### Format 6: Processing Notification
Use when a long-running task starts, so the user knows to wait.

```
⏳ *[Task name] started*

[Plain description of what's happening]
I'll message you when it's done.
```

**Example:**
```
⏳ *Vizard clipping started*

Sending 3 videos to Vizard for clip generation.
Usually takes 2–5 minutes per video.
I'll message you when clips are ready for review.
```

---

## Approval Flow Standard

All skills that require user approval MUST follow this pattern.

### Single item approval

1. Send item using **Format 1** (Single Item Card)
2. Poll for reply with 5-minute timeout per item
3. Accept only: `approve` or `reject` (case-insensitive)
4. On timeout: skip item, move to next
5. After all items: send **Format 3** (Stage Complete)

```powershell
function Wait-ForApproval {
    param($botToken, $chatId, $offset, $timeoutSeconds = 300)

    $start = Get-Date
    while ((Get-Date) -lt $start.AddSeconds($timeoutSeconds)) {
        $updates = Invoke-RestMethod -Uri "https://api.telegram.org/bot$botToken/getUpdates?offset=$offset"
        $reply   = $updates.result | Where-Object {
            $_.message.text -match "^(approve|reject)$"
        } | Select-Object -Last 1

        if ($reply) {
            return @{
                decision = $reply.message.text.ToLower()
                offset   = $reply.update_id + 1
            }
        }
        Start-Sleep -Seconds 3
    }

    # Timeout — return skip
    return @{ decision = "timeout"; offset = $offset }
}
```

### Bulk list approval

1. Send full numbered list using **Format 2**
2. Poll for reply with 10-minute timeout
3. Accept:
   - Numbers: `1,3,5` or `1 3 5` → approve those items
   - `all` → approve everything
   - `none` → reject everything
4. Parse reply:

```powershell
function Parse-BulkApproval {
    param($reply, $items)

    $input = $reply.Trim().ToLower()

    if ($input -eq "all")  { return $items }
    if ($input -eq "none") { return @() }

    $indices = $input -split "[,\s]+" | Where-Object { $_ -match "^\d+$" } | ForEach-Object { [int]$_ - 1 }
    return $indices | Where-Object { $_ -ge 0 -and $_ -lt $items.Count } | ForEach-Object { $items[$_] }
}
```

---

## Notification Standards

### When to notify (send a message)
- Pipeline stage starts (Format 6 — Processing)
- Approval needed (Format 1 or 2)
- Stage completes (Format 3)
- Pipeline fully complete (Format 4)
- Any error or warning (Format 5)

### When NOT to notify
- Every individual API call
- Minor intermediate steps
- Config reads/writes
- Cron job ticks (unless something needs attention)

**Rule: one message per meaningful event. Never spam.**

---

## Polling Standard

All approval polling follows this pattern:

```powershell
$offset = 0  # Track last processed update

# Get current offset first to ignore old messages
$existing = Invoke-RestMethod -Uri "https://api.telegram.org/bot$botToken/getUpdates"
if ($existing.result) {
    $offset = ($existing.result | Select-Object -Last 1).update_id + 1
}

# Now poll for new messages only
$timeout = 300  # seconds
$start   = Get-Date

while ((Get-Date) -lt $start.AddSeconds($timeout)) {
    $updates = Invoke-RestMethod -Uri "https://api.telegram.org/bot$botToken/getUpdates?offset=$offset"

    foreach ($update in $updates.result) {
        $offset = $update.update_id + 1
        $text   = $update.message.text.Trim().ToLower()

        if ($text -match "^(approve|reject|all|none|\d[\d,\s]*)$") {
            # Process reply
            return $text
        }
    }

    Start-Sleep -Seconds 3
}

return "timeout"
```

**Key rules:**
- Always set `offset` to last `update_id + 1` before polling to ignore stale messages
- Poll every 3 seconds
- Always have a timeout — never poll forever
- Single item approvals: 5-minute timeout
- Bulk list approvals: 10-minute timeout
- Long-running tasks (e.g. Vizard): 10-minute timeout

---

## Credential Storage Standard

All Telegram credentials stored in `~/.openclaw/workspace/.env.personal`:

```
TELEGRAM_BOT_TOKEN=123456789:ABCdefGHIjklMNOpqrSTUvwxYZ
TELEGRAM_CHAT_ID=987654321
```

**Reading credentials (standard pattern used by all skills):**
```powershell
$envPath  = "$env:USERPROFILE\.openclaw\workspace\.env.personal"
$botToken = (Get-Content $envPath | Select-String "TELEGRAM_BOT_TOKEN=").ToString().Split("=")[1]
$chatId   = (Get-Content $envPath | Select-String "TELEGRAM_CHAT_ID=").ToString().Split("=")[1]

if (-not $botToken -or -not $chatId) {
    Write-Host "⚠️ Telegram not configured. Run /telegram setup first."
    exit
}
```

**Skills should NEVER ask for Telegram credentials directly.** They check `.env.personal` first. If missing, they call the telegram-bot setup wizard.

---

## Sending Messages (Standard Function)

All skills use this pattern to send messages:

```powershell
function Send-TelegramMessage {
    param($botToken, $chatId, $text)

    Invoke-RestMethod -Uri "https://api.telegram.org/bot$botToken/sendMessage" -Method POST -Body @{
        chat_id                  = $chatId
        text                     = $text
        parse_mode               = "Markdown"
        disable_web_page_preview = $true   # Never auto-expand links
    }
}
```

**Always set `disable_web_page_preview: true`** — link previews clutter approval messages.

---

## File Structure

```
~/.openclaw/workspace/
  .env.personal                      ← TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID
  skills/telegram-bot/
    SKILL.md                         ← This file
    bundled/
      cron-scheduler.zip             ← For other skills that need scheduling
```

---

## Integration Checklist for Other Skills

When building a skill that uses Telegram, follow this checklist:

- [ ] Check `.env.personal` for `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID` before doing anything
- [ ] If missing → call telegram-bot setup wizard, don't ask directly
- [ ] Use **Format 1** for single item approvals
- [ ] Use **Format 2** for bulk list approvals
- [ ] Use **Format 3** for stage complete notifications
- [ ] Use **Format 4** for pipeline complete notifications
- [ ] Use **Format 5** for errors and warnings
- [ ] Use **Format 6** for long-running task start notifications
- [ ] Set `disable_web_page_preview: true` on all messages
- [ ] Always set offset before polling to ignore old messages
- [ ] Single item timeout: 5 minutes
- [ ] Bulk list timeout: 10 minutes
- [ ] Never send images, thumbnails, or media
- [ ] Never spam — one message per meaningful event

---

## Notes

- **One bot for everything** — all skills share the same bot token and chat ID
- **Text only** — no photos, videos, or documents sent by the agent
- **Links as raw URLs** — always visible, never masked
- **Markdown only** — bold, italic, code, no HTML
- **Offset tracking** — always ignore messages that arrived before the current poll started
