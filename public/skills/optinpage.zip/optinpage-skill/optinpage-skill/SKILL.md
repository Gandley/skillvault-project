# Opt-In Page Builder Skill

## Command: `/optinpage`

Generate a complete opt-in / lead magnet page. One goal: get the email. No long-form copy. No objection stacking. Just a tight, high-converting page that makes the lead magnet impossible to ignore.

## Usage

Type `/optinpage` and provide:
- Lead magnet name
- Target audience
- Primary benefit (the single most valuable thing they get)
- Any bonuses (optional)

## Output

Complete opt-in page copy with:
- 3 headline variants
- Sub-headline
- 3–5 bullet benefit stack
- Form field label copy
- 3 CTA button text variants
- Micro reassurance line below form

## Directive File

See `OPENCLAW-OPTIN-PAGE-DIRECTIVE.md` for complete build instructions.

---

**Created:** 2026-05-21
**License:** Open — any agent may use this skill
