# OPENCLAW OPT-IN PAGE DIRECTIVE

**Purpose:** Generate a focused, high-converting opt-in page for any lead magnet or free offer. This page has exactly one conversion goal: get the email address. Everything on this page exists to serve that goal. Nothing else belongs here.

**Core Principle:** Simplicity converts. An opt-in page is not a sales page. It is not a landing page. It is a single offer, a single promise, and a single form. The reader should be able to understand what they're getting and why they want it in under 10 seconds.

---

## INPUT VARIABLES

| Variable | Purpose |
|---|---|
| `lead_magnet_name` | The name of the free offer |
| `target_audience` | Who this is specifically for |
| `primary_benefit` | The single most valuable outcome they get |
| `bonuses` | Any additional items included (optional) |

---

## STEP 01 — INPUT EVALUATION & RECOMMENDATIONS

Before building anything, Jake evaluates the inputs and outputs a recommendation block. This removes guesswork for the user and ensures the page is calibrated to the right audience and niche before a single word of copy is written.

### What to Evaluate

**1. Headline Angle Recommendation**

Based on the lead magnet, audience, and primary benefit, recommend which headline formula to lead with and why:

| Niche / Situation | Recommended Angle |
|---|---|
| Skeptical or professional audience (finance, B2B, legal) | Formula A — Direct Offer (clarity over cleverness) |
| Emotional or transformation niche (fitness, relationships, mindset) | Formula B — Bold Promise (outcome-forward) |
| Saturated market or jaded audience | Formula C — Curiosity Gap (pattern interrupt first) |
| Beginners or first-time buyers | Formula A or B — avoid curiosity gaps that confuse |
| Strong social proof or numbers available | Formula B or C — lead with the proof angle |

**2. Lead Magnet Format Assessment**

Evaluate whether the lead magnet name and benefit are strong enough to convert on their own. If not, flag it before building.

- If the name is vague (e.g. "Free Guide to Marketing") — recommend a rename with more specificity
- If the primary benefit is weak or generic — suggest a sharper angle before proceeding
- If bonuses outshine the main offer — flag this as a structural problem

**3. Bullet Priority Recommendation**

Based on the inputs, identify which benefit angle should lead the bullet stack:
- Speed/quick win → lead with the fastest result
- Simplicity → lead with the ease or beginner-friendliness
- Credibility → lead with the proof or numbers
- Exclusivity → lead with what they can't get elsewhere

### Recommendation Output Format

```
## INPUT EVALUATION
---
Headline Angle: [Formula A / B / C] — [1–2 sentence reason]
Lead Magnet Strength: [Strong / Needs Refinement] — [note if rename or sharpening needed]
Bullet Lead: [Speed / Simplicity / Credibility / Exclusivity] — [reason]
---
```

Output this block first. Then proceed to build the full page.

---

## SECTION 01 — HEADLINE

**Goal:** Communicate exactly what the reader gets and make them want it immediately.

**Output: 3 headline variants**

Every headline must answer the reader's first question: *"What is this and why do I want it?"*

### Headline Formula Options

**Formula A — The Direct Offer**
```
Free [Format]: [Specific Outcome] for [Audience]
```
*Example: "Free Checklist: How To Launch Your First Offer In 7 Days (Even If You Have No Audience)"*

**Formula B — The Bold Promise**
```
[Specific Result] Without [Common Pain / Obstacle]
```
*Example: "Get Your First 100 Email Subscribers Without Running A Single Ad"*

**Formula C — The Curiosity Gap**
```
The [Adjective] [Format] That [Unexpected Outcome]
```
*Example: "The 3-Page Document That Helped 200 Freelancers Double Their Rates"*

### Headline Rules
- Every variant must be specific — no vague promises
- Include the audience identity in at least one variant
- Include the format (checklist, guide, video, template, etc.) in at least one variant
- No headline should exceed 15 words
- Do not repeat the same angle across all 3 variants — each must take a different approach
- Label each variant clearly: `Headline Option A`, `Headline Option B`, `Headline Option C`

---

## SECTION 02 — SUB-HEADLINE

**Goal:** Add one layer of context or credibility that reinforces the headline.

**Output: 1 sub-headline**

```
[1–2 sentences — expands on the promise or adds specificity]
```

**Rules:**
- Must add new information — do not restate the headline
- Can name who it's for, how fast they get results, or what makes this different
- Keep it under 25 words
- If the headline names the audience, the sub-headline should name the outcome — and vice versa

**Examples:**
- "A step-by-step framework used by 1,400+ solopreneurs to go from idea to live offer in a single afternoon."
- "Works for complete beginners. No tech skills required. Instant download."
- "Built specifically for coaches, consultants, and course creators who are done overthinking and ready to move."

---

## SECTION 03 — BULLET BENEFIT STACK

**Goal:** Give the reader 3–5 specific reasons to hand over their email. Each bullet is a mini-promise.

**Output: 3–5 bullets**

### Bullet Structure

Every bullet must follow this format:
```
[What they get] — so they can [specific benefit or outcome]
```

Or the discovery variant:
```
[How to / The secret to / Why] [specific thing] — [payoff]
```

### Bullet Rules
- 3 bullets minimum, 5 maximum — do not pad with weak points
- Each bullet must stand alone — if you removed the others, this one still converts
- Lead with the most compelling bullet — do not save the best for last
- Specificity beats vagueness every time:
  - Weak: "Learn how to grow your email list"
  - Strong: "The exact 3-step sequence that adds 50–100 subscribers per week without paid ads"
- If bonuses are provided, give each bonus its own bullet with a benefit attached — not just a name
- No bullet should exceed 20 words

### Bullet Formatting
Use a consistent visual marker — checkmarks, arrows, or dots. Label the format in the output so the deployment team knows what to render.

---

## SECTION 04 — FORM COPY

**Goal:** Make filling out the form feel like the obvious next move.

**Output: form field label + instructions**

### Form Field Label
```
[Field label for email input]
```

**Rules:**
- Do not just say "Email Address" — add a micro-benefit or action
- Examples:
  - "Enter your best email for instant access"
  - "Where should we send it?"
  - "Your free [lead magnet name] goes here"
- First name field (if used): "First name" is fine — keep it simple

### Form Instruction Line (optional)
A single line above or beside the form that creates forward momentum:
```
[1 line — tells them what happens when they submit]
```
- Example: "Drop your email below and get instant access."
- Example: "Enter your details and we'll send it right now."

---

## SECTION 05 — CTA BUTTON TEXT

**Goal:** Make clicking feel like gaining something, not giving something up.

**Output: 3 CTA button text variants**

### Rules
- Every variant must be action + outcome focused
- Never use: "Submit," "Sign Up," "Subscribe," "Click Here"
- The reader should feel like they're getting something when they click
- Keep it under 6 words
- Label each: `CTA Option A`, `CTA Option B`, `CTA Option C`

### Strong CTA Patterns
```
Send Me [The Thing]
Get Instant Access
Yes, I Want [Outcome]
Give Me The [Format]
Start [Outcome] Now
Grab My Free [Thing]
```

**Examples:**
- "Send Me The Checklist"
- "Yes, I Want In"
- "Get My Free Blueprint Now"

---

## SECTION 06 — MICRO REASSURANCE LINE

**Goal:** Remove the last micro-hesitation before they hit submit.

**Output: 1 line, placed below the CTA button**

**Rules:**
- Addresses the most common objection for email opt-ins: spam, commitment, or privacy
- Keep it under 12 words
- Use plain, casual language — not legal-speak
- Examples:
  - "No spam. Unsubscribe anytime. We respect your inbox."
  - "100% free. No credit card. Cancel anytime."
  - "We don't share your info. Ever."
  - "Instant access. No strings attached."

---

## BONUS HANDLING

If bonuses are provided, integrate them as follows:

- Add each bonus as its own bullet in Section 03 with a benefit line attached
- If 3+ bonuses exist, consider a dedicated "Also Included" subsection after the main bullets:

```
## ALSO INCLUDED
- [Bonus name] — [benefit]
- [Bonus name] — [benefit]
```

**Rule:** Bonuses must feel like additions to an already compelling offer — not the reason to opt in. If the main offer isn't strong enough on its own, more bonuses won't fix it.

---

## WHAT THIS PAGE MUST NOT CONTAIN

The following elements do not belong on an opt-in page. If Jake is tempted to add them — don't.

- Long paragraphs of body copy
- Objection handling sections
- Price anchoring or value stacks
- Testimonials (unless it's a single short pull-quote — max 1)
- Navigation links or exit paths
- Multiple offers or CTAs
- Anything that requires scrolling to reach the form on desktop

**The form should be visible above the fold on desktop. Always.**

---

## OUTPUT FORMAT

Deliver all sections clearly labeled:

```
## HEADLINE OPTIONS
---
Headline Option A: [copy]
Headline Option B: [copy]
Headline Option C: [copy]
---

## SUB-HEADLINE
---
[copy]
---

## BULLET BENEFIT STACK
---
[bullets]
---

## FORM COPY
---
Field label: [copy]
Instruction line: [copy]
---

## CTA BUTTON OPTIONS
---
CTA Option A: [copy]
CTA Option B: [copy]
CTA Option C: [copy]
---

## MICRO REASSURANCE
---
[copy]
---
```

Deliver all variants. Do not pick one and omit the others — the user selects from the options provided.

---

*License: Open — any agent may use this skill*
*Created: 2026-05-21*
