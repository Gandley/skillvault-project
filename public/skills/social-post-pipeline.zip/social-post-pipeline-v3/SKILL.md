---
name: social-post-pipeline
description: >
  Telegram-based social media pipeline: Generate AI posts with images → Approve via Telegram → Publish to 9+ platforms via Blotato.
  No Control Board. No PostStream. Everything runs through Telegram.
  Activate when someone types /social post pipeline, /social post search, or /social post publish.
---

# Social Post Pipeline v3.1.0

Full social post lifecycle pipeline via Telegram + Blotato. No external approval dashboards required.

```
[Any command — first use]
        ↓
Setup Wizard (runs ONCE only, never again):
  → Telegram bot token + chat ID
  → Blotato API key + fetch connected accounts
  → OpenRouter API key + balance check
  → Default topic + platforms + image tier
  → Config saved to disk
        ↓
[Subsequent runs — wizard skipped entirely]
        ↓
[/social post pipeline]
        ↓
Stage 1: Generate posts (text + image via OpenRouter Python script)
        ↓
Telegram: shows each post with image → approve/reject
        ↓
Stage 2: Publish approved posts to selected platforms via Blotato
        ↓
Telegram: delivery confirmation with results
```

---

## Trigger

`/social post pipeline`

**Commands:**
- `/social post pipeline` → Full pipeline
- `/social post search` → Stage 1 only (generate + approve via Telegram)
- `/social post publish` → Stage 2 only (publish approved posts via Blotato)

---

## Installation Success Message

```
📱 Social Post Pipeline v3.1.0 Installed!

Telegram-based pipeline. No dashboards. No external approval tools.

🤖 GENERATE → AI writes posts + images for any topic
✅ APPROVE  → Review each post in Telegram, reply approve/reject
🚀 PUBLISH  → Auto-publish to 9+ platforms via Blotato

Run /social post pipeline to get started.
First run will walk you through a one-time setup wizard.
```

---

## Setup Wizard (First Use Only)

**Trigger:** Runs automatically on ANY first command if `config.json` does not exist.
**Never runs again** once config is saved.

```powershell
$configPath = "$env:USERPROFILE\.openclaw\workspace\social_post_pipeline\config.json"
$configExists = Test-Path $configPath

if (-not $configExists) {
    # Run full setup wizard
}
```

### Wizard Step 1: Telegram

> "👋 Welcome to Social Post Pipeline!
>
> Let's get you set up. This only takes a minute and you'll never be asked again.
>
> **Step 1 of 4 — Telegram**
>
> I need your Telegram bot to send you posts for approval.
>
> **Don't have a bot yet?**
> 1. Open Telegram → search @BotFather
> 2. Send /newbot → follow prompts → copy your token
>
> **Already have a bot?** Paste your token below."

```powershell
# Save token
$botToken = "{user_input}"
Add-Content -Path "$env:USERPROFILE\.openclaw\workspace\.env.personal" -Value "TELEGRAM_BOT_TOKEN=$botToken"

# Auto-fetch chat ID
$updates = Invoke-RestMethod -Uri "https://api.telegram.org/bot$botToken/getUpdates"
$chatId = $updates.result[-1].message.chat.id

if (-not $chatId) {
    # Prompt user to send any message to their bot first, then retry
    Write-Host "Please send any message to your bot in Telegram, then press Enter to continue..."
    Read-Host
    $updates = Invoke-RestMethod -Uri "https://api.telegram.org/bot$botToken/getUpdates"
    $chatId = $updates.result[-1].message.chat.id
}

Add-Content -Path "$env:USERPROFILE\.openclaw\workspace\.env.personal" -Value "TELEGRAM_CHAT_ID=$chatId"
```

> "✅ Telegram connected! (Chat ID: {chatId})"

---

### Wizard Step 2: Blotato

> "**Step 2 of 4 — Blotato (Social Publishing)**
>
> Blotato publishes your posts to Instagram, X, LinkedIn, TikTok, and more.
>
> Get your API key at: https://my.blotato.com/settings → API
>
> Paste your Blotato API key:"

```powershell
$blotatoKey = "{user_input}"
Add-Content -Path "$env:USERPROFILE\.openclaw\workspace\.env.personal" -Value "BLOTATO_API_KEY=$blotatoKey"

# Fetch and display connected accounts
$accounts = Invoke-RestMethod -Uri "https://backend.blotato.com/v2/users/me/accounts" `
    -Headers @{ "blotato-api-key" = $blotatoKey }
```

Display connected accounts:
> "Connected accounts found:
> 1. Instagram - @{handle}
> 2. X/Twitter - @{handle}
> 3. LinkedIn - {name}
> ...
>
> Which platforms do you want to publish to by default?
> (Enter numbers separated by commas, e.g. 1,2,3)"

Save selected platform `accountId`s + platform names to config.

> "✅ Blotato connected! {n} platforms selected."

---

### Wizard Step 3: OpenRouter

> "**Step 3 of 4 — OpenRouter (AI Content Generation)**
>
> OpenRouter generates your post text and images. Text is always FREE.
> Images cost $0.003–$0.20 each depending on quality tier.
>
> Get your API key at: https://openrouter.ai → API Keys
>
> Paste your OpenRouter API key:"

```powershell
$openrouterKey = "{user_input}"
Add-Content -Path "$env:USERPROFILE\.openclaw\workspace\.env.personal" -Value "OPENROUTER_API_KEY=$openrouterKey"

# Validate key + check balance
$env:OPENROUTER_API_KEY = $openrouterKey
$scriptPath = "$env:USERPROFILE\.openclaw\workspace\skills\social-post-pipeline\scripts\social_post_generator.py"
& python $scriptPath validate-key
& python $scriptPath check-balance
```

> "✅ OpenRouter connected! Balance: ${balance}"

---

### Wizard Step 4: Defaults

> "**Step 4 of 4 — Your Defaults**
>
> These save your preferences so the pipeline runs faster each time.
> You can change them anytime."

Ask in sequence:

1. > "What topic should I create posts about by default?
   > (e.g. 'AI tools', 'marketing tips', 'fitness motivation')"
   - Save as `default_topic`

2. > "How many posts per run? (recommended: 3–5)"
   - Save as `default_count`

3. > "Default image quality tier:
   > 1. 💰 Budget — $0.003/image (fast, good quality)
   > 2. ⭐ Standard — $0.05/image (professional quality)
   > 3. 🏆 Premium — $0.20/image (best quality)
   >
   > Recommended: Budget to start"
   - Save as `default_image_tier`

---

### Save Config

```powershell
$config = @{
    setup_complete    = $true
    default_topic     = "{topic}"
    default_count     = {count}
    default_image_tier = "{tier}"
    platforms         = @(
        @{ accountId = "{id}"; platform = "{name}"; handle = "{handle}" }
    )
    approved_posts    = @()
    cron_ids          = @{}
} | ConvertTo-Json -Depth 5

New-Item -ItemType Directory -Force -Path "$env:USERPROFILE\.openclaw\workspace\social_post_pipeline" | Out-Null
$config | Set-Content "$env:USERPROFILE\.openclaw\workspace\social_post_pipeline\config.json"
```

Send Telegram confirmation:
```powershell
Invoke-RestMethod -Uri "https://api.telegram.org/bot$botToken/sendMessage" -Method POST -Body @{
    chat_id    = $chatId
    text       = "✅ Social Post Pipeline is ready!`n`nI'll send you posts here for approval. Just reply approve or reject to each one.`n`nStarting your first pipeline now..."
    parse_mode = "Markdown"
}
```

> "🎉 Setup complete! Starting pipeline..."

---

## Command: `/social post pipeline`

**Check setup first:**
```powershell
$config = Get-Content "$env:USERPROFILE\.openclaw\workspace\social_post_pipeline\config.json" -ErrorAction SilentlyContinue | ConvertFrom-Json
if (-not $config -or -not $config.setup_complete) { # Run setup wizard }
```

Then runs Stage 1 → Stage 2 in sequence.

---

## Command: `/social post search`

**Purpose:** Stage 1 — Generate posts, send to Telegram for approval

**Check setup first** (same as above).

### Step 1: Load config or prompt reconfigure

Show current defaults:
> "Current config:
> Topic: {default_topic}
> Platforms: {platforms}
> Posts: {default_count}
> Image tier: {default_image_tier}
>
> 1. 🚀 Run with current config
> 2. ⚙️ Change for this run only
> 3. 🔧 Update defaults"

### Step 2: Cost estimate + confirm
```
💰 Cost Estimate:
• Posts: {count}
• Text: FREE
• Images: {count} × ${cost} = ${total}
• Total: ~${total}

Proceed? (yes/no)
```

### Step 3: Check + install Python
```powershell
try {
    $v = & python --version 2>$null
    if ($LASTEXITCODE -ne 0) { throw }
} catch {
    Write-Host "⚠️ Python not found. Installing Python 3.12..."
    Invoke-WebRequest -Uri "https://www.python.org/ftp/python/3.12.3/python-3.12.3-amd64.exe" -OutFile "$env:TEMP\python-installer.exe"
    Start-Process "$env:TEMP\python-installer.exe" -ArgumentList "/quiet InstallAllUsers=1 PrependPath=1" -Wait
    $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
    Write-Host "✅ Python installed"
}
```

### Step 4: Generate posts via Python script
```powershell
$env:OPENROUTER_API_KEY = (Get-Content $envPath | Select-String "OPENROUTER_API_KEY=").ToString().Split("=")[1]
$scriptPath = "$env:USERPROFILE\.openclaw\workspace\skills\social-post-pipeline\scripts\social_post_generator.py"

& python $scriptPath generate-content --topic "{topic}"
# Returns JSON: title, description, caption, image_prompt

& python $scriptPath generate-image --prompt "{image_prompt}" --tier {tier}
# Returns: path to PNG file
```

**Image tiers:**
| Tier | Model | Cost |
|------|-------|------|
| budget | `google/gemini-2.5-flash-image` | $0.003 |
| standard | `google/gemini-3.1-flash-image-preview` | $0.05 |
| premium | `google/gemini-3-pro-image-preview` | $0.20 |

### Step 5: Send to Telegram for approval
```powershell
$botToken = (Get-Content $envPath | Select-String "TELEGRAM_BOT_TOKEN=").ToString().Split("=")[1]
$chatId   = (Get-Content $envPath | Select-String "TELEGRAM_CHAT_ID=").ToString().Split("=")[1]

# Send photo + caption for each post
Invoke-RestMethod -Uri "https://api.telegram.org/bot$botToken/sendPhoto" -Method POST -Body @{
    chat_id    = $chatId
    photo      = (Get-Item $imagePath)
    caption    = "📱 *Post {n} of {total}*`n`n*{title}*`n`n{caption}`n`nPlatforms: {platforms}`n`nReply *approve* or *reject*"
    parse_mode = "Markdown"
}

# Poll for reply (5 min timeout per post)
$timeout = 300
$start   = Get-Date
while ((Get-Date) -lt $start.AddSeconds($timeout)) {
    $updates = Invoke-RestMethod -Uri "https://api.telegram.org/bot$botToken/getUpdates?offset=$offset"
    $reply   = $updates.result | Where-Object { $_.message.text -match "^(approve|reject)$" } | Select-Object -Last 1
    if ($reply) {
        $decision = $reply.message.text.ToLower()
        $offset   = $reply.update_id + 1
        break
    }
    Start-Sleep -Seconds 3
}
```

- `approve` → add to `$approvedPosts`
- `reject` / timeout → skip

### Step 6: Save approved posts + summary
```powershell
$config.approved_posts = $approvedPosts
$config | ConvertTo-Json -Depth 10 | Set-Content $configPath
```

Telegram summary:
```
✅ Approval complete
• Approved: X posts
• Rejected: Y posts

Starting /social post publish...
```

### Step 7: Cron scheduling (optional)
> "Schedule future post generation?
> - **one-time** — Run manually
> - **every 6h** — Every 6 hours
> - **every 24h** — Daily
> - **skip**"

If recurring → delegate to cron-scheduler:
- Name: `social-post-search`
- Payload: `/social post search`
- Channel: telegram
- To: `$chatId`

---

## Command: `/social post publish`

**Purpose:** Stage 2 — Publish approved posts via Blotato

**Check setup first.**

### Step 1: Load approved posts
```powershell
$config = Get-Content $configPath | ConvertFrom-Json
$posts  = $config.approved_posts
```

If empty:
> "No approved posts. Run `/social post search` first."
> Exit

### Step 2: Upload image to Blotato
```powershell
$blotatoKey = (Get-Content $envPath | Select-String "BLOTATO_API_KEY=").ToString().Split("=")[1]

# Upload local image file
$uploadResponse = Invoke-RestMethod -Uri "https://backend.blotato.com/v2/media" `
    -Headers @{ "blotato-api-key" = $blotatoKey } `
    -Method POST `
    -Form @{ file = Get-Item $post.imagePath }

$imageUrl = $uploadResponse.url
```

### Step 3: Publish to each platform
```powershell
foreach ($post in $posts) {
    foreach ($platform in $config.platforms) {
        $body = @{
            post = @{
                accountId = $platform.accountId
                content   = @{
                    text      = $post.caption
                    mediaUrls = @($imageUrl)
                    platform  = $platform.platform
                }
                target    = @{
                    targetType = $platform.platform
                }
            }
        } | ConvertTo-Json -Depth 6

        Invoke-RestMethod `
            -Uri "https://backend.blotato.com/v2/posts" `
            -Headers @{ "blotato-api-key" = $blotatoKey; "Content-Type" = "application/json" } `
            -Method POST `
            -Body $body

        Write-Host "✅ Published: $($post.title) → $($platform.platform)"
    }
}
```

### Step 4: Telegram confirmation
```powershell
$summary = "🚀 *All posts published!*`n`n"
foreach ($post in $posts) { $summary += "• $($post.title)`n" }
$summary += "`nPlatforms: {platforms}`nTotal: {count} posts"

Invoke-RestMethod -Uri "https://api.telegram.org/bot$botToken/sendMessage" -Method POST -Body @{
    chat_id    = $chatId
    text       = $summary
    parse_mode = "Markdown"
}
```

### Step 5: Cron scheduling (optional)
> "Schedule automatic publishing?
> - **one-time**
> - **every 15m**
> - **every 30m**
> - **every 1h**
> - **skip**"

If recurring → delegate to cron-scheduler:
- Name: `social-post-publish`
- Payload: `/social post publish`
- Channel: telegram
- To: `$chatId`

---

## Cron-Scheduler Integration

```powershell
if (!(Test-Path "$env:USERPROFILE\.openclaw\workspace\skills\cron-scheduler")) {
    Expand-Archive `
        -Path "$env:USERPROFILE\.openclaw\workspace\skills\social-post-pipeline\bundled\cron-scheduler.zip" `
        -DestinationPath "$env:USERPROFILE\.openclaw\workspace\skills\cron-scheduler" -Force
    Write-Host "✅ cron-scheduler installed"
}
```

---

## Full Pipeline Summary

| Stage | What happens |
|-------|-------------|
| Setup (first use only) | Telegram + Blotato + OpenRouter setup → save config |
| `/social post search` | Load config → generate posts → send to Telegram → approve/reject → save approved |
| `/social post publish` | Load approved → upload image → publish via Blotato → Telegram confirmation |

---

## File Structure

```
~/.openclaw/workspace/
  .env.personal                              ← TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, BLOTATO_API_KEY, OPENROUTER_API_KEY
  skills/social-post-pipeline/
    SKILL.md                                 ← This file
    bundled/
      cron-scheduler.zip
    scripts/
      social_post_generator.py               ← OpenRouter content + image generation
  social_post_pipeline/
    config.json                              ← setup_complete, defaults, platforms, approved_posts, cron_ids
    images/
      {topic}-{timestamp}.png
```

---

## Notes

- **Setup wizard runs once** — triggered automatically on first use, never again after `setup_complete: true`
- **No Control Board** — all approval in Telegram
- **No PostStream** — Blotato handles 9+ platforms via one API
- **Telegram config shared** — if bot already set up from another skill, wizard skips Telegram step automatically
- **Lazy Python install** — auto-installs Python 3.12 if missing
- **All credentials in `.env.personal`** — never hardcoded, never asked twice
