#!/usr/bin/env python3
"""
openrouter_generate.py — Production-grade OpenRouter API engine for the
content-creator-godfather OpenClaw skill.

The SINGLE engine that handles ALL 60+ content creation commands across 12
social media platforms.  Uses ONLY the OpenRouter API (https://openrouter.ai)
via Python standard library (urllib).  No pip packages required.

Features:
  - Smart Model Routing: Automatically picks the best model for each use case
  - Retry Cascade: Falls back through cheaper models on failure
  - Cost Tracking: Logs every generation to spending history
  - 12 Platforms: Instagram, Facebook, Twitter/X, LinkedIn, TikTok, YouTube,
    Pinterest, Threads, Bluesky, Snapchat, WhatsApp, Google Ads

Usage:
  python3 scripts/openrouter_generate.py <command> [options]

Environment:
  OPENROUTER_API_KEY   Required.  Your OpenRouter API key.

Author:  Content Creator Godfather Skill
License: Proprietary
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path
from typing import Any

# ═══════════════════════════════════════════════════════════════════════════════
# CONSTANTS
# ═══════════════════════════════════════════════════════════════════════════════

OPENROUTER_BASE_URL   = "https://openrouter.ai/api/v1"
CHAT_COMPLETIONS_URL  = f"{OPENROUTER_BASE_URL}/chat/completions"
VIDEO_GENERATION_URL  = "https://openrouter.ai/api/alpha/videos"
AUTH_CHECK_URL        = f"{OPENROUTER_BASE_URL}/auth/key"

DATA_DIR      = Path.home() / ".openclaw-content-creator"
CONTENT_DIR   = DATA_DIR / "content"
CONFIG_DIR    = DATA_DIR / "config"
HISTORY_FILE  = DATA_DIR / "history.json"
SPENDING_FILE = DATA_DIR / "spending.json"
PREFS_FILE    = CONFIG_DIR / "preferences.json"
PROVIDER_FILE = CONFIG_DIR / "provider.json"
PLAN_FILE     = CONFIG_DIR / "content-plan.json"

SCRIPT_PATH = "/home/ubuntu/skills/content-creator-godfather/scripts/openrouter_generate.py"

# ═══════════════════════════════════════════════════════════════════════════════
# MODEL REGISTRIES  (only verified-working models)
# ═══════════════════════════════════════════════════════════════════════════════

FREE_TEXT_MODELS = {
    "qwen/qwen3.6-plus:free":                {"name": "Qwen 3.6 Plus (Free)",           "context": "1M",   "best_for": "Best overall, marketing copy"},
    "openrouter/free":                        {"name": "OpenRouter Auto-Free",            "context": "var",  "best_for": "Auto-selects best free model"},
    "nvidia/nemotron-3-super:free":           {"name": "NVIDIA Nemotron 3 Super (Free)",  "context": "262K", "best_for": "Complex planning, reasoning"},
    "arcee-ai/trinity-large-preview:free":    {"name": "Arcee Trinity Large (Free)",      "context": "131K", "best_for": "Creative writing, storytelling"},
    "stepfun/step-3.5-flash:free":            {"name": "StepFun Step 3.5 Flash (Free)",   "context": "256K", "best_for": "Fast reasoning model"},
    "openai/gpt-oss-120b:free":               {"name": "OpenAI GPT-OSS 120B (Free)",      "context": "131K", "best_for": "High-reasoning, agentic tasks"},
    "openai/gpt-oss-20b:free":                {"name": "OpenAI GPT-OSS 20B (Free)",       "context": "131K", "best_for": "Fast, lightweight tasks"},
    "meta-llama/llama-3.3-70b-instruct:free": {"name": "Meta Llama 3.3 70B (Free)",       "context": "66K",  "best_for": "Instruction following"},
    "z-ai/glm-4.5-air:free":                  {"name": "Z.ai GLM 4.5 Air (Free)",         "context": "131K", "best_for": "Hybrid reasoning modes"},
    "minimax/minimax-m2.5:free":              {"name": "MiniMax M2.5 (Free)",             "context": "197K", "best_for": "Real-world productivity"},
    "nvidia/nemotron-nano-9b-v2:free":        {"name": "NVIDIA Nemotron Nano 9B (Free)",  "context": "128K", "best_for": "Lightweight reasoning"},
    "qwen/qwen3-coder-480b-a35b:free":        {"name": "Qwen3 Coder 480B (Free)",         "context": "262K", "best_for": "Code generation"},
    "qwen/qwen3-next-80b-a3b-instruct:free":  {"name": "Qwen3 Next 80B (Free)",           "context": "262K", "best_for": "Fast, stable responses"},
}

# ── Image Models ──────────────────────────────────────────────────────────────
# Two API formats:
#   "text+image" models → modalities: ["image", "text"]  (can return text alongside image)
#   "image-only" models → modalities: ["image"]           (pure image generators)

IMAGE_MODELS = {
    "budget": {
        "google/gemini-2.5-flash-image": {
            "name": "Nano Banana (Gemini 2.5 Flash)", "cost_per_image": 0.003,
            "api_type": "text+image", "speed": "fast", "text_rendering": "excellent",
            "artistic": "good", "notes": "BEST VALUE — cheapest, fastest, great text-in-image",
            "verified": True,
        },
        "bytedance-seed/seedream-4.5": {
            "name": "Seedream 4.5", "cost_per_image": 0.04,
            "api_type": "text+image", "speed": "fast", "text_rendering": "good",
            "artistic": "excellent", "notes": "Fast, artistic, multi-image composition",
            "verified": True,
        },
        "black-forest-labs/flux.2-klein-4b": {
            "name": "FLUX.2 Klein 4B", "cost_per_image": 0.014,
            "api_type": "image-only", "speed": "fast", "text_rendering": "poor",
            "artistic": "excellent", "notes": "Beautiful artistic images, no text rendering",
            "verified": True,
        },
    },
    "standard": {
        "google/gemini-3.1-flash-image-preview": {
            "name": "Nano Banana 2 (Gemini 3.1 Flash)", "cost_per_image": 0.05,
            "api_type": "text+image", "speed": "medium", "text_rendering": "excellent",
            "artistic": "excellent", "notes": "Pro-level quality, great text rendering",
            "verified": True,
        },
        "black-forest-labs/flux.2-pro": {
            "name": "FLUX.2 Pro", "cost_per_image": 0.03,
            "api_type": "image-only", "speed": "medium", "text_rendering": "poor",
            "artistic": "excellent", "notes": "High-fidelity artistic images",
            "verified": True,
        },
        "black-forest-labs/flux.2-flex": {
            "name": "FLUX.2 Flex", "cost_per_image": 0.06,
            "api_type": "image-only", "speed": "slow", "text_rendering": "poor",
            "artistic": "excellent", "notes": "Multi-reference editing, flexible control",
            "verified": True,
        },
    },
    "premium": {
        "google/gemini-3-pro-image-preview": {
            "name": "Nano Banana Pro (Gemini 3 Pro)", "cost_per_image": 0.20,
            "api_type": "text+image", "speed": "slow", "text_rendering": "best",
            "artistic": "excellent", "notes": "Industry-leading quality and text rendering",
            "verified": True,
        },
        "openai/gpt-5-image-mini": {
            "name": "GPT-5 Image Mini", "cost_per_image": 0.10,
            "api_type": "text+image", "speed": "slow", "text_rendering": "excellent",
            "artistic": "excellent", "notes": "OpenAI quality, slow but excellent",
            "verified": True,
        },
        "black-forest-labs/flux.2-max": {
            "name": "FLUX.2 Max", "cost_per_image": 0.07,
            "api_type": "image-only", "speed": "medium", "text_rendering": "poor",
            "artistic": "best", "notes": "Best FLUX model, stunning artistic quality",
            "verified": True,
        },
    },
}

VIDEO_MODELS = {
    "budget": {
        "alibaba/wan-2.6": {
            "name": "Wan 2.6 (480p)", "cost_per_second": 0.04,
            "resolution": "480p", "notes": "Cheapest video, good for drafts",
            "verified": True,
        },
    },
    "standard": {
        "alibaba/wan-2.6:720": {
            "name": "Wan 2.6 (720p)", "cost_per_second": 0.08,
            "resolution": "720p", "notes": "Good quality, affordable",
            "verified": True,
        },
        "bytedance/seedance-1-5-pro": {
            "name": "Seedance 1.5 Pro", "cost_per_second": 0.24,
            "resolution": "1080p", "notes": "Cinematic quality, V2A capable",
            "verified": True,
        },
    },
    "premium": {
        "google/veo-3.1:no-audio": {
            "name": "Veo 3.1 (no audio)", "cost_per_second": 0.20,
            "resolution": "1080p", "notes": "Google quality, no audio track",
            "verified": True,
        },
        "openai/sora-2-pro": {
            "name": "Sora 2 Pro", "cost_per_second": 0.30,
            "resolution": "720p", "notes": "OpenAI cinematic quality",
            "verified": True,
        },
        "google/veo-3.1": {
            "name": "Veo 3.1 (with audio)", "cost_per_second": 0.40,
            "resolution": "1080p", "notes": "Best quality with generated audio",
            "verified": True,
        },
    },
}

DEFAULT_TEXT_MODEL = "qwen/qwen3.6-plus:free"

# ═══════════════════════════════════════════════════════════════════════════════
# SMART MODEL ROUTING
# ═══════════════════════════════════════════════════════════════════════════════
#
# The routing engine automatically selects the best model based on:
#   1. Content intent (text-in-image, artistic, general, ads)
#   2. User's tier preference (budget/standard/premium)
#   3. Model capabilities (text rendering, artistic quality, speed)
#
# Intent categories:
#   "text-in-image"  → Quotes, logos, promo graphics, ads with overlay text
#   "artistic"       → Lifestyle, mood boards, aesthetic, editorial
#   "general"        → Standard social media posts, product shots
#   "ads"            → Campaign hero images, high-quality ads
#   "fast"           → High-volume daily posts, drafts, iterations

# Command → intent mapping (determines which model capability matters most)
COMMAND_INTENT: dict[str, str] = {
    # Text-in-image: needs excellent text rendering
    "ig-ad-feed": "ads", "ig-ad-story": "ads",
    "fb-ad-feed": "ads", "fb-ad-story": "ads", "fb-carousel-ad": "ads",
    "tw-ad": "ads", "li-ad": "ads", "pin-ad": "ads", "snap-ad": "ads",
    "gad-display-rect": "ads", "gad-leaderboard": "ads",
    "gad-skyscraper": "ads", "gad-responsive-landscape": "ads",
    "gad-responsive-square": "ads",
    # Artistic: lifestyle, stories, mood-driven
    "ig-story": "artistic", "ig-feed-image": "general",
    "fb-story": "artistic", "fb-cover": "artistic", "fb-event-cover": "artistic",
    "pin-standard": "artistic", "pin-idea": "artistic",
    "snap-story": "artistic", "wa-status": "artistic",
    "yt-banner": "artistic",
    # General: standard posts
    "ig-feed-post": "general", "fb-feed-post": "general", "fb-feed-image": "general",
    "tw-post": "general", "tw-header": "general", "tw-card": "general",
    "li-post": "general", "li-article-cover": "general",
    "li-company-cover": "general", "li-carousel": "general",
    "threads-post": "general", "bsky-post": "general", "bsky-banner": "general",
    "yt-thumbnail": "general", "yt-end-screen": "general",
    "ig-carousel": "general",
}

# Intent → best model per tier (smart defaults)
SMART_ROUTE_TABLE: dict[str, dict[str, str]] = {
    "ads": {
        # Ads need text rendering → always use Gemini (best text-in-image)
        "budget":   "google/gemini-2.5-flash-image",
        "standard": "google/gemini-3.1-flash-image-preview",
        "premium":  "google/gemini-3-pro-image-preview",
    },
    "text-in-image": {
        # Quotes, promo graphics → Gemini excels at text rendering
        "budget":   "google/gemini-2.5-flash-image",
        "standard": "google/gemini-3.1-flash-image-preview",
        "premium":  "google/gemini-3-pro-image-preview",
    },
    "artistic": {
        # Lifestyle, mood boards → FLUX for artistic beauty, Gemini as fallback
        "budget":   "bytedance-seed/seedream-4.5",
        "standard": "black-forest-labs/flux.2-pro",
        "premium":  "black-forest-labs/flux.2-max",
    },
    "general": {
        # Standard posts → cheapest reliable model
        "budget":   "google/gemini-2.5-flash-image",
        "standard": "google/gemini-3.1-flash-image-preview",
        "premium":  "openai/gpt-5-image-mini",
    },
    "fast": {
        # High volume, drafts → absolute cheapest
        "budget":   "google/gemini-2.5-flash-image",
        "standard": "google/gemini-2.5-flash-image",
        "premium":  "google/gemini-3.1-flash-image-preview",
    },
}

# Video routing: short clips → cheap, longer/quality → premium
SMART_VIDEO_ROUTE: dict[str, dict[str, str]] = {
    "draft": {
        "budget": "alibaba/wan-2.6", "standard": "alibaba/wan-2.6",
        "premium": "alibaba/wan-2.6:720",
    },
    "social": {
        "budget": "alibaba/wan-2.6", "standard": "alibaba/wan-2.6:720",
        "premium": "bytedance/seedance-1-5-pro",
    },
    "campaign": {
        "budget": "alibaba/wan-2.6:720", "standard": "bytedance/seedance-1-5-pro",
        "premium": "google/veo-3.1",
    },
}

# Retry cascade — tried in order when primary model fails (cheapest first)
FALLBACK_IMAGE_MODELS = [
    "google/gemini-2.5-flash-image",
    "bytedance-seed/seedream-4.5",
    "black-forest-labs/flux.2-klein-4b",
    "google/gemini-3.1-flash-image-preview",
    "black-forest-labs/flux.2-pro",
    "black-forest-labs/flux.2-max",
    "openai/gpt-5-image-mini",
]

# Free text model fallback list
FALLBACK_TEXT_MODELS = [
    "qwen/qwen3.6-plus:free",
    "meta-llama/llama-3.3-70b-instruct:free",
    "arcee-ai/trinity-large-preview:free",
    "stepfun/step-3.5-flash:free",
    "openai/gpt-oss-120b:free",
    "openai/gpt-oss-20b:free",
    "nvidia/nemotron-3-super:free",
    "minimax/minimax-m2.5:free",
    "nvidia/nemotron-nano-9b-v2:free",
    "qwen/qwen3-next-80b-a3b-instruct:free",
]

# ═══════════════════════════════════════════════════════════════════════════════
# PLATFORM DIMENSIONS  (width, height)
# ═══════════════════════════════════════════════════════════════════════════════

PLATFORM_DIMENSIONS: dict[str, dict[str, tuple[int, int]]] = {
    "instagram": {
        "feed-square": (1080, 1080), "feed-portrait": (1080, 1350),
        "feed-landscape": (1080, 566), "story": (1080, 1920),
        "reel": (1080, 1920), "carousel": (1080, 1080),
        "ad-feed": (1080, 1080), "ad-story": (1080, 1920),
    },
    "facebook": {
        "feed-landscape": (1200, 630), "feed-square": (1080, 1080),
        "story": (1080, 1920), "cover": (820, 312),
        "event-cover": (1920, 1005), "ad-feed": (1200, 628),
        "ad-story": (1080, 1920), "carousel-ad": (1080, 1080),
        "video": (1280, 720),
    },
    "twitter": {
        "post": (1600, 900), "header": (1500, 500),
        "card": (800, 418), "ad": (1200, 675),
    },
    "linkedin": {
        "post": (1200, 628), "article-cover": (1200, 644),
        "company-cover": (1128, 191), "ad": (1200, 628),
        "carousel": (1080, 1350),
    },
    "tiktok": {
        "video": (1080, 1920), "ad": (1080, 1920),
    },
    "youtube": {
        "thumbnail": (1280, 720), "shorts": (1080, 1920),
        "banner": (2560, 1440), "video": (1920, 1080),
        "end-screen": (1920, 1080),
    },
    "pinterest": {
        "standard": (1000, 1500), "idea": (1080, 1920), "ad": (1000, 1500),
    },
    "threads": {
        "post": (1080, 1080),
    },
    "bluesky": {
        "post": (1200, 675), "banner": (1500, 500),
    },
    "snapchat": {
        "story": (1080, 1920), "ad": (1080, 1920),
    },
    "whatsapp": {
        "status": (1080, 1920),
    },
    "google-ads": {
        "display-rect": (300, 250), "leaderboard": (728, 90),
        "skyscraper": (160, 600), "responsive-landscape": (1200, 628),
        "responsive-square": (1200, 1200),
    },
}

# ═══════════════════════════════════════════════════════════════════════════════
# COMMAND → METADATA MAPPING  (platform, content-type, dimensions-key, media)
# ═══════════════════════════════════════════════════════════════════════════════

COMMAND_META: dict[str, dict[str, Any]] = {
    # ── Instagram ──────────────────────────────────────────────────────────
    "ig-feed-post":   {"platform": "instagram", "dim_key": "feed-portrait", "media": "text+image", "label": "Instagram Feed Post"},
    "ig-feed-text":   {"platform": "instagram", "dim_key": None,            "media": "text",       "label": "Instagram Feed Caption"},
    "ig-feed-image":  {"platform": "instagram", "dim_key": "feed-portrait", "media": "image",      "label": "Instagram Feed Image"},
    "ig-story":       {"platform": "instagram", "dim_key": "story",         "media": "image",      "label": "Instagram Story"},
    "ig-reel":        {"platform": "instagram", "dim_key": "reel",          "media": "video",      "label": "Instagram Reel"},
    "ig-carousel":    {"platform": "instagram", "dim_key": "carousel",      "media": "carousel",   "label": "Instagram Carousel"},
    "ig-ad-feed":     {"platform": "instagram", "dim_key": "ad-feed",       "media": "image",      "label": "Instagram Feed Ad"},
    "ig-ad-story":    {"platform": "instagram", "dim_key": "ad-story",      "media": "image",      "label": "Instagram Story Ad"},
    # ── Facebook ───────────────────────────────────────────────────────────
    "fb-feed-post":   {"platform": "facebook", "dim_key": "feed-landscape", "media": "text+image", "label": "Facebook Feed Post"},
    "fb-feed-text":   {"platform": "facebook", "dim_key": None,             "media": "text",       "label": "Facebook Feed Text"},
    "fb-feed-image":  {"platform": "facebook", "dim_key": "feed-square",    "media": "image",      "label": "Facebook Feed Image"},
    "fb-story":       {"platform": "facebook", "dim_key": "story",          "media": "image",      "label": "Facebook Story"},
    "fb-cover":       {"platform": "facebook", "dim_key": "cover",          "media": "image",      "label": "Facebook Cover Photo"},
    "fb-event-cover": {"platform": "facebook", "dim_key": "event-cover",    "media": "image",      "label": "Facebook Event Cover"},
    "fb-ad-feed":     {"platform": "facebook", "dim_key": "ad-feed",        "media": "image",      "label": "Facebook Feed Ad"},
    "fb-ad-story":    {"platform": "facebook", "dim_key": "ad-story",       "media": "image",      "label": "Facebook Story Ad"},
    "fb-carousel-ad": {"platform": "facebook", "dim_key": "carousel-ad",    "media": "carousel",   "label": "Facebook Carousel Ad"},
    "fb-video":       {"platform": "facebook", "dim_key": "video",          "media": "video",      "label": "Facebook Video"},
    # ── Twitter / X ────────────────────────────────────────────────────────
    "tw-post":        {"platform": "twitter", "dim_key": "post",    "media": "text+image", "label": "Tweet with Image"},
    "tw-text":        {"platform": "twitter", "dim_key": None,      "media": "text",       "label": "Text Tweet"},
    "tw-thread":      {"platform": "twitter", "dim_key": None,      "media": "thread",     "label": "Twitter Thread"},
    "tw-header":      {"platform": "twitter", "dim_key": "header",  "media": "image",      "label": "Twitter Header"},
    "tw-card":        {"platform": "twitter", "dim_key": "card",    "media": "image",      "label": "Twitter Card Image"},
    "tw-ad":          {"platform": "twitter", "dim_key": "ad",      "media": "image",      "label": "Twitter Ad"},
    # ── LinkedIn ───────────────────────────────────────────────────────────
    "li-post":          {"platform": "linkedin", "dim_key": "post",          "media": "text+image", "label": "LinkedIn Post"},
    "li-text":          {"platform": "linkedin", "dim_key": None,            "media": "text",       "label": "LinkedIn Text Post"},
    "li-carousel":      {"platform": "linkedin", "dim_key": "carousel",      "media": "carousel",   "label": "LinkedIn Carousel"},
    "li-article-cover": {"platform": "linkedin", "dim_key": "article-cover", "media": "image",      "label": "LinkedIn Article Cover"},
    "li-company-cover": {"platform": "linkedin", "dim_key": "company-cover", "media": "image",      "label": "LinkedIn Company Cover"},
    "li-ad":            {"platform": "linkedin", "dim_key": "ad",            "media": "image",      "label": "LinkedIn Ad"},
    # ── TikTok ─────────────────────────────────────────────────────────────
    "tt-video":  {"platform": "tiktok", "dim_key": "video", "media": "video", "label": "TikTok Video"},
    "tt-ad":     {"platform": "tiktok", "dim_key": "ad",    "media": "video", "label": "TikTok Ad"},
    "tt-text":   {"platform": "tiktok", "dim_key": None,    "media": "text",  "label": "TikTok Caption/Script"},
    # ── YouTube ────────────────────────────────────────────────────────────
    "yt-thumbnail":  {"platform": "youtube", "dim_key": "thumbnail",  "media": "image", "label": "YouTube Thumbnail"},
    "yt-shorts":     {"platform": "youtube", "dim_key": "shorts",     "media": "video", "label": "YouTube Shorts"},
    "yt-banner":     {"platform": "youtube", "dim_key": "banner",     "media": "image", "label": "YouTube Banner"},
    "yt-video":      {"platform": "youtube", "dim_key": "video",      "media": "video", "label": "YouTube Video"},
    "yt-end-screen": {"platform": "youtube", "dim_key": "end-screen", "media": "image", "label": "YouTube End Screen"},
    "yt-script":     {"platform": "youtube", "dim_key": None,         "media": "text",  "label": "YouTube Script"},
    # ── Pinterest ──────────────────────────────────────────────────────────
    "pin-standard": {"platform": "pinterest", "dim_key": "standard", "media": "image", "label": "Pinterest Standard Pin"},
    "pin-idea":     {"platform": "pinterest", "dim_key": "idea",     "media": "image", "label": "Pinterest Idea Pin"},
    "pin-ad":       {"platform": "pinterest", "dim_key": "ad",       "media": "image", "label": "Pinterest Ad Pin"},
    # ── Threads ────────────────────────────────────────────────────────────
    "threads-post": {"platform": "threads", "dim_key": "post", "media": "text+image", "label": "Threads Post"},
    "threads-text": {"platform": "threads", "dim_key": None,   "media": "text",       "label": "Threads Text Post"},
    # ── Bluesky ────────────────────────────────────────────────────────────
    "bsky-post":   {"platform": "bluesky", "dim_key": "post",   "media": "text+image", "label": "Bluesky Post"},
    "bsky-text":   {"platform": "bluesky", "dim_key": None,     "media": "text",       "label": "Bluesky Text Post"},
    "bsky-banner": {"platform": "bluesky", "dim_key": "banner", "media": "image",      "label": "Bluesky Banner"},
    # ── Snapchat ───────────────────────────────────────────────────────────
    "snap-story": {"platform": "snapchat", "dim_key": "story", "media": "image", "label": "Snapchat Story"},
    "snap-ad":    {"platform": "snapchat", "dim_key": "ad",    "media": "image", "label": "Snapchat Ad"},
    # ── WhatsApp ───────────────────────────────────────────────────────────
    "wa-status":  {"platform": "whatsapp", "dim_key": "status", "media": "image", "label": "WhatsApp Status"},
    # ── Google Ads ─────────────────────────────────────────────────────────
    "gad-display-rect":        {"platform": "google-ads", "dim_key": "display-rect",        "media": "image", "label": "Google Display Ad 300x250"},
    "gad-leaderboard":         {"platform": "google-ads", "dim_key": "leaderboard",          "media": "image", "label": "Google Leaderboard 728x90"},
    "gad-skyscraper":          {"platform": "google-ads", "dim_key": "skyscraper",            "media": "image", "label": "Google Skyscraper 160x600"},
    "gad-responsive-landscape": {"platform": "google-ads", "dim_key": "responsive-landscape", "media": "image", "label": "Google Responsive 1200x628"},
    "gad-responsive-square":   {"platform": "google-ads", "dim_key": "responsive-square",    "media": "image", "label": "Google Responsive 1200x1200"},
}

# Platform-specific system prompts for text generation
PLATFORM_PROMPTS: dict[str, str] = {
    "instagram": "You are an expert Instagram copywriter. Write engaging captions with emojis, line breaks for readability, and 10-20 relevant hashtags at the end. Start with a hook that stops the scroll. Keep the voice authentic and community-focused.",
    "facebook":  "You are an expert Facebook copywriter. Write conversational, community-oriented posts. Ask questions to drive engagement. Use 1-2 hashtags maximum. Keep it relatable and shareable.",
    "twitter":   "You are an expert Twitter/X copywriter. Write punchy, thought-provoking tweets under 280 characters. Use 1-2 hashtags maximum. Be conversational and contrarian when appropriate.",
    "linkedin":  "You are an expert LinkedIn copywriter. Write professional, story-driven posts with short paragraphs and line breaks (broetry style). Start with a strong hook, share insight, end with a question. Add 3-5 hashtags at the bottom.",
    "tiktok":    "You are an expert TikTok script writer. Write short, punchy scripts with a hook in the first 3 seconds. Include visual cues in [brackets]. Keep it authentic and trend-aware. Add 3-5 hashtags.",
    "youtube":   "You are an expert YouTube content writer. Write compelling scripts with clear structure: hook, intro, main content, CTA. Include timestamps and visual cues.",
    "pinterest": "You are an expert Pinterest copywriter. Write keyword-rich descriptions that are searchable. Include relevant keywords naturally. Keep it informative and aspirational.",
    "threads":   "You are an expert Threads copywriter. Write conversational, authentic posts. Keep it concise and engaging. Minimal hashtags.",
    "bluesky":   "You are an expert Bluesky copywriter. Write thoughtful, community-focused posts under 300 characters. Be genuine and conversational.",
    "snapchat":  "You are an expert Snapchat content creator. Write casual, fun, ephemeral content. Keep it brief and visually descriptive.",
    "whatsapp":  "You are an expert WhatsApp status writer. Write brief, impactful status updates. Keep it personal and engaging.",
    "google-ads": "You are an expert Google Ads copywriter. Write direct-response ad copy using the PAS framework. Headline under 30 chars, description under 90 chars. Be benefit-focused and include a clear CTA.",
}

# ═══════════════════════════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════════════════════════

def get_api_key() -> str:
    """Return the OpenRouter API key from the environment."""
    key = os.environ.get("OPENROUTER_API_KEY", "").strip()
    if not key:
        print("ERROR: OPENROUTER_API_KEY environment variable is not set.", file=sys.stderr)
        print("Set it with:  export OPENROUTER_API_KEY='sk-or-...'", file=sys.stderr)
        sys.exit(1)
    return key


def api_request(url: str, payload: dict | None = None, method: str = "POST",
                timeout: int = 180) -> dict:
    """Make an authenticated request to the OpenRouter API.  Uses only urllib."""
    api_key = get_api_key()
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type":  "application/json",
        "HTTP-Referer":  "https://openclaw.ai",
        "X-Title":       "content-creator-godfather",
    }
    data = json.dumps(payload).encode("utf-8") if payload else None
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {exc.code}: {body}")
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Network error: {exc.reason}")


def ensure_dirs() -> None:
    """Create the data directory structure."""
    for d in [DATA_DIR, CONTENT_DIR, CONFIG_DIR,
              DATA_DIR / "automations", DATA_DIR / "templates"]:
        d.mkdir(parents=True, exist_ok=True)


def ensure_provider_config() -> None:
    """Save OpenRouter as the ONLY provider on first run."""
    ensure_dirs()
    if not PROVIDER_FILE.exists():
        config = {
            "provider": "openrouter",
            "base_url": "https://openrouter.ai/api/v1",
            "video_url": "https://openrouter.ai/api/alpha/videos",
            "locked": True,
            "note": "OpenRouter is the ONLY provider. This cannot be changed.",
            "configured_at": datetime.utcnow().isoformat() + "Z",
        }
        PROVIDER_FILE.write_text(json.dumps(config, indent=2))


def load_preferences() -> dict:
    ensure_dirs()
    if PREFS_FILE.exists():
        try:
            return json.loads(PREFS_FILE.read_text())
        except (json.JSONDecodeError, OSError):
            pass
    return {"default_tier": "free", "default_text_model": None,
            "default_image_model": None, "default_video_model": None}


def save_preferences(prefs: dict) -> None:
    ensure_dirs()
    PREFS_FILE.write_text(json.dumps(prefs, indent=2))


def load_content_plan() -> dict | None:
    if PLAN_FILE.exists():
        try:
            return json.loads(PLAN_FILE.read_text())
        except (json.JSONDecodeError, OSError):
            pass
    return None


def save_content_plan(plan: dict) -> None:
    ensure_dirs()
    PLAN_FILE.write_text(json.dumps(plan, indent=2))


def resolve_tier(args_tier: str | None) -> str:
    if args_tier:
        return args_tier.lower()
    return load_preferences().get("default_tier", "free").lower()


def resolve_text_model(args_model: str | None = None) -> str:
    if args_model:
        return args_model
    pm = load_preferences().get("default_text_model")
    return pm if pm else DEFAULT_TEXT_MODEL


def smart_route_image(command: str | None, tier: str,
                      user_model: str | None = None) -> str:
    """Smart Model Routing: pick the best image model for the use case.

    Priority order:
      1. Explicit user --model override  (always respected)
      2. User's saved preference          (from set-preferences)
      3. Smart route table                (command intent × tier)
      4. Tier default fallback            (cheapest in tier)
    """
    # 1. Explicit override
    if user_model:
        return user_model

    # 2. Saved preference
    pm = load_preferences().get("default_image_model")
    if pm:
        return pm

    # 3. Smart routing by command intent
    intent = COMMAND_INTENT.get(command, "general") if command else "general"
    effective_tier = tier if tier in ("budget", "standard", "premium") else "budget"
    route = SMART_ROUTE_TABLE.get(intent, SMART_ROUTE_TABLE["general"])
    model = route.get(effective_tier)
    if model:
        return model

    # 4. Tier default fallback
    tier_defaults = {
        "budget": "google/gemini-2.5-flash-image",
        "standard": "google/gemini-3.1-flash-image-preview",
        "premium": "google/gemini-3-pro-image-preview",
    }
    return tier_defaults.get(effective_tier, "google/gemini-2.5-flash-image")


def smart_route_video(command: str | None, tier: str, duration: int = 5,
                      user_model: str | None = None) -> str:
    """Smart Model Routing for video: pick based on quality needs and duration."""
    if user_model:
        return user_model
    pm = load_preferences().get("default_video_model")
    if pm:
        return pm

    # Determine video intent from command and duration
    is_ad = command and "ad" in command
    effective_tier = tier if tier in ("budget", "standard", "premium") else "budget"

    if is_ad or duration > 10:
        intent = "campaign"
    elif duration <= 5:
        intent = "draft"
    else:
        intent = "social"

    route = SMART_VIDEO_ROUTE.get(intent, SMART_VIDEO_ROUTE["social"])
    model = route.get(effective_tier)
    if model:
        return model
    return "alibaba/wan-2.6"


def get_dims(platform: str, dim_key: str | None) -> tuple[int, int]:
    if dim_key is None:
        return (0, 0)
    plat = PLATFORM_DIMENSIONS.get(platform, {})
    return plat.get(dim_key, (1080, 1080))


def get_image_cost(model: str) -> float:
    for tier_models in IMAGE_MODELS.values():
        if model in tier_models:
            return tier_models[model]["cost_per_image"]
    return 0.03


def get_image_api_type(model: str) -> str:
    """Return the API modalities type for an image model."""
    for tier_models in IMAGE_MODELS.values():
        if model in tier_models:
            return tier_models[model].get("api_type", "text+image")
    # Default: if model name contains 'flux' or 'riverflow', it's image-only
    lower = model.lower()
    if "flux" in lower or "riverflow" in lower:
        return "image-only"
    return "text+image"


def get_video_cost(model: str) -> float:
    for tier_models in VIDEO_MODELS.values():
        if model in tier_models:
            return tier_models[model]["cost_per_second"]
    base = model.split(":")[0]
    for tier_models in VIDEO_MODELS.values():
        if base in tier_models:
            return tier_models[base]["cost_per_second"]
    return 0.10


def log_generation(gen_type: str, model: str, cost: float,
                   platform: str, output_path: str) -> None:
    ensure_dirs()
    # History
    history: list = []
    if HISTORY_FILE.exists():
        try:
            history = json.loads(HISTORY_FILE.read_text())
        except (json.JSONDecodeError, OSError):
            pass
    history.append({
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "type": gen_type, "model": model,
        "cost_usd": round(cost, 6), "platform": platform,
        "output": output_path,
    })
    HISTORY_FILE.write_text(json.dumps(history, indent=2))
    # Spending
    spending: dict = {"total_usd": 0.0, "by_type": {}, "by_model": {}}
    if SPENDING_FILE.exists():
        try:
            spending = json.loads(SPENDING_FILE.read_text())
        except (json.JSONDecodeError, OSError):
            pass
    spending["total_usd"] = round(spending.get("total_usd", 0.0) + cost, 6)
    spending.setdefault("by_type", {})[gen_type] = round(
        spending.get("by_type", {}).get(gen_type, 0.0) + cost, 6)
    spending.setdefault("by_model", {})[model] = round(
        spending.get("by_model", {}).get(model, 0.0) + cost, 6)
    SPENDING_FILE.write_text(json.dumps(spending, indent=2))


def save_file(data: bytes | str, path: str) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(data, bytes):
        p.write_bytes(data)
    else:
        p.write_text(data)


def save_metadata(path: str, meta: dict) -> None:
    mp = Path(path).parent / (Path(path).stem + "_metadata.json")
    mp.write_text(json.dumps(meta, indent=2))


def content_dir_today() -> Path:
    d = CONTENT_DIR / datetime.now().strftime("%Y-%m-%d")
    d.mkdir(parents=True, exist_ok=True)
    return d


def ts() -> str:
    return str(int(time.time()))


# ═══════════════════════════════════════════════════════════════════════════════
# RICH OUTPUT FORMATTERS
# ═══════════════════════════════════════════════════════════════════════════════

def fmt_text_post(label: str, caption: str, platform: str) -> None:
    """Print a ready-to-post text-only result."""
    print()
    print(f"  Post Ready for {label}")
    print()
    print("  CAPTION (copy this):")
    print("  " + "\u2500" * 50)
    for line in caption.strip().split("\n"):
        print(f"  {line}")
    print("  " + "\u2500" * 50)
    print()
    print(f"  Ready to post on {platform}! Copy the caption above.")
    print()


def fmt_image_post(label: str, image_path: str, w: int, h: int) -> None:
    """Print a ready-to-post image-only result."""
    print()
    print(f"  Image Ready for {label}")
    print()
    print("  IMAGE:")
    print(f"     File: {image_path}")
    print(f"     Dimensions: {w}x{h}")
    print()
    print(f"  Upload the image above to post.")
    print()


def fmt_text_image_post(label: str, caption: str, image_path: str,
                        w: int, h: int, platform: str) -> None:
    """Print a ready-to-post text + image combined result."""
    print()
    print(f"  Post Ready for {label}")
    print()
    print("  CAPTION (copy this):")
    print("  " + "\u2500" * 50)
    for line in caption.strip().split("\n"):
        print(f"  {line}")
    print("  " + "\u2500" * 50)
    print()
    print("  IMAGE:")
    print(f"     File: {image_path}")
    print(f"     Dimensions: {w}x{h}")
    print()
    print(f"  Ready to post! Copy the caption above and upload the image.")
    print()


def fmt_carousel(label: str, caption: str, slides: list[str],
                 w: int, h: int, platform: str) -> None:
    """Print a ready-to-post carousel result."""
    print()
    print(f"  Carousel Ready for {label}")
    print()
    print("  CAPTION (copy this):")
    print("  " + "\u2500" * 50)
    for line in caption.strip().split("\n"):
        print(f"  {line}")
    print("  " + "\u2500" * 50)
    print()
    print(f"  SLIDES ({len(slides)} images, {w}x{h} each):")
    for i, s in enumerate(slides, 1):
        print(f"     Slide {i}: {s}")
    print()
    print(f"  Upload all slides in order to {platform}.")
    print()


def fmt_video_post(label: str, caption: str | None, video_path: str,
                   w: int, h: int, duration: int) -> None:
    """Print a ready-to-post video result."""
    print()
    print(f"  Video Ready for {label}")
    print()
    if caption:
        print("  CAPTION (copy this):")
        print("  " + "\u2500" * 50)
        for line in caption.strip().split("\n"):
            print(f"  {line}")
        print("  " + "\u2500" * 50)
        print()
    print("  VIDEO:")
    print(f"     File: {video_path}")
    print(f"     Dimensions: {w}x{h}")
    print(f"     Duration: ~{duration}s")
    print()
    print(f"  Upload the video above to post.")
    print()


def fmt_thread(label: str, tweets: list[str]) -> None:
    """Print a ready-to-post thread."""
    print()
    print(f"  Thread Ready for {label}")
    print()
    for i, tweet in enumerate(tweets, 1):
        print(f"  Tweet {i}/{len(tweets)}:")
        print("  " + "\u2500" * 50)
        for line in tweet.strip().split("\n"):
            print(f"  {line}")
        print("  " + "\u2500" * 50)
        print()
    print(f"  Post each tweet in order as a thread.")
    print()


def fmt_cost_estimate(tier: str, model: str, ctype: str, count: int,
                      per_item: float, total: float,
                      monthly: float | None = None) -> None:
    """Print a cost estimate box."""
    print()
    print("+" + "\u2500" * 52 + "+")
    print(f"|{'Cost Estimate':^52}|")
    print("+" + "\u2500" * 52 + "+")
    print(f"| Tier          : {tier:<34}|")
    print(f"| Content type  : {ctype:<34}|")
    print(f"| Model         : {model[:34]:<34}|")
    print(f"| Quantity      : {count:<34}|")
    print(f"| Per item      : ${per_item:<33.4f}|")
    print(f"| Total         : ${total:<33.4f}|")
    if monthly is not None:
        print(f"| Monthly (30d) : ${monthly:<33.4f}|")
        print(f"| Yearly proj.  : ${monthly * 12:<33.4f}|")
    print("+" + "\u2500" * 52 + "+")
    print()


def fmt_tiered_options(ctype: str, count: int = 1, duration: int = 5) -> None:
    """Display all tier options with FREE first."""
    print()
    print("+" + "=" * 58 + "+")
    print(f"|{'Content Generation Options':^58}|")
    print("+" + "=" * 58 + "+")
    if ctype == "text":
        print("|  FREE (Tier 1):                                          |")
        print("|    Model : Qwen 3.6 Plus / OpenRouter Auto-Free          |")
        print("|    Cost  : $0.00 per generation                          |")
        print(f"|    Total : $0.00 for {count} items{' ' * (35 - len(str(count)))}|")
        print("|  15+ free text models available. Text is ALWAYS free.    |")
    elif ctype in ("image", "text-image", "carousel"):
        img_count = count
        print("|  No free image models on OpenRouter.                     |")
        print("|" + "\u2500" * 58 + "|")
        bc = 0.003 * img_count
        print("|  BUDGET (Tier 2):                                        |")
        print("|    Model : Nano Banana (Gemini 2.5 Flash Image)          |")
        print(f"|    Cost  : ~$0.003/image | Total: ${bc:<8.3f}{' ' * (20 - len(f'${bc:<8.3f}'))}           |")
        print("|" + "\u2500" * 58 + "|")
        sc = 0.05 * img_count
        print("|  STANDARD (Tier 3):                                      |")
        print("|    Model : Nano Banana 2 (Gemini 3.1 Flash)              |")
        print(f"|    Cost  : ~$0.050/image | Total: ${sc:<8.3f}{' ' * (20 - len(f'${sc:<8.3f}'))}           |")
        print("|" + "\u2500" * 58 + "|")
        pc = 0.20 * img_count
        print("|  PREMIUM (Tier 4):                                       |")
        print("|    Model : Nano Banana Pro (Gemini 3 Pro)                |")
        print(f"|    Cost  : ~$0.200/image | Total: ${pc:<8.3f}{' ' * (20 - len(f'${pc:<8.3f}'))}           |")
    elif ctype == "video":
        print("|  No free video models on OpenRouter.                     |")
        print("|" + "\u2500" * 58 + "|")
        bc = 0.04 * duration * count
        print("|  BUDGET (Tier 2):                                        |")
        print("|    Model : Wan 2.6 (480p) — $0.04/sec                    |")
        print(f"|    Total : ${bc:<8.3f} for {count}x {duration}s clips{' ' * 25}|")
        print("|" + "\u2500" * 58 + "|")
        sc = 0.08 * duration * count
        print("|  STANDARD (Tier 3):                                      |")
        print("|    Model : Wan 2.6 (720p) — $0.08/sec                    |")
        print(f"|    Total : ${sc:<8.3f} for {count}x {duration}s clips{' ' * 25}|")
        print("|" + "\u2500" * 58 + "|")
        pc = 0.40 * duration * count
        print("|  PREMIUM (Tier 4):                                       |")
        print("|    Model : Veo 3.1 (with audio) — $0.40/sec              |")
        print(f"|    Total : ${pc:<8.3f} for {count}x {duration}s clips{' ' * 25}|")
    print("+" + "=" * 58 + "+")
    print()


# ═══════════════════════════════════════════════════════════════════════════════
# CORE GENERATION FUNCTIONS  (with retry cascade for images)
# ═══════════════════════════════════════════════════════════════════════════════

def generate_text(prompt: str, platform: str, content_type: str = "post",
                  model: str | None = None, extra_instructions: str = "") -> str:
    """Generate text via OpenRouter chat completions with retry cascade."""
    primary = resolve_text_model(model)
    sys_prompt = PLATFORM_PROMPTS.get(platform,
        "You are an expert social media copywriter. Write engaging content.")
    if extra_instructions:
        sys_prompt += f"\n\nAdditional instructions: {extra_instructions}"
    sys_prompt += (
        f"\n\nGenerate a {content_type} for {platform}. "
        "Output ONLY the post content — no explanations, no meta-commentary, "
        "no markdown code fences."
    )

    models_to_try = [primary] + [m for m in FALLBACK_TEXT_MODELS if m != primary]
    last_error = ""

    for i, m in enumerate(models_to_try):
        if i > 0:
            print(f"  Retrying text with model: {m}...", file=sys.stderr)
            time.sleep(1)
        try:
            payload = {
                "model": m,
                "messages": [
                    {"role": "system", "content": sys_prompt},
                    {"role": "user",   "content": prompt},
                ],
                "temperature": 0.8,
                "max_tokens": 2000,
            }
            result = api_request(CHAT_COMPLETIONS_URL, payload)
            msg = result.get("choices", [{}])[0].get("message", {})
            text = msg.get("content") or ""
            if not text and msg.get("reasoning"):
                text = msg["reasoning"]
            if text and isinstance(text, str) and text.strip():
                return text.strip()
            last_error = f"Model {m} returned empty content."
        except RuntimeError as exc:
            last_error = str(exc)
            if "429" in last_error:
                continue
        except Exception as exc:
            last_error = f"Model {m}: {exc}"

    raise RuntimeError(f"Text generation failed with all models. Last error: {last_error}")


def generate_image_with_retry(prompt: str, width: int, height: int,
                              primary_model: str) -> tuple[bytes | None, str, str | None]:
    """Generate an image with automatic retry cascade.

    Returns (image_bytes, model_used, text_response).
    Tries the primary model first, then the fallback list.
    Automatically detects the correct API modalities format per model.
    NEVER suggests using another provider.
    """
    image_prompt = (
        f"{prompt}. The image dimensions should be {width}x{height} pixels "
        f"(aspect ratio {width}:{height}). High resolution, professional quality, "
        f"clean composition."
    )

    models_to_try = [primary_model] + [
        m for m in FALLBACK_IMAGE_MODELS if m != primary_model
    ]
    last_error = ""

    for i, model in enumerate(models_to_try):
        try:
            if i > 0:
                print(f"  Retrying with model: {model}...")

            # Smart modalities selection based on model type
            api_type = get_image_api_type(model)
            if api_type == "image-only":
                modalities = ["image"]
            else:
                modalities = ["image", "text"]

            payload = {
                "model": model,
                "messages": [{"role": "user", "content": image_prompt}],
                "modalities": modalities,
                "temperature": 0.9,
                "max_tokens": 4096,
            }
            result = api_request(CHAT_COMPLETIONS_URL, payload, timeout=240)
            message = result.get("choices", [{}])[0].get("message", {})
            image_data = None
            text_response = None

            # Extract text from content field
            content = message.get("content")
            if isinstance(content, str):
                text_response = content
            elif isinstance(content, list):
                for part in content:
                    if isinstance(part, dict) and part.get("type") == "text":
                        text_response = part.get("text", "")

            # PRIMARY: Check 'images' field (OpenRouter returns images here)
            images_list = message.get("images", [])
            if images_list:
                for img_item in images_list:
                    if isinstance(img_item, dict):
                        url = img_item.get("image_url", {}).get("url", "")
                        if not url and isinstance(img_item.get("image_url"), str):
                            url = img_item["image_url"]
                        if url.startswith("data:"):
                            _, encoded = url.split(",", 1)
                            image_data = base64.b64decode(encoded)
                            break
                        elif url.startswith("http"):
                            req = urllib.request.Request(url)
                            with urllib.request.urlopen(req, timeout=60) as resp:
                                image_data = resp.read()
                            break
                    elif isinstance(img_item, str):
                        if img_item.startswith("data:"):
                            _, encoded = img_item.split(",", 1)
                            image_data = base64.b64decode(encoded)
                            break
                        elif img_item.startswith("http"):
                            req = urllib.request.Request(img_item)
                            with urllib.request.urlopen(req, timeout=60) as resp:
                                image_data = resp.read()
                            break
                        else:
                            try:
                                image_data = base64.b64decode(img_item)
                                break
                            except Exception:
                                pass

            # FALLBACK: Check content list for image_url parts (legacy format)
            if not image_data and isinstance(content, list):
                for part in content:
                    if isinstance(part, dict) and part.get("type") == "image_url":
                        url = part.get("image_url", {}).get("url", "")
                        if url.startswith("data:"):
                            _, encoded = url.split(",", 1)
                            image_data = base64.b64decode(encoded)
                            break

            if image_data:
                return (image_data, model, text_response)
            else:
                last_error = f"Model {model} returned no image data."
                if text_response:
                    last_error += f" Response: {text_response[:200]}"
                print(f"  WARNING: {last_error}", file=sys.stderr)

        except RuntimeError as exc:
            last_error = f"Model {model} failed: {exc}"
            print(f"  WARNING: {last_error}", file=sys.stderr)
        except Exception as exc:
            last_error = f"Model {model} unexpected error: {exc}"
            print(f"  WARNING: {last_error}", file=sys.stderr)

    # ALL models failed
    print(file=sys.stderr)
    print("  Image generation failed with all available OpenRouter models.", file=sys.stderr)
    print(file=sys.stderr)
    print("   Troubleshooting:", file=sys.stderr)
    print(f"   1. Check balance: python3 {SCRIPT_PATH} check-balance", file=sys.stderr)
    print(f"   2. Validate key:  python3 {SCRIPT_PATH} validate-key", file=sys.stderr)
    print("   3. Models may be temporarily unavailable — try again in a few minutes", file=sys.stderr)
    print("   4. Try a different tier: --tier standard or --tier premium", file=sys.stderr)
    print(file=sys.stderr)
    print("   Note: This skill uses OpenRouter exclusively. No other providers.", file=sys.stderr)
    print(f"   Last error: {last_error}", file=sys.stderr)
    return (None, primary_model, None)


def generate_video(prompt: str, width: int, height: int, duration: int,
                   model: str) -> tuple[str | None, str]:
    """Generate a video via OpenRouter alpha API.  Returns (video_path, model)."""
    api_model = model.split(":")[0] if ":" in model else model
    video_prompt = (
        f"{prompt}. Resolution: {width}x{height}. "
        f"High quality, smooth motion, {duration} seconds."
    )
    payload = {"model": api_model, "prompt": video_prompt}
    print(f"  Submitting video generation request to OpenRouter...")
    try:
        result = api_request(VIDEO_GENERATION_URL, payload)
    except RuntimeError as exc:
        print(f"  ERROR: Video API request failed: {exc}", file=sys.stderr)
        return (None, api_model)

    polling_url = result.get("polling_url")
    job_id = result.get("id", "unknown")
    if not polling_url:
        print(f"  ERROR: No polling URL returned. Response: {json.dumps(result)[:300]}", file=sys.stderr)
        return (None, api_model)

    print(f"  Job submitted: {job_id}")
    print(f"  Polling for completion (may take several minutes)...")

    api_key = get_api_key()
    for attempt in range(1, 121):
        time.sleep(5)
        try:
            poll_req = urllib.request.Request(polling_url, headers={
                "Authorization": f"Bearer {api_key}",
            })
            with urllib.request.urlopen(poll_req, timeout=30) as resp:
                status_data = json.loads(resp.read().decode("utf-8"))
        except Exception as exc:
            print(f"  Poll {attempt}: error — {exc}", file=sys.stderr)
            continue

        status = status_data.get("status", "unknown")
        if attempt % 6 == 0:
            print(f"  Poll {attempt}: {status}")

        if status == "completed":
            video_urls = status_data.get("unsigned_urls", status_data.get("urls", []))
            if video_urls:
                out_dir = content_dir_today()
                out_path = str(out_dir / f"video_{ts()}.mp4")
                try:
                    dl_req = urllib.request.Request(video_urls[0])
                    with urllib.request.urlopen(dl_req, timeout=300) as resp:
                        save_file(resp.read(), out_path)
                    return (out_path, api_model)
                except Exception as exc:
                    print(f"  ERROR downloading video: {exc}", file=sys.stderr)
                    url_path = str(out_dir / f"video_{ts()}_urls.json")
                    save_file(json.dumps({"urls": video_urls}, indent=2), url_path)
                    return (url_path, api_model)
            else:
                print("  WARNING: No video URLs in completed response.", file=sys.stderr)
                return (None, api_model)

        elif status == "failed":
            err = status_data.get("error", "Unknown error")
            print(f"  ERROR: Video generation failed — {err}", file=sys.stderr)
            return (None, api_model)

    print("  ERROR: Video generation timed out after 10 minutes.", file=sys.stderr)
    return (None, api_model)


# ═══════════════════════════════════════════════════════════════════════════════
# UNIFIED COMMAND HANDLERS
# ═══════════════════════════════════════════════════════════════════════════════

def handle_text_command(args: argparse.Namespace) -> None:
    """Handle any text-only generation command."""
    cmd = args.command
    meta = COMMAND_META[cmd]
    platform = meta["platform"]
    label = meta["label"]

    print(f"  Generating {label}...")
    print(f"  Model: {resolve_text_model()} (FREE — $0.00)")

    extra = ""
    if cmd == "tw-thread":
        n = getattr(args, "tweets", 5)
        extra = f"Write a thread of exactly {n} tweets. Separate each tweet with '---TWEET---'."
    elif cmd == "yt-script":
        extra = "Write a full video script with [VISUAL CUE] markers, timestamps, and a clear hook/intro/body/CTA structure."
    elif cmd in ("ig-carousel", "li-carousel", "fb-carousel-ad"):
        n = getattr(args, "slides", 5)
        extra = f"Write text for a {n}-slide carousel. Format: SLIDE 1: ... SLIDE 2: ... etc. One core idea per slide, under 30 words each. Slide 1 is the hook, last slide is the CTA."

    text = generate_text(args.prompt, platform, cmd, extra_instructions=extra)

    out_dir = content_dir_today()
    out_path = str(out_dir / f"{cmd}_{ts()}.txt")
    save_file(text, out_path)
    save_metadata(out_path, {
        "type": "text", "command": cmd, "model": resolve_text_model(),
        "platform": platform, "label": label, "prompt": args.prompt,
        "cost_usd": 0.0, "generated_at": datetime.utcnow().isoformat() + "Z",
    })
    log_generation("text", resolve_text_model(), 0.0, platform, out_path)

    if cmd == "tw-thread":
        tweets = [t.strip() for t in text.split("---TWEET---") if t.strip()]
        if len(tweets) <= 1:
            tweets = [t.strip() for t in text.split("\n\n") if t.strip()]
        fmt_thread(label, tweets)
    else:
        fmt_text_post(label, text, platform)

    print(f"  Saved to: {out_path}")


def handle_image_command(args: argparse.Namespace) -> None:
    """Handle any image-only generation command."""
    cmd = args.command
    meta = COMMAND_META[cmd]
    platform = meta["platform"]
    label = meta["label"]
    dim_key = meta["dim_key"]
    tier = resolve_tier(getattr(args, "tier", None))
    model = smart_route_image(cmd, tier, getattr(args, "model", None))
    w, h = get_dims(platform, dim_key)
    cost = get_image_cost(model)
    intent = COMMAND_INTENT.get(cmd, "general")

    print(f"  Generating {label}...")
    print(f"  Smart Route: intent={intent} | Tier: {tier} | Model: {model}")
    print(f"  Dimensions: {w}x{h} | Est. cost: ${cost:.3f}")

    image_data, used_model, _ = generate_image_with_retry(args.prompt, w, h, model)
    actual_cost = get_image_cost(used_model)

    if image_data:
        out_dir = content_dir_today()
        out_path = str(out_dir / f"{cmd}_{ts()}.png")
        save_file(image_data, out_path)
        save_metadata(out_path, {
            "type": "image", "command": cmd, "model": used_model,
            "tier": tier, "intent": intent, "platform": platform, "label": label,
            "dimensions": f"{w}x{h}", "prompt": args.prompt,
            "cost_usd": round(actual_cost, 6),
            "generated_at": datetime.utcnow().isoformat() + "Z",
        })
        log_generation("image", used_model, actual_cost, platform, out_path)
        fmt_image_post(label, out_path, w, h)
    else:
        sys.exit(1)


def handle_text_image_command(args: argparse.Namespace) -> None:
    """Handle any text+image combined post command."""
    cmd = args.command
    meta = COMMAND_META[cmd]
    platform = meta["platform"]
    label = meta["label"]
    dim_key = meta["dim_key"]
    tier = resolve_tier(getattr(args, "tier", None))
    img_model = smart_route_image(cmd, tier, getattr(args, "model", None))
    w, h = get_dims(platform, dim_key)
    img_cost = get_image_cost(img_model)
    intent = COMMAND_INTENT.get(cmd, "general")

    print(f"  Generating {label} (text + image)...")
    print(f"  Text model: {resolve_text_model()} (FREE)")
    print(f"  Image model: {img_model} (${img_cost:.3f}) [intent: {intent}]")
    print(f"  Dimensions: {w}x{h}")

    # Step 1: Generate caption (FREE)
    print(f"  Step 1/2: Generating caption...")
    caption = generate_text(args.prompt, platform, cmd)

    # Step 2: Generate image (paid)
    print(f"  Step 2/2: Generating image...")
    image_data, used_model, _ = generate_image_with_retry(args.prompt, w, h, img_model)
    actual_cost = get_image_cost(used_model)

    out_dir = content_dir_today()
    text_path = str(out_dir / f"{cmd}_{ts()}_caption.txt")
    save_file(caption, text_path)

    if image_data:
        img_path = str(out_dir / f"{cmd}_{ts()}.png")
        save_file(image_data, img_path)
        save_metadata(img_path, {
            "type": "text+image", "command": cmd,
            "text_model": resolve_text_model(), "image_model": used_model,
            "tier": tier, "intent": intent, "platform": platform, "label": label,
            "dimensions": f"{w}x{h}", "prompt": args.prompt,
            "caption_file": text_path, "image_file": img_path,
            "cost_usd": round(actual_cost, 6),
            "generated_at": datetime.utcnow().isoformat() + "Z",
        })
        log_generation("text+image", used_model, actual_cost, platform, img_path)
        fmt_text_image_post(label, caption, img_path, w, h, platform)
    else:
        log_generation("text", resolve_text_model(), 0.0, platform, text_path)
        fmt_text_post(label, caption, platform)
        print("  WARNING: Image generation failed. Caption saved above.", file=sys.stderr)
        print(f"  Caption saved to: {text_path}")


def handle_carousel_command(args: argparse.Namespace) -> None:
    """Handle carousel commands (multi-slide)."""
    cmd = args.command
    meta = COMMAND_META[cmd]
    platform = meta["platform"]
    label = meta["label"]
    dim_key = meta["dim_key"]
    tier = resolve_tier(getattr(args, "tier", None))
    img_model = smart_route_image(cmd, tier, getattr(args, "model", None))
    w, h = get_dims(platform, dim_key)
    num_slides = getattr(args, "slides", 5)
    per_image = get_image_cost(img_model)
    total_cost = per_image * num_slides

    print(f"  Generating {label} ({num_slides} slides)...")
    print(f"  Text model: {resolve_text_model()} (FREE)")
    print(f"  Image model: {img_model} (${per_image:.3f}/image)")
    print(f"  Total est. cost: ${total_cost:.3f} for {num_slides} slides")
    print(f"  Dimensions: {w}x{h} per slide")

    # Step 1: Generate carousel text
    print(f"  Step 1: Generating carousel text for {num_slides} slides...")
    extra = (f"Write text for a {num_slides}-slide carousel. "
             f"Format each slide as 'SLIDE N: [content]'. "
             f"Slide 1 is the hook. Last slide is CTA. Under 30 words per slide.")
    carousel_text = generate_text(args.prompt, platform, "carousel",
                                  extra_instructions=extra)

    out_dir = content_dir_today()
    text_path = str(out_dir / f"{cmd}_{ts()}_text.txt")
    save_file(carousel_text, text_path)

    # Step 2: Generate slide images
    slide_paths: list[str] = []
    total_actual_cost = 0.0
    for i in range(1, num_slides + 1):
        print(f"  Step 2: Generating slide {i}/{num_slides}...")
        slide_prompt = f"Slide {i} of {num_slides} for a carousel about: {args.prompt}. Professional, cohesive design, consistent style across all slides."
        img_data, used_model, _ = generate_image_with_retry(slide_prompt, w, h, img_model)
        if img_data:
            sp = str(out_dir / f"{cmd}_{ts()}_slide{i:02d}.png")
            save_file(img_data, sp)
            slide_paths.append(sp)
            total_actual_cost += get_image_cost(used_model)
        else:
            slide_paths.append(f"[FAILED] Slide {i}")

        if i < num_slides:
            time.sleep(1)

    save_metadata(text_path, {
        "type": "carousel", "command": cmd,
        "text_model": resolve_text_model(), "image_model": img_model,
        "tier": tier, "platform": platform, "label": label,
        "dimensions": f"{w}x{h}", "num_slides": num_slides,
        "prompt": args.prompt, "slide_files": slide_paths,
        "cost_usd": round(total_actual_cost, 6),
        "generated_at": datetime.utcnow().isoformat() + "Z",
    })
    log_generation("carousel", img_model, total_actual_cost, platform, text_path)
    fmt_carousel(label, carousel_text, slide_paths, w, h, platform)


def handle_video_command(args: argparse.Namespace) -> None:
    """Handle any video generation command."""
    cmd = args.command
    meta = COMMAND_META[cmd]
    platform = meta["platform"]
    label = meta["label"]
    dim_key = meta["dim_key"]
    tier = resolve_tier(getattr(args, "tier", None))
    duration = getattr(args, "duration", 5) or 5
    vid_model = smart_route_video(cmd, tier, duration, getattr(args, "model", None))
    w, h = get_dims(platform, dim_key)
    cost_per_sec = get_video_cost(vid_model)
    est_cost = cost_per_sec * duration

    print(f"  Generating {label}...")
    print(f"  Model: {vid_model} | Tier: {tier}")
    print(f"  Dimensions: {w}x{h} | Duration: {duration}s")
    print(f"  Est. cost: ${est_cost:.3f}")

    # Also generate a caption
    print(f"  Generating caption (FREE)...")
    caption = generate_text(args.prompt, platform, "video caption")

    print(f"  Generating video (this may take several minutes)...")
    video_path, used_model = generate_video(args.prompt, w, h, duration, vid_model)

    out_dir = content_dir_today()
    text_path = str(out_dir / f"{cmd}_{ts()}_caption.txt")
    save_file(caption, text_path)

    if video_path:
        save_metadata(video_path, {
            "type": "video", "command": cmd,
            "text_model": resolve_text_model(), "video_model": used_model,
            "tier": tier, "platform": platform, "label": label,
            "dimensions": f"{w}x{h}", "duration": duration,
            "prompt": args.prompt, "caption_file": text_path,
            "cost_usd": round(est_cost, 6),
            "generated_at": datetime.utcnow().isoformat() + "Z",
        })
        log_generation("video", used_model, est_cost, platform, video_path)
        fmt_video_post(label, caption, video_path, w, h, duration)
    else:
        log_generation("text", resolve_text_model(), 0.0, platform, text_path)
        fmt_text_post(label + " (caption only — video failed)", caption, platform)
        print("  WARNING: Video generation failed. Caption saved.", file=sys.stderr)


# ═══════════════════════════════════════════════════════════════════════════════
# SETUP & CONFIG COMMANDS
# ═══════════════════════════════════════════════════════════════════════════════

def cmd_validate_key(args: argparse.Namespace) -> None:
    ensure_provider_config()
    print("  Validating OpenRouter API key...")
    try:
        result = api_request(AUTH_CHECK_URL, method="GET", payload=None)
    except RuntimeError as exc:
        print(f"  ERROR: {exc}", file=sys.stderr)
        sys.exit(1)
    data = result.get("data", {})
    label = data.get("label", "Unknown")
    usage = data.get("usage", 0)
    limit = data.get("limit")
    print(f"  Key label  : {label}")
    print(f"  Usage      : ${usage:.4f}")
    if limit is not None:
        print(f"  Limit      : ${limit:.4f}")
        print(f"  Remaining  : ${limit - usage:.4f}")
    else:
        print(f"  Limit      : Unlimited")
    print(f"  Provider   : OpenRouter (locked)")
    print(f"  Config     : {PROVIDER_FILE}")
    print("  API key is valid.")


def cmd_check_balance(args: argparse.Namespace) -> None:
    try:
        result = api_request(AUTH_CHECK_URL, method="GET", payload=None)
    except RuntimeError as exc:
        print(f"  ERROR: {exc}", file=sys.stderr)
        sys.exit(1)
    data = result.get("data", {})
    usage = data.get("usage", 0)
    limit = data.get("limit")
    remaining = (limit - usage) if limit is not None else None
    print(json.dumps({
        "provider": "openrouter",
        "usage_usd": usage,
        "limit_usd": limit,
        "remaining_usd": remaining,
    }, indent=2))


def cmd_set_preferences(args: argparse.Namespace) -> None:
    prefs = load_preferences()
    if args.tier:
        prefs["default_tier"] = args.tier.lower()
    if getattr(args, "text_model", None):
        prefs["default_text_model"] = args.text_model
    if getattr(args, "image_model", None):
        prefs["default_image_model"] = args.image_model
    if getattr(args, "video_model", None):
        prefs["default_video_model"] = args.video_model
    save_preferences(prefs)
    print("  Preferences updated:")
    print(json.dumps(prefs, indent=2))


def cmd_show_preferences(args: argparse.Namespace) -> None:
    prefs = load_preferences()
    plan = load_content_plan()
    print("  Current preferences:")
    print(json.dumps(prefs, indent=2))
    if plan:
        print()
        print("  Saved content plan:")
        print(json.dumps(plan, indent=2))


def cmd_list_models(args: argparse.Namespace) -> None:
    filter_type = getattr(args, "type", None)
    if not filter_type or filter_type == "text":
        print("\n=== FREE Text Models (Tier 1 — $0.00) ===")
        for mid, info in FREE_TEXT_MODELS.items():
            print(f"  {mid}")
            print(f"    {info['name']} | Context: {info['context']} | {info['best_for']}")
    if not filter_type or filter_type == "image":
        for tn in ["budget", "standard", "premium"]:
            tl = {"budget": "Tier 2 — Budget", "standard": "Tier 3 — Standard",
                   "premium": "Tier 4 — Premium"}
            print(f"\n=== {tl[tn]} Image Models ===")
            for mid, info in IMAGE_MODELS[tn].items():
                print(f"  {mid}")
                tr = info.get("text_rendering", "?")
                art = info.get("artistic", "?")
                print(f"    {info['name']} | ${info['cost_per_image']:.3f}/image | Text: {tr} | Art: {art} | {info['notes']}")
    if not filter_type or filter_type == "video":
        for tn in ["budget", "standard", "premium"]:
            tl = {"budget": "Tier 2 — Budget", "standard": "Tier 3 — Standard",
                   "premium": "Tier 4 — Premium"}
            print(f"\n=== {tl[tn]} Video Models ===")
            for mid, info in VIDEO_MODELS[tn].items():
                print(f"  {mid}")
                print(f"    {info['name']} | ${info['cost_per_second']:.2f}/sec | {info.get('resolution','')} | {info['notes']}")
    print()


def cmd_estimate_cost(args: argparse.Namespace) -> None:
    ctype = args.type
    count = args.count
    tier = resolve_tier(getattr(args, "tier", None))
    duration = getattr(args, "duration", 5) or 5

    fmt_tiered_options(ctype, count, duration)

    if ctype == "text":
        model = resolve_text_model()
        per_item = 0.0
    elif ctype in ("image", "text-image", "carousel"):
        model = smart_route_image(None, tier)
        per_item = get_image_cost(model)
    elif ctype == "video":
        model = smart_route_video(None, tier, duration)
        per_item = get_video_cost(model) * duration
    elif ctype == "batch":
        model = "mixed"
        per_item = 0.02
    else:
        model = resolve_text_model()
        per_item = 0.0

    total = per_item * count
    monthly = total * 30 if getattr(args, "recurring", False) else None
    fmt_cost_estimate(tier, model, ctype, count, per_item, total, monthly)

    result = {"tier": tier, "type": ctype, "model": model, "count": count,
              "per_item_usd": round(per_item, 6), "total_usd": round(total, 6)}
    if monthly is not None:
        result["monthly_usd"] = round(monthly, 4)
        result["yearly_usd"] = round(monthly * 12, 4)
    print(json.dumps(result))


# ═══════════════════════════════════════════════════════════════════════════════
# REPURPOSE COMMAND
# ═══════════════════════════════════════════════════════════════════════════════

def cmd_repurpose(args: argparse.Namespace) -> None:
    """Take source content and adapt it for multiple platforms."""
    source = args.source
    platforms = [p.strip().lower() for p in args.platforms.split(",")]
    tier = resolve_tier(getattr(args, "tier", None))

    print(f"  Repurposing content for {len(platforms)} platforms...")
    print(f"  Platforms: {', '.join(platforms)}")
    print(f"  Tier: {tier}")

    platform_cmd_map = {
        "instagram": "ig-feed-post", "facebook": "fb-feed-post",
        "twitter": "tw-post", "x": "tw-post", "linkedin": "li-post",
        "tiktok": "tt-text", "youtube": "yt-script",
        "pinterest": "pin-standard", "threads": "threads-post",
        "bluesky": "bsky-post", "snapchat": "snap-story",
        "whatsapp": "wa-status",
    }

    results: list[dict] = []
    total_cost = 0.0

    for plat in platforms:
        cmd_name = platform_cmd_map.get(plat)
        if not cmd_name:
            print(f"  WARNING: Unknown platform '{plat}', skipping.", file=sys.stderr)
            continue

        meta = COMMAND_META.get(cmd_name)
        if not meta:
            continue

        print(f"\n  [{plat.upper()}] Generating adapted content...")

        extra = f"Adapt this content for {plat}: {source}"
        text = generate_text(extra, meta["platform"], cmd_name)

        out_dir = content_dir_today()
        text_path = str(out_dir / f"repurpose_{plat}_{ts()}.txt")
        save_file(text, text_path)

        img_path = None
        if meta["media"] in ("image", "text+image") and meta["dim_key"]:
            w, h = get_dims(meta["platform"], meta["dim_key"])
            img_model = smart_route_image(cmd_name, tier)
            img_data, used_model, _ = generate_image_with_retry(
                f"Visual for {plat} about: {source}", w, h, img_model)
            if img_data:
                img_path = str(out_dir / f"repurpose_{plat}_{ts()}.png")
                save_file(img_data, img_path)
                cost = get_image_cost(used_model)
                total_cost += cost
                log_generation("image", used_model, cost, plat, img_path)
                fmt_text_image_post(meta["label"], text, img_path, w, h, plat)
            else:
                fmt_text_post(meta["label"], text, plat)
        else:
            fmt_text_post(meta["label"], text, plat)

        log_generation("text", resolve_text_model(), 0.0, plat, text_path)
        results.append({"platform": plat, "text_file": text_path,
                        "image_file": img_path, "command": cmd_name})

        if plat != platforms[-1]:
            time.sleep(1)

    print()
    print("  Repurposing Complete!")
    print(f"  Platforms: {len(results)}")
    print(f"  Total cost: ${total_cost:.3f}")
    print()
    for r in results:
        print(f"  {r['platform'].upper()}: text={r['text_file']}")
        if r["image_file"]:
            print(f"  {' ' * len(r['platform'])}  image={r['image_file']}")


# ═══════════════════════════════════════════════════════════════════════════════
# BATCH COMMAND
# ═══════════════════════════════════════════════════════════════════════════════

def cmd_batch_generate(args: argparse.Namespace) -> None:
    """Batch generate from a JSON config file."""
    config_path = Path(args.config)
    if not config_path.exists():
        print(f"  ERROR: Config file not found: {config_path}", file=sys.stderr)
        sys.exit(1)

    config = json.loads(config_path.read_text())
    items = config.get("items", [])
    tier = resolve_tier(getattr(args, "tier", None))

    if not items:
        print("  ERROR: No items in batch config.", file=sys.stderr)
        sys.exit(1)

    total_est = 0.0
    for item in items:
        it = item.get("type", "text")
        count = item.get("count", 1)
        dur = item.get("duration", 5)
        if it == "text":
            pass
        elif it == "image":
            total_est += get_image_cost(smart_route_image(None, tier)) * count
        elif it == "video":
            total_est += get_video_cost(smart_route_video(None, tier, dur)) * dur * count

    print()
    print(f"  Batch: {len(items)} items | Tier: {tier} | Est. cost: ${total_est:.3f}")
    print()

    for i, item in enumerate(items, 1):
        it = item.get("type", "text")
        prompt = item.get("prompt", "")
        plat = item.get("platform", "instagram")
        ct = item.get("content_type", "post")
        print(f"  [{i}/{len(items)}] {it} for {plat}...")

        ns = argparse.Namespace(
            command=item.get("command", f"{plat[:2]}-{ct}"),
            prompt=prompt, tier=tier, model=None,
            slides=item.get("slides", 5),
            tweets=item.get("tweets", 5),
            duration=item.get("duration", 5),
        )

        cmd_name = item.get("command")
        if cmd_name and cmd_name in COMMAND_META:
            meta = COMMAND_META[cmd_name]
            ns.command = cmd_name
            if meta["media"] == "text":
                handle_text_command(ns)
            elif meta["media"] == "image":
                handle_image_command(ns)
            elif meta["media"] == "text+image":
                handle_text_image_command(ns)
            elif meta["media"] == "carousel":
                handle_carousel_command(ns)
            elif meta["media"] == "video":
                handle_video_command(ns)
            elif meta["media"] == "thread":
                handle_text_command(ns)
        else:
            text = generate_text(prompt, plat, ct)
            out_dir = content_dir_today()
            out_path = str(out_dir / f"batch_{i:03d}_{ts()}.txt")
            save_file(text, out_path)
            fmt_text_post(f"Batch item {i}", text, plat)

        if i < len(items):
            time.sleep(1)

    print(f"\n  Batch complete! {len(items)} items generated.")


# ═══════════════════════════════════════════════════════════════════════════════
# AUTOMATION / SCHEDULE COMMANDS
# ═══════════════════════════════════════════════════════════════════════════════

def cmd_schedule_content(args: argparse.Namespace) -> None:
    """Save a content schedule configuration."""
    ensure_dirs()
    schedule = {
        "id": f"sched_{ts()}",
        "type": args.type,
        "platforms": [p.strip() for p in args.platforms.split(",")],
        "topics": [t.strip() for t in args.topics.split(",")],
        "tier": resolve_tier(getattr(args, "tier", None)),
        "created_at": datetime.utcnow().isoformat() + "Z",
        "active": True,
    }

    sched_file = DATA_DIR / "automations" / f"{schedule['id']}.json"
    save_file(json.dumps(schedule, indent=2), str(sched_file))

    tier = schedule["tier"]
    num_platforms = len(schedule["platforms"])
    img_model = smart_route_image(None, tier)
    per_image = get_image_cost(img_model)

    if schedule["type"] == "daily":
        daily_images = num_platforms
        monthly_cost = daily_images * per_image * 30
    else:
        daily_images = num_platforms / 7
        monthly_cost = num_platforms * per_image * 4

    print()
    print(f"  Schedule saved: {schedule['id']}")
    print(f"  Type: {schedule['type']}")
    print(f"  Platforms: {', '.join(schedule['platforms'])}")
    print(f"  Topics: {', '.join(schedule['topics'])}")
    print(f"  Tier: {tier}")
    print()
    print(f"  Cost Projection:")
    print(f"    Text generation: $0.00/month (always free)")
    print(f"    Image generation: ~${monthly_cost:.2f}/month")
    print(f"    Total: ~${monthly_cost:.2f}/month (${monthly_cost * 12:.2f}/year)")
    print()
    print(f"  Config saved to: {sched_file}")
    print(f"  To generate content: say 'generate today's content' or run:")
    print(f"    python3 {SCRIPT_PATH} execute-plan")


def cmd_show_schedule(args: argparse.Namespace) -> None:
    auto_dir = DATA_DIR / "automations"
    if not auto_dir.exists():
        print("  No schedules found.")
        return
    files = list(auto_dir.glob("sched_*.json"))
    if not files:
        print("  No schedules found.")
        return
    for f in files:
        try:
            s = json.loads(f.read_text())
            status = "ACTIVE" if s.get("active", True) else "INACTIVE"
            print(f"  [{status}] {s['id']} | {s['type']} | {', '.join(s['platforms'])} | Tier: {s['tier']}")
        except (json.JSONDecodeError, OSError):
            pass


def cmd_cancel_schedule(args: argparse.Namespace) -> None:
    sched_file = DATA_DIR / "automations" / f"{args.id}.json"
    if not sched_file.exists():
        print(f"  ERROR: Schedule not found: {args.id}", file=sys.stderr)
        sys.exit(1)
    s = json.loads(sched_file.read_text())
    s["active"] = False
    sched_file.write_text(json.dumps(s, indent=2))
    print(f"  Schedule {args.id} cancelled.")


def cmd_save_plan(args: argparse.Namespace) -> None:
    """Save a content plan from wizard answers (called by OpenClaw)."""
    plan_data = {}
    if getattr(args, "plan_json", None):
        plan_data = json.loads(args.plan_json)
    else:
        plan_data = {
            "brand": getattr(args, "brand", ""),
            "audience": getattr(args, "audience", ""),
            "platforms": [p.strip() for p in getattr(args, "platforms", "").split(",")],
            "content_types": getattr(args, "content_types", ""),
            "topics": [t.strip() for t in getattr(args, "topics", "").split(",")],
            "tone": getattr(args, "tone", "professional"),
            "frequency": getattr(args, "frequency", "daily"),
            "tier": resolve_tier(getattr(args, "tier", None)),
        }
    plan_data["saved_at"] = datetime.utcnow().isoformat() + "Z"
    save_content_plan(plan_data)
    print(f"  Content plan saved to: {PLAN_FILE}")
    print(json.dumps(plan_data, indent=2))


def cmd_execute_plan(args: argparse.Namespace) -> None:
    """Execute the saved content plan — generate today's content."""
    plan = load_content_plan()
    if not plan:
        print("  ERROR: No content plan found. Run the Content Wizard first.", file=sys.stderr)
        print(f"  Or save a plan: python3 {SCRIPT_PATH} save-plan --plan-json '{{...}}'", file=sys.stderr)
        sys.exit(1)

    platforms = plan.get("platforms", [])
    topics = plan.get("topics", ["general content"])
    tier = plan.get("tier", "budget")
    tone = plan.get("tone", "professional")
    brand = plan.get("brand", "")

    day_of_year = datetime.now().timetuple().tm_yday
    topic = topics[day_of_year % len(topics)]

    print(f"  Executing content plan...")
    print(f"  Today's topic: {topic}")
    print(f"  Platforms: {', '.join(platforms)}")
    print(f"  Tier: {tier} | Tone: {tone}")
    if brand:
        print(f"  Brand: {brand}")
    print()

    platform_cmd_map = {
        "instagram": "ig-feed-post", "facebook": "fb-feed-post",
        "twitter": "tw-post", "x": "tw-post", "linkedin": "li-post",
        "tiktok": "tt-text", "youtube": "yt-script",
        "pinterest": "pin-standard", "threads": "threads-post",
        "bluesky": "bsky-post", "snapchat": "snap-story",
        "whatsapp": "wa-status",
    }

    for plat in platforms:
        cmd_name = platform_cmd_map.get(plat.lower())
        if not cmd_name or cmd_name not in COMMAND_META:
            print(f"  WARNING: No default command for '{plat}', skipping.", file=sys.stderr)
            continue

        meta = COMMAND_META[cmd_name]
        prompt = f"Create content about '{topic}' for {brand or 'our brand'}. Tone: {tone}."

        ns = argparse.Namespace(
            command=cmd_name, prompt=prompt, tier=tier, model=None,
            slides=5, tweets=5, duration=5,
        )

        print(f"\n  === {plat.upper()} ===")
        if meta["media"] == "text":
            handle_text_command(ns)
        elif meta["media"] == "image":
            handle_image_command(ns)
        elif meta["media"] == "text+image":
            handle_text_image_command(ns)
        elif meta["media"] == "carousel":
            handle_carousel_command(ns)
        elif meta["media"] == "video":
            handle_video_command(ns)
        elif meta["media"] == "thread":
            handle_text_command(ns)

        time.sleep(1)

    print(f"\n  Content plan executed! All content saved to: {content_dir_today()}")


# ═══════════════════════════════════════════════════════════════════════════════
# CLI PARSER — ALL 60+ COMMANDS
# ═══════════════════════════════════════════════════════════════════════════════

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="openrouter_generate.py",
        description="Content Creator Godfather — OpenRouter-powered content engine. "
                    "60+ commands across 12 platforms. Smart model routing. Text is ALWAYS FREE.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # ── Setup & Config ─────────────────────────────────────────────────────
    sub.add_parser("validate-key", help="Validate the OpenRouter API key")
    sub.add_parser("check-balance", help="Check OpenRouter credit balance")

    p = sub.add_parser("set-preferences", help="Set default tier and model preferences")
    p.add_argument("--tier", choices=["free", "budget", "standard", "premium"])
    p.add_argument("--text-model", default=None)
    p.add_argument("--image-model", default=None)
    p.add_argument("--video-model", default=None)

    sub.add_parser("show-preferences", help="Show current preferences and saved plan")

    p = sub.add_parser("list-models", help="List available models by tier")
    p.add_argument("--type", choices=["text", "image", "video"], default=None)

    # ── Cost Estimation ────────────────────────────────────────────────────
    p = sub.add_parser("estimate-cost", help="Estimate cost with tiered options")
    p.add_argument("--type", required=True,
                   choices=["text", "image", "video", "text-image", "carousel", "batch"])
    p.add_argument("--count", type=int, default=1)
    p.add_argument("--tier", choices=["free", "budget", "standard", "premium"])
    p.add_argument("--duration", type=int, default=5)
    p.add_argument("--recurring", action="store_true")

    # ── Helper to add common args to platform commands ─────────────────────
    def add_prompt_args(p: argparse.ArgumentParser, has_tier: bool = True,
                        has_slides: bool = False, has_tweets: bool = False,
                        has_duration: bool = False) -> None:
        p.add_argument("--prompt", required=True, help="Content description/topic")
        if has_tier:
            p.add_argument("--tier", choices=["free", "budget", "standard", "premium"],
                           default=None)
        p.add_argument("--model", default=None, help="Override model selection")
        if has_slides:
            p.add_argument("--slides", type=int, default=5, help="Number of carousel slides")
        if has_tweets:
            p.add_argument("--tweets", type=int, default=5, help="Number of tweets in thread")
        if has_duration:
            p.add_argument("--duration", type=int, default=5, help="Video duration in seconds")

    # ── Instagram ──────────────────────────────────────────────────────────
    p = sub.add_parser("ig-feed-post",  help="Instagram feed post (text + image, 1080x1350)")
    add_prompt_args(p)
    p = sub.add_parser("ig-feed-text",  help="Instagram caption only (FREE)")
    add_prompt_args(p, has_tier=False)
    p = sub.add_parser("ig-feed-image", help="Instagram feed image (1080x1350)")
    add_prompt_args(p)
    p = sub.add_parser("ig-story",      help="Instagram story image (1080x1920)")
    add_prompt_args(p)
    p = sub.add_parser("ig-reel",       help="Instagram reel video (1080x1920)")
    add_prompt_args(p, has_duration=True)
    p = sub.add_parser("ig-carousel",   help="Instagram carousel (multi-slide)")
    add_prompt_args(p, has_slides=True)
    p = sub.add_parser("ig-ad-feed",    help="Instagram feed ad (1080x1080)")
    add_prompt_args(p)
    p = sub.add_parser("ig-ad-story",   help="Instagram story ad (1080x1920)")
    add_prompt_args(p)

    # ── Facebook ───────────────────────────────────────────────────────────
    p = sub.add_parser("fb-feed-post",   help="Facebook feed post (text + image, 1200x630)")
    add_prompt_args(p)
    p = sub.add_parser("fb-feed-text",   help="Facebook text post (FREE)")
    add_prompt_args(p, has_tier=False)
    p = sub.add_parser("fb-feed-image",  help="Facebook image post (1080x1080)")
    add_prompt_args(p)
    p = sub.add_parser("fb-story",       help="Facebook story (1080x1920)")
    add_prompt_args(p)
    p = sub.add_parser("fb-cover",       help="Facebook cover photo (820x312)")
    add_prompt_args(p)
    p = sub.add_parser("fb-event-cover", help="Facebook event cover (1920x1005)")
    add_prompt_args(p)
    p = sub.add_parser("fb-ad-feed",     help="Facebook feed ad (1200x628)")
    add_prompt_args(p)
    p = sub.add_parser("fb-ad-story",    help="Facebook story ad (1080x1920)")
    add_prompt_args(p)
    p = sub.add_parser("fb-carousel-ad", help="Facebook carousel ad (multi-slide)")
    add_prompt_args(p, has_slides=True)
    p = sub.add_parser("fb-video",       help="Facebook video post (1280x720)")
    add_prompt_args(p, has_duration=True)

    # ── Twitter / X ────────────────────────────────────────────────────────
    p = sub.add_parser("tw-post",   help="Tweet with image (1600x900)")
    add_prompt_args(p)
    p = sub.add_parser("tw-text",   help="Text tweet (FREE)")
    add_prompt_args(p, has_tier=False)
    p = sub.add_parser("tw-thread", help="Twitter thread (multiple tweets)")
    add_prompt_args(p, has_tier=False, has_tweets=True)
    p = sub.add_parser("tw-header", help="Twitter header image (1500x500)")
    add_prompt_args(p)
    p = sub.add_parser("tw-card",   help="Twitter card image (800x418)")
    add_prompt_args(p)
    p = sub.add_parser("tw-ad",     help="Twitter ad image (1200x675)")
    add_prompt_args(p)

    # ── LinkedIn ───────────────────────────────────────────────────────────
    p = sub.add_parser("li-post",          help="LinkedIn post with image (1200x628)")
    add_prompt_args(p)
    p = sub.add_parser("li-text",          help="LinkedIn text post (FREE)")
    add_prompt_args(p, has_tier=False)
    p = sub.add_parser("li-carousel",      help="LinkedIn document carousel (1080x1350)")
    add_prompt_args(p, has_slides=True)
    p = sub.add_parser("li-article-cover", help="LinkedIn article cover (1200x644)")
    add_prompt_args(p)
    p = sub.add_parser("li-company-cover", help="LinkedIn company cover (1128x191)")
    add_prompt_args(p)
    p = sub.add_parser("li-ad",            help="LinkedIn ad image (1200x628)")
    add_prompt_args(p)

    # ── TikTok ─────────────────────────────────────────────────────────────
    p = sub.add_parser("tt-video", help="TikTok video (1080x1920)")
    add_prompt_args(p, has_duration=True)
    p = sub.add_parser("tt-ad",    help="TikTok ad video (1080x1920)")
    add_prompt_args(p, has_duration=True)
    p = sub.add_parser("tt-text",  help="TikTok caption/script (FREE)")
    add_prompt_args(p, has_tier=False)

    # ── YouTube ────────────────────────────────────────────────────────────
    p = sub.add_parser("yt-thumbnail",  help="YouTube thumbnail (1280x720)")
    add_prompt_args(p)
    p = sub.add_parser("yt-shorts",     help="YouTube Shorts video (1080x1920)")
    add_prompt_args(p, has_duration=True)
    p = sub.add_parser("yt-banner",     help="YouTube channel banner (2560x1440)")
    add_prompt_args(p)
    p = sub.add_parser("yt-video",      help="YouTube video (1920x1080)")
    add_prompt_args(p, has_duration=True)
    p = sub.add_parser("yt-end-screen", help="YouTube end screen (1920x1080)")
    add_prompt_args(p)
    p = sub.add_parser("yt-script",     help="YouTube video script (FREE)")
    add_prompt_args(p, has_tier=False)

    # ── Pinterest ──────────────────────────────────────────────────────────
    p = sub.add_parser("pin-standard", help="Pinterest standard pin (1000x1500)")
    add_prompt_args(p)
    p = sub.add_parser("pin-idea",     help="Pinterest idea pin (1080x1920)")
    add_prompt_args(p)
    p = sub.add_parser("pin-ad",       help="Pinterest ad pin (1000x1500)")
    add_prompt_args(p)

    # ── Threads ────────────────────────────────────────────────────────────
    p = sub.add_parser("threads-post", help="Threads post with image (1080x1080)")
    add_prompt_args(p)
    p = sub.add_parser("threads-text", help="Threads text post (FREE)")
    add_prompt_args(p, has_tier=False)

    # ── Bluesky ────────────────────────────────────────────────────────────
    p = sub.add_parser("bsky-post",   help="Bluesky post with image (1200x675)")
    add_prompt_args(p)
    p = sub.add_parser("bsky-text",   help="Bluesky text post (FREE)")
    add_prompt_args(p, has_tier=False)
    p = sub.add_parser("bsky-banner", help="Bluesky banner (1500x500)")
    add_prompt_args(p)

    # ── Snapchat ───────────────────────────────────────────────────────────
    p = sub.add_parser("snap-story", help="Snapchat story (1080x1920)")
    add_prompt_args(p)
    p = sub.add_parser("snap-ad",    help="Snapchat ad (1080x1920)")
    add_prompt_args(p)

    # ── WhatsApp ───────────────────────────────────────────────────────────
    p = sub.add_parser("wa-status", help="WhatsApp status image (1080x1920)")
    add_prompt_args(p)

    # ── Google Ads ─────────────────────────────────────────────────────────
    p = sub.add_parser("gad-display-rect",         help="Google Display 300x250")
    add_prompt_args(p)
    p = sub.add_parser("gad-leaderboard",          help="Google Leaderboard 728x90")
    add_prompt_args(p)
    p = sub.add_parser("gad-skyscraper",           help="Google Skyscraper 160x600")
    add_prompt_args(p)
    p = sub.add_parser("gad-responsive-landscape", help="Google Responsive 1200x628")
    add_prompt_args(p)
    p = sub.add_parser("gad-responsive-square",    help="Google Responsive 1200x1200")
    add_prompt_args(p)

    # ── Repurpose ──────────────────────────────────────────────────────────
    p = sub.add_parser("repurpose", help="Repurpose content for multiple platforms")
    p.add_argument("--source", required=True, help="Source content to repurpose")
    p.add_argument("--platforms", required=True, help="Comma-separated platform list")
    p.add_argument("--tier", choices=["free", "budget", "standard", "premium"])
    p.add_argument("--model", default=None)

    # ── Batch ──────────────────────────────────────────────────────────────
    p = sub.add_parser("batch-generate", help="Batch generate from JSON config")
    p.add_argument("--config", required=True, help="Path to batch config JSON")
    p.add_argument("--tier", choices=["free", "budget", "standard", "premium"])

    # ── Automation ─────────────────────────────────────────────────────────
    p = sub.add_parser("schedule-content", help="Set up content schedule")
    p.add_argument("--type", required=True, choices=["daily", "weekly"])
    p.add_argument("--platforms", required=True, help="Comma-separated platforms")
    p.add_argument("--topics", required=True, help="Comma-separated topics")
    p.add_argument("--tier", choices=["free", "budget", "standard", "premium"])

    sub.add_parser("show-schedule", help="Show all content schedules")

    p = sub.add_parser("cancel-schedule", help="Cancel a content schedule")
    p.add_argument("--id", required=True, help="Schedule ID to cancel")

    # ── Plan Management ────────────────────────────────────────────────────
    p = sub.add_parser("save-plan", help="Save content plan from wizard")
    p.add_argument("--plan-json", default=None, help="Full plan as JSON string")
    p.add_argument("--brand", default="")
    p.add_argument("--audience", default="")
    p.add_argument("--platforms", default="")
    p.add_argument("--content-types", default="")
    p.add_argument("--topics", default="")
    p.add_argument("--tone", default="professional")
    p.add_argument("--frequency", default="daily")
    p.add_argument("--tier", choices=["free", "budget", "standard", "premium"])

    sub.add_parser("execute-plan", help="Execute saved content plan (generate today's content)")

    return parser


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN DISPATCH
# ═══════════════════════════════════════════════════════════════════════════════

def main() -> None:
    ensure_provider_config()
    parser = build_parser()
    args = parser.parse_args()
    cmd = args.command

    direct_dispatch = {
        "validate-key":     cmd_validate_key,
        "check-balance":    cmd_check_balance,
        "set-preferences":  cmd_set_preferences,
        "show-preferences": cmd_show_preferences,
        "list-models":      cmd_list_models,
        "estimate-cost":    cmd_estimate_cost,
        "repurpose":        cmd_repurpose,
        "batch-generate":   cmd_batch_generate,
        "schedule-content": cmd_schedule_content,
        "show-schedule":    cmd_show_schedule,
        "cancel-schedule":  cmd_cancel_schedule,
        "save-plan":        cmd_save_plan,
        "execute-plan":     cmd_execute_plan,
    }

    if cmd in direct_dispatch:
        direct_dispatch[cmd](args)
        return

    if cmd not in COMMAND_META:
        print(f"ERROR: Unknown command '{cmd}'.", file=sys.stderr)
        parser.print_help()
        sys.exit(1)

    meta = COMMAND_META[cmd]
    media = meta["media"]

    if media == "text":
        handle_text_command(args)
    elif media == "image":
        handle_image_command(args)
    elif media == "text+image":
        handle_text_image_command(args)
    elif media == "carousel":
        handle_carousel_command(args)
    elif media == "video":
        handle_video_command(args)
    elif media == "thread":
        handle_text_command(args)
    else:
        print(f"ERROR: Unknown media type '{media}' for command '{cmd}'.", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
