#!/usr/bin/env python3
"""
social_post_generator.py — OpenRouter-powered content generator for the
social-post-pipeline OpenClaw skill.

Generates text and images via OpenRouter API using only Python standard library.
No pip packages required.

Usage:
  python3 social_post_generator.py <command> [options]

Commands:
  generate-content    Generate title, description, caption, and image prompt
  generate-image      Generate image from prompt
  validate-key        Validate OpenRouter API key
  check-balance       Check OpenRouter credit balance

Environment:
  OPENROUTER_API_KEY   Required. Your OpenRouter API key.
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path
from typing import Any

# ═══════════════════════════════════════════════════════════════════════════════
# CONSTANTS
# ═══════════════════════════════════════════════════════════════════════════════

OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"
CHAT_COMPLETIONS_URL = f"{OPENROUTER_BASE_URL}/chat/completions"
AUTH_CHECK_URL = f"{OPENROUTER_BASE_URL}/auth/key"

DATA_DIR = Path.home() / ".openclaw-social-post-pipeline"
CONTENT_DIR = DATA_DIR / "content"
CONFIG_DIR = DATA_DIR / "config"

# ═══════════════════════════════════════════════════════════════════════════════
# MODEL REGISTRIES
# ═══════════════════════════════════════════════════════════════════════════════

FREE_TEXT_MODELS = [
    "qwen/qwen3.6-plus:free",
    "meta-llama/llama-3.3-70b-instruct:free",
    "openai/gpt-oss-120b:free",
    "nvidia/nemotron-3-super:free",
]

IMAGE_MODELS = {
    "budget": "google/gemini-2.5-flash-image",
    "standard": "google/gemini-3.1-flash-image-preview",
    "premium": "google/gemini-3-pro-image-preview",
}

FALLBACK_IMAGE_MODELS = [
    "google/gemini-2.5-flash-image",
    "bytedance-seed/seedream-4.5",
    "black-forest-labs/flux.2-klein-4b",
    "google/gemini-3.1-flash-image-preview",
]

# ═══════════════════════════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════════════════════════

def get_api_key() -> str:
    """Return the OpenRouter API key from the environment."""
    key = os.environ.get("OPENROUTER_API_KEY", "").strip()
    if not key:
        print("ERROR: OPENROUTER_API_KEY environment variable is not set.", file=sys.stderr)
        sys.exit(1)
    return key


def api_request(url: str, payload: dict | None = None, method: str = "POST",
                timeout: int = 180) -> dict:
    """Make an authenticated request to the OpenRouter API."""
    api_key = get_api_key()
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "HTTP-Referer": "https://clawlauncher.io",
        "X-Title": "social-post-pipeline",
    }
    data = json.dumps(payload).encode("utf-8") if payload else None
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {exc.code}: {body}")
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Network error: {exc.reason}")


def ensure_dirs() -> None:
    """Create the data directory structure."""
    for d in [DATA_DIR, CONTENT_DIR, CONFIG_DIR]:
        d.mkdir(parents=True, exist_ok=True)


def save_file(data: bytes | str, path: str) -> None:
    """Save data to file."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(data, bytes):
        p.write_bytes(data)
    else:
        p.write_text(data)


def content_dir_today() -> Path:
    """Get or create today's content directory."""
    d = CONTENT_DIR / datetime.now().strftime("%Y-%m-%d")
    d.mkdir(parents=True, exist_ok=True)
    return d


def ts() -> str:
    """Return timestamp string."""
    return str(int(time.time()))


# ═══════════════════════════════════════════════════════════════════════════════
# CORE GENERATION FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

def generate_content(topic: str) -> dict:
    """Generate title, description, caption, and image prompt for a topic."""
    model = FREE_TEXT_MODELS[0]  # qwen/qwen3.6-plus:free
    
    system_prompt = "You are an expert social media content creator. Generate engaging post content."
    user_prompt = f"""Create a social media post about: {topic}

Generate:
1. TITLE: Short catchy headline (5-10 words)
2. DESCRIPTION: 2-3 sentences explaining the post
3. CAPTION: Social media ready with emojis and 5-10 hashtags
4. IMAGE_PROMPT: Detailed prompt for image generation

Format as JSON:
{{
  "title": "...",
  "description": "...",
  "caption": "...",
  "image_prompt": "..."
}}"""

    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "temperature": 0.8,
        "max_tokens": 2000,
    }
    
    # Try each model in cascade
    for m in FREE_TEXT_MODELS:
        try:
            payload["model"] = m
            result = api_request(CHAT_COMPLETIONS_URL, payload)
            text = result.get("choices", [{}])[0].get("message", {}).get("content", "")
            
            # Parse JSON from response
            try:
                data = json.loads(text)
                return {
                    "title": data.get("title", ""),
                    "description": data.get("description", ""),
                    "caption": data.get("caption", ""),
                    "image_prompt": data.get("image_prompt", ""),
                    "model_used": m,
                }
            except json.JSONDecodeError:
                # Try to extract JSON from markdown code blocks
                if "```json" in text:
                    json_text = text.split("```json")[1].split("```")[0].strip()
                    data = json.loads(json_text)
                    return {
                        "title": data.get("title", ""),
                        "description": data.get("description", ""),
                        "caption": data.get("caption", ""),
                        "image_prompt": data.get("image_prompt", ""),
                        "model_used": m,
                    }
        except Exception as exc:
            print(f"  Model {m} failed: {exc}", file=sys.stderr)
            continue
    
    raise RuntimeError("All text models failed")


def generate_image(prompt: str, tier: str = "budget") -> tuple[bytes | None, str]:
    """Generate image with retry cascade. Returns (image_bytes, model_used)."""
    primary_model = IMAGE_MODELS.get(tier, IMAGE_MODELS["budget"])
    
    models_to_try = [primary_model] + [m for m in FALLBACK_IMAGE_MODELS if m != primary_model]
    
    image_prompt = f"{prompt}. High resolution, professional quality, clean composition."
    
    for model in models_to_try:
        try:
            payload = {
                "model": model,
                "messages": [{"role": "user", "content": image_prompt}],
                "modalities": ["image", "text"],
                "temperature": 0.9,
                "max_tokens": 4096,
            }
            
            result = api_request(CHAT_COMPLETIONS_URL, payload, timeout=240)
            message = result.get("choices", [{}])[0].get("message", {})
            
            # Extract image from response
            images_list = message.get("images", [])
            if images_list:
                for img_item in images_list:
                    if isinstance(img_item, dict):
                        url = img_item.get("image_url", {}).get("url", "")
                        if not url and isinstance(img_item.get("image_url"), str):
                            url = img_item["image_url"]
                        
                        if url.startswith("data:"):
                            _, encoded = url.split(",", 1)
                            return (base64.b64decode(encoded), model)
                        elif url.startswith("http"):
                            req = urllib.request.Request(url)
                            with urllib.request.urlopen(req, timeout=60) as resp:
                                return (resp.read(), model)
                    elif isinstance(img_item, str):
                        if img_item.startswith("data:"):
                            _, encoded = img_item.split(",", 1)
                            return (base64.b64decode(encoded), model)
                        elif img_item.startswith("http"):
                            req = urllib.request.Request(img_item)
                            with urllib.request.urlopen(req, timeout=60) as resp:
                                return (resp.read(), model)
            
            print(f"  Model {model} returned no image data", file=sys.stderr)
            
        except Exception as exc:
            print(f"  Model {model} failed: {exc}", file=sys.stderr)
            continue
    
    return (None, primary_model)


def generate_platform_captions(title: str, description: str) -> dict:
    """Generate platform-specific captions."""
    model = FREE_TEXT_MODELS[0]
    
    user_prompt = f"""Generate platform-specific captions for this post:

Title: {title}
Description: {description}

Create captions for:
1. Instagram (with emojis, hashtags)
2. X/Twitter (concise, engaging)
3. LinkedIn (professional tone)
4. Facebook (friendly, conversational)
5. TikTok (trendy, short)
6. YouTube (community post style)

Format as JSON with platform names as keys."""

    payload = {
        "model": model,
        "messages": [{"role": "user", "content": user_prompt}],
        "temperature": 0.8,
        "max_tokens": 2000,
    }
    
    for m in FREE_TEXT_MODELS:
        try:
            payload["model"] = m
            result = api_request(CHAT_COMPLETIONS_URL, payload)
            text = result.get("choices", [{}])[0].get("message", {}).get("content", "")
            
            try:
                return json.loads(text)
            except json.JSONDecodeError:
                if "```json" in text:
                    json_text = text.split("```json")[1].split("```")[0].strip()
                    return json.loads(json_text)
        except Exception:
            continue
    
    return {}


# ═══════════════════════════════════════════════════════════════════════════════
# COMMAND HANDLERS
# ═══════════════════════════════════════════════════════════════════════════════

def cmd_generate_content(args: argparse.Namespace) -> None:
    """Generate content (title, description, caption, image_prompt)."""
    topic = args.topic
    print(f"Generating content for: {topic}")
    
    result = generate_content(topic)
    
    # Save to file
    out_dir = content_dir_today()
    out_path = str(out_dir / f"content_{ts()}.json")
    save_file(json.dumps(result, indent=2), out_path)
    
    print(json.dumps(result, indent=2))
    print(f"Saved to: {out_path}")


def cmd_generate_image(args: argparse.Namespace) -> None:
    """Generate image from prompt."""
    prompt = args.prompt
    tier = args.tier
    
    print(f"Generating image (tier: {tier})...")
    
    image_data, model_used = generate_image(prompt, tier)
    
    if image_data:
        out_dir = content_dir_today()
        out_path = str(out_dir / f"image_{ts()}.png")
        save_file(image_data, out_path)
        
        print(f"Image generated successfully!")
        print(f"Model: {model_used}")
        print(f"Saved to: {out_path}")
    else:
        print("ERROR: Image generation failed with all models", file=sys.stderr)
        sys.exit(1)


def cmd_validate_key(args: argparse.Namespace) -> None:
    """Validate OpenRouter API key."""
    print("Validating OpenRouter API key...")
    try:
        result = api_request(AUTH_CHECK_URL, method="GET", payload=None)
        data = result.get("data", {})
        print(f"Key label: {data.get('label', 'Unknown')}")
        print(f"Usage: ${data.get('usage', 0):.4f}")
        print(f"Limit: {data.get('limit', 'Unlimited')}")
        print("API key is valid!")
    except RuntimeError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(1)


def cmd_check_balance(args: argparse.Namespace) -> None:
    """Check OpenRouter balance."""
    try:
        result = api_request(AUTH_CHECK_URL, method="GET", payload=None)
        data = result.get("data", {})
        print(json.dumps({
            "usage_usd": data.get("usage", 0),
            "limit_usd": data.get("limit"),
            "remaining_usd": (data.get("limit", 0) - data.get("usage", 0)) if data.get("limit") else None,
        }, indent=2))
    except RuntimeError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(1)


# ═══════════════════════════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════════════════════════

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="social_post_generator.py",
        description="Social Post Pipeline — OpenRouter content generator",
    )
    sub = parser.add_subparsers(dest="command", required=True)
    
    # Generate content
    p = sub.add_parser("generate-content", help="Generate title, description, caption, image_prompt")
    p.add_argument("--topic", required=True, help="Topic for the post")
    
    # Generate image
    p = sub.add_parser("generate-image", help="Generate image from prompt")
    p.add_argument("--prompt", required=True, help="Image generation prompt")
    p.add_argument("--tier", choices=["budget", "standard", "premium"], default="budget")
    
    # Validate key
    sub.add_parser("validate-key", help="Validate OpenRouter API key")
    
    # Check balance
    sub.add_parser("check-balance", help="Check OpenRouter credit balance")
    
    return parser


def main() -> None:
    ensure_dirs()
    parser = build_parser()
    args = parser.parse_args()
    
    commands = {
        "generate-content": cmd_generate_content,
        "generate-image": cmd_generate_image,
        "validate-key": cmd_validate_key,
        "check-balance": cmd_check_balance,
    }
    
    cmd_func = commands.get(args.command)
    if cmd_func:
        cmd_func(args)
    else:
        print(f"ERROR: Unknown command '{args.command}'", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
