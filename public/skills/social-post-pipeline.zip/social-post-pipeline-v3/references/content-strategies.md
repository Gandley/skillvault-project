# Content Strategies & Best Practices

This document outlines the core strategies for generating high-performing content across different platforms. Use these guidelines when adapting or repurposing content.

## Platform-Specific Tones & Strategies

### Twitter / X
- **Tone:** Punchy, conversational, thought-provoking, contrarian.
- **Length:** Short (under 280 characters). Use threads for longer thoughts.
- **Structure:** Strong hook in the first sentence. One main idea per tweet.
- **Visuals:** Memes, charts, infographics, or high-contrast images.
- **Hashtags:** 1-2 relevant hashtags maximum. Often better without them.
- **Best for:** Real-time updates, networking, building authority, quick thoughts.

### LinkedIn
- **Tone:** Professional, educational, inspiring, story-driven.
- **Length:** Medium to long (up to 3000 characters).
- **Structure:** "Broetry" style (short sentences, lots of line breaks). Start with a relatable hook, share a personal story or professional insight, end with a clear takeaway and a question to drive comments.
- **Visuals:** Document carousels (PDFs), professional photos, infographics, text-only posts.
- **Hashtags:** 3-5 broad and niche hashtags at the bottom.
- **Best for:** B2B networking, thought leadership, recruitment, company news.

### Instagram
- **Tone:** Visual-first, aesthetic, engaging, community-focused.
- **Length:** Captions can be long (micro-blogging) but the visual must grab attention instantly.
- **Structure:** Strong visual hook. Caption should start with a compelling first line (before the "more" cutoff). Use emojis to break up text.
- **Visuals:** High-quality photos, aesthetic graphics, Reels (short-form video), Carousels (educational or storytelling).
- **Hashtags:** 10-30 relevant hashtags. Mix of broad, niche, and location-based.
- **Best for:** Brand building, visual storytelling, e-commerce, community engagement.

### TikTok
- **Tone:** Authentic, entertaining, trend-driven, raw, educational.
- **Length:** Short-form video (15s to 3m). Captions are secondary but important for SEO.
- **Structure:** Hook within the first 3 seconds. Fast pacing. Clear call to action at the end.
- **Visuals:** Vertical video (9:16). Native text overlays, trending audio.
- **Hashtags:** 3-5 highly relevant hashtags. Use trending hashtags if applicable.
- **Best for:** Viral reach, Gen Z/Millennial audience, behind-the-scenes, quick tutorials.

### Facebook
- **Tone:** Conversational, community-oriented, slightly more casual than LinkedIn.
- **Length:** Short to medium.
- **Structure:** Ask questions to drive engagement. Share links with compelling commentary.
- **Visuals:** Videos (native upload), link previews, image galleries.
- **Hashtags:** 1-2 hashtags (less critical than on IG/Twitter).
- **Best for:** Community building (Groups), local businesses, older demographics, event promotion.

## Content Repurposing Framework

When the user asks to repurpose a piece of content (e.g., a blog post or YouTube video), follow this framework:

1.  **Extract the Core Message:** Identify the main thesis, 3-5 key takeaways, and any compelling quotes or statistics.
2.  **Adapt for Twitter:** Create a thread summarizing the key points, or 3-5 standalone tweets highlighting individual insights.
3.  **Adapt for LinkedIn:** Write a story-driven post focusing on the "why" behind the content, or create a carousel summarizing the "how-to" steps.
4.  **Adapt for Instagram:** Design a carousel graphic with the key takeaways, or write a script for a Reel explaining the core concept.
5.  **Adapt for TikTok/Shorts:** Write a punchy, 30-second script focusing on the most surprising or valuable insight.
6.  **Adapt for Facebook:** Write a conversational post asking the audience for their opinion on the topic, linking back to the original content.

## Hashtag Strategy

-   **Broad:** #Marketing, #Fitness, #Technology (High volume, low visibility)
-   **Niche:** #ContentMarketingTips, #HomeWorkoutRoutine, #SaaSDevelopment (Lower volume, higher targeted visibility)
-   **Branded:** #YourCompanyName, #YourCampaignName (For tracking and community building)
-   **Location:** #NYCEats, #LondonTech (Crucial for local businesses)

**Rule of Thumb:** Mix 1-2 broad, 3-5 niche, and 1 branded hashtag for optimal reach on platforms that heavily rely on them (Instagram, TikTok).
