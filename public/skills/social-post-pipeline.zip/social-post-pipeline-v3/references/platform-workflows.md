# Platform Workflows — Detailed Step-by-Step Guides

This is the MASTER WORKFLOW REFERENCE. For every content request, find the matching platform and content type below and follow the exact question sequence. Ask ONE question at a time. Wait for the answer. Never skip steps. Never generate without completing the workflow and getting cost approval.

---

## UNIVERSAL RULES FOR ALL WORKFLOWS

1. Before starting ANY workflow, check if `~/.openclaw-content-creator/config/brand-profile.json` exists. If yes, pre-fill brand name, colors, tone, and audience from it. Tell the user: "I have your brand profile loaded. I'll use [brand name] defaults unless you say otherwise."
2. After EVERY generation, always deliver: caption text (ready to copy) + image/video file (attached) + hashtags + cost spent.
3. After EVERY generation, ask: "Want to: (a) repurpose this for other platforms, (b) save as a template, (c) set up recurring, or (d) done?"
4. For recurring setup, ALWAYS calculate monthly cost and get explicit "yes" before activating.

---

## INSTAGRAM WORKFLOWS

### Instagram Feed Post (Image + Caption)
**Command:** `ig-feed-post`
**Dimensions:** 1080x1350 (4:5 portrait, recommended) or 1080x1080 (square)
**Questions:**
1. "What's this post about?" (topic/product/message)
2. "What visual style?" (Minimal clean / Bold vibrant / Lifestyle photography / Product showcase / Quote graphic / Infographic)
3. "Should the image have text overlay? If yes, what text?" (e.g., brand name, tagline, quote)
4. "Caption tone?" (Casual & fun / Professional / Inspirational / Educational / Storytelling / Witty)
5. "Hashtag strategy?" (I'll suggest 15-20 relevant ones / You provide custom ones / No hashtags)
6. "Quality tier?" (Budget ~$0.003 / Standard ~$0.05 / Premium ~$0.20)
**Cost gate:** Show estimate. "This will cost ~$X.XX. Proceed?"
**Prompt construction:** Combine topic + style + brand colors + text overlay into expert prompt. For product: add "studio lighting, shallow depth of field, premium aesthetic". For lifestyle: add "natural lighting, candid feel, warm tones". For quote: add "clean background, bold typography, centered text".
**Generate:** Run `ig-feed-post --prompt "[constructed prompt]" --tier [tier]`
**Deliver:** Attach image + show caption + hashtags. Ask about repurpose/template/recurring.

### Instagram Story
**Command:** `ig-story`
**Dimensions:** 1080x1920 (9:16 vertical)
**Questions:**
1. "What's the story about?" (announcement/behind-the-scenes/poll/promo/tip)
2. "Visual style?" (Branded template / Raw authentic / Aesthetic gradient / Photo-based)
3. "Any text overlay?" (headline, CTA, swipe-up text)
4. "Include sticker-style elements?" (poll placeholder, question box area, countdown)
5. "Quality tier?"
**Cost gate:** Show estimate. Get "yes".
**Prompt construction:** Vertical format. Keep important content in center safe zone (avoid top 250px and bottom 250px). Add "vertical 9:16, mobile-first design, bold readable text, Instagram story format".
**Generate:** Run `ig-story --prompt "[constructed prompt]" --tier [tier]`

### Instagram Reel (Video)
**Command:** `ig-reel`
**Dimensions:** 1080x1920 (9:16 vertical)
**Questions:**
1. "What's the reel concept?" (tutorial/trend/product demo/before-after/day-in-life/tips)
2. "What's the hook? (first 3 seconds are critical)" (question/bold statement/visual surprise/text hook)
3. "Duration?" (15 seconds / 30 seconds / 60 seconds)
4. "Visual style?" (Cinematic / Fast-paced cuts / Talking head / B-roll montage / Text-heavy)
5. "Music mood?" (Upbeat energetic / Chill lo-fi / Dramatic / Trending audio style)
6. "Quality tier?" (Budget 15s=$0.60 / Standard 15s=$1.20 / Premium 15s=$3.00)
**Cost gate:** "A [duration]s reel at [tier] tier will cost ~$X.XX. Proceed?"
**Prompt construction:** Add "vertical 9:16, dynamic camera movement, [hook description] in first 3 seconds, [music mood] energy, social media reel format, engaging and scroll-stopping".
**Generate:** Run `ig-reel --prompt "[constructed prompt]" --tier [tier] --duration [seconds]`
**Deliver:** Attach video + show caption + hashtags + reel description.

### Instagram Carousel (Multi-Slide)
**Command:** `ig-carousel`
**Dimensions:** 1080x1350 per slide (4:5)
**Questions:**
1. "What's the carousel about?" (educational breakdown/storytelling/product showcase/tips list/before-after)
2. "How many slides?" (3-10, recommend 5-7 for engagement)
3. "Slide 1 hook — what grabs attention?" (bold question/surprising stat/provocative statement)
4. "Key points for body slides?" (list the main points, one per slide)
5. "Final slide CTA?" (Follow for more / Save this / Link in bio / Share with a friend)
6. "Visual style?" (Clean minimal / Bold colorful / Professional / Branded template)
7. "Quality tier?" (Budget 5 slides=$0.015 / Standard=$0.25 / Premium=$1.00)
**Cost gate:** "[N] slides at [tier] = ~$X.XX. Proceed?"
**Prompt construction:** Generate each slide with consistent style. Slide 1: hook with large text. Body slides: one key point + supporting visual. Last slide: CTA. Add "consistent color scheme, clean typography, Instagram carousel format, 4:5 portrait".
**Generate:** Run `ig-carousel --prompt "[constructed prompt]" --slides [N] --tier [tier]`

### Instagram Ad (Feed)
**Command:** `ig-ad-feed`
**Dimensions:** 1080x1080 (1:1)
**Questions:**
1. "What are you promoting?" (product/service/event/app/offer)
2. "What's the main benefit or hook?"
3. "CTA button text?" (Shop Now / Learn More / Sign Up / Book Now / Download)
4. "Target audience?"
5. "Brand guidelines?" (colors, logo placement, fonts)
6. "Quality tier?" (Budget for testing / Standard for campaigns / Premium for hero ads)
**Cost gate:** Show estimate. Get "yes".
**Prompt construction:** Use Gemini models (best text rendering for ads). Add "clean ad layout, clear CTA area, brand colors [colors], professional advertising photography, high contrast, attention-grabbing, square 1:1 format".

### Instagram Ad (Story)
**Command:** `ig-ad-story`
**Dimensions:** 1080x1920 (9:16)
**Same questions as feed ad** but add: "Swipe-up CTA text?"
**Prompt construction:** Vertical format. CTA at bottom. "Full-screen vertical ad, swipe-up CTA area at bottom, immersive, mobile-first".

---

## FACEBOOK WORKFLOWS

### Facebook Feed Post (Image + Caption)
**Command:** `fb-feed-post`
**Dimensions:** 1200x630 (landscape) or 1080x1080 (square)
**Questions:**
1. "What's the post about?"
2. "Post goal?" (Engagement/clicks / Traffic to website / Brand awareness / Community discussion / Sales)
3. "Audience?" (Personal profile / Business page / Group)
4. "Visual style?" (Professional / Casual & friendly / News/announcement / Promotional)
5. "Include a link preview?" (If yes, image will be 1200x630 landscape)
6. "Caption length?" (Short punchy / Medium with story / Long detailed)
7. "Quality tier?"
**Cost gate → Generate → Deliver**

### Facebook Story
**Command:** `fb-story`
**Dimensions:** 1080x1920 (9:16)
**Questions:**
1. "What's the story about?"
2. "Visual style?" (Branded / Casual / Promotional / Behind-the-scenes)
3. "Text overlay?"
4. "Quality tier?"
**Cost gate → Generate → Deliver**

### Facebook Cover Photo
**Command:** `fb-cover`
**Dimensions:** 820x312 (desktop) — design for both desktop and mobile crop
**Questions:**
1. "What should the cover communicate?" (brand identity/current campaign/seasonal/event)
2. "Key text to include?" (tagline, website URL, phone number)
3. "Brand colors and logo placement?"
4. "Quality tier?"
**Prompt construction:** "Facebook cover photo, wide panoramic format, important content centered (mobile crops sides), brand identity, professional, clean layout".

### Facebook Video Post
**Command:** `fb-video`
**Dimensions:** 1280x720 (16:9 landscape) or 1080x1920 (9:16 vertical)
**Questions:**
1. "Video concept?"
2. "Orientation?" (Landscape 16:9 for desktop / Vertical 9:16 for mobile feed)
3. "Duration?" (15s/30s/60s)
4. "Hook in first 3 seconds?"
5. "Quality tier?"
**Cost gate with video pricing → Generate → Deliver**

### Facebook Ad (Feed)
**Command:** `fb-ad-feed`
**Dimensions:** 1200x628 (landscape) or 1080x1080 (square)
**Questions:**
1. "Campaign objective?" (Awareness / Traffic / Conversions / Lead gen)
2. "What are you promoting?"
3. "Primary text (above image)?"
4. "Headline (below image)?"
5. "CTA?" (Learn More / Shop Now / Sign Up / Book Now)
6. "Target audience description?"
7. "Quality tier?"
**Prompt construction:** Use Gemini for text rendering. "Facebook ad creative, clear value proposition, professional, high-contrast, CTA-ready layout".

### Facebook Carousel Ad
**Command:** `fb-carousel-ad`
**Dimensions:** 1080x1080 per card (1:1)
**Questions:**
1. "How many cards?" (2-10)
2. "What does each card show?" (different products / features / steps / testimonials)
3. "Consistent style across cards?"
4. "Headline per card?"
5. "Quality tier?"
**Cost gate: [N] cards × cost per image**

---

## TWITTER / X WORKFLOWS

### Tweet with Image
**Command:** `tw-post`
**Dimensions:** 1600x900 (16:9)
**Questions:**
1. "What's the tweet about?"
2. "Tone?" (Professional / Witty / Hot take / Informative / Thread-worthy)
3. "Image style?" (Data visualization / Quote card / Meme / Product shot / Infographic)
4. "Quality tier?"
**Prompt construction:** "Twitter-optimized image, 16:9 landscape, bold and eye-catching, designed to stop the scroll, high contrast".

### Twitter Thread
**Command:** `tw-thread`
**Questions:**
1. "What topic are you breaking down?"
2. "How many tweets?" (5-15 recommended)
3. "Thread style?" (Educational breakdown / Story arc / Hot takes / Tips list / Case study)
4. "Include images?" (Every tweet / First tweet only / No images)
5. "Quality tier?" (Text is FREE, images are per-tweet cost)
**Generate:** Text for all tweets (FREE) + images if requested (paid per image).

### Twitter Ad
**Command:** `tw-ad`
**Dimensions:** 1200x675 (16:9)
**Questions:**
1. "Campaign goal?"
2. "Ad copy (tweet text)?"
3. "CTA?"
4. "Target audience?"
5. "Quality tier?"

---

## LINKEDIN WORKFLOWS

### LinkedIn Post (Image + Caption)
**Command:** `li-post`
**Dimensions:** 1200x628 (landscape) or 1080x1080 (square)
**Questions:**
1. "What's the post about?"
2. "Post type?" (Thought leadership / Company update / Personal story / Industry insight / Hiring)
3. "Tone?" (Formal professional / Conversational professional / Storytelling / Data-driven)
4. "Image style?" (Professional photo / Infographic / Data chart / Quote card / Abstract)
5. "Include a hook line?" (first line before "see more" — critical for engagement)
6. "Quality tier?"
**Prompt construction:** "Professional LinkedIn image, clean corporate aesthetic, [style], business-appropriate, high quality".

### LinkedIn Carousel (Document)
**Command:** `li-carousel`
**Dimensions:** 1080x1350 per page (4:5)
**Questions:**
1. "Carousel topic?"
2. "How many slides?" (5-10 recommended for LinkedIn)
3. "Slide 1 hook?"
4. "Key points per slide?"
5. "Final slide CTA?" (Follow me / Visit website / Comment your thoughts / DM me)
6. "Visual style?" (Corporate clean / Bold modern / Data-heavy / Minimal)
7. "Quality tier?"
**Cost gate: [N] slides × cost**

### LinkedIn Article Cover
**Command:** `li-article-cover`
**Dimensions:** 1200x644
**Questions:**
1. "Article title?"
2. "Article topic/theme?"
3. "Visual style?" (Professional / Abstract / Photo-based / Branded)
4. "Quality tier?"

### LinkedIn Ad
**Command:** `li-ad`
**Dimensions:** 1200x628
**Questions:**
1. "Campaign objective?" (Brand awareness / Lead gen / Website visits / Job applications)
2. "What are you promoting?"
3. "Headline?"
4. "CTA?"
5. "Target audience?" (Job titles, industries, seniority)
6. "Quality tier?"

---

## TIKTOK WORKFLOWS

### TikTok Video
**Command:** `tt-video`
**Dimensions:** 1080x1920 (9:16 vertical)
**Questions:**
1. "Video concept?" (Tutorial / Trend / Product demo / Storytime / Day-in-life / Tips / Comedy skit)
2. "Hook (first 3 seconds)?" (This is the MOST important part — what stops the scroll?)
3. "Duration?" (15s for quick hits / 30s for tutorials / 60s for stories)
4. "Pacing?" (Fast cuts / Smooth transitions / Single take / Text-heavy with b-roll)
5. "Text overlay style?" (Bold captions / Subtitle style / Minimal / Trending format)
6. "Music/audio mood?" (Trending sound style / Upbeat / Chill / Dramatic / Voiceover)
7. "Quality tier?" (Budget 15s=$0.60 / Standard=$1.20 / Premium=$3.60)
**Cost gate → Generate → Deliver with caption + hashtags**

### TikTok Ad
**Command:** `tt-ad`
**Dimensions:** 1080x1920 (9:16)
**Questions:**
1. "What are you promoting?"
2. "Ad style?" (UGC-style / Professional / Trend-based / Testimonial)
3. "Hook?"
4. "CTA?"
5. "Duration?" (15s recommended for ads)
6. "Quality tier?"

---

## YOUTUBE WORKFLOWS

### YouTube Thumbnail
**Command:** `yt-thumbnail`
**Dimensions:** 1280x720 (16:9)
**Questions:**
1. "Video title/topic?"
2. "Thumbnail style?" (Face + text / Before-after / Clickbait bold / Clean minimal / Tutorial)
3. "Main text on thumbnail?" (Keep under 5 words — must be readable at small size)
4. "Color scheme?" (High contrast recommended — yellow/red/blue work best)
5. "Include a face/person?" (Yes with expression / No, object-focused)
6. "Quality tier?"
**Prompt construction:** "YouTube thumbnail, 16:9, bold large text '[text]', high contrast colors, eye-catching, designed for small display, [face/expression if applicable], professional, click-worthy".

### YouTube Shorts (Video)
**Command:** `yt-shorts`
**Dimensions:** 1080x1920 (9:16 vertical)
**Questions:**
1. "Shorts concept?"
2. "Hook (first 2 seconds)?"
3. "Duration?" (15-60 seconds)
4. "Style?" (Fast-paced / Tutorial / Reaction / Tips)
5. "Quality tier?"

### YouTube Banner
**Command:** `yt-banner`
**Dimensions:** 2560x1440 (safe area: 1546x423 center)
**Questions:**
1. "Channel name and tagline?"
2. "Upload schedule to display?" (e.g., "New videos every Tuesday")
3. "Brand colors?"
4. "Style?" (Gaming / Professional / Creative / Minimal)
5. "Quality tier?"
**Prompt construction:** "YouTube channel banner, ultra-wide format, important content centered in safe zone (1546x423), brand identity, professional, [style]".

### YouTube Video Script
**Command:** `yt-script`
**Questions (FREE — no cost):**
1. "Video topic?"
2. "Target length?" (5 min / 10 min / 15 min / 20+ min)
3. "Video style?" (Tutorial / Essay / Vlog / Review / List / Interview)
4. "Hook strategy?" (Question / Bold claim / Story / Stat)
5. "Key points to cover?"
6. "CTA?" (Subscribe / Like / Comment / Check link)
**Generate:** Full script with timestamps, hooks, transitions, and CTA placements. Always FREE.

---

## PINTEREST WORKFLOWS

### Pinterest Standard Pin
**Command:** `pin-standard`
**Dimensions:** 1000x1500 (2:3 vertical)
**Questions:**
1. "What's the pin about?"
2. "Pin style?" (Product photo / Infographic / Quote / Tutorial steps / Mood board)
3. "Text overlay?" (Title + subtitle recommended for Pinterest SEO)
4. "Keywords to rank for?" (Pinterest is a search engine — keywords matter)
5. "Quality tier?"
**Prompt construction:** "Pinterest pin, tall vertical 2:3, [style], text overlay '[text]', aesthetic, save-worthy, high quality".

### Pinterest Idea Pin
**Command:** `pin-idea`
**Dimensions:** 1080x1920 (9:16)
**Questions:**
1. "Idea pin concept?" (Tutorial / Recipe / DIY / Tips / Inspiration)
2. "How many pages?" (2-20)
3. "Visual style?" (Warm aesthetic / Clean minimal / Bold colorful / Rustic)
4. "Quality tier?"

---

## THREADS WORKFLOWS

### Threads Post (Image + Text)
**Command:** `threads-post`
**Dimensions:** 1080x1080 (1:1)
**Questions:**
1. "What's the post about?"
2. "Tone?" (Conversational / Hot take / Informative / Funny / Thought-provoking)
3. "Image style?" (Photo / Graphic / Meme / Quote card)
4. "Quality tier?"

### Threads Text Only
**Command:** `threads-text` (FREE)
**Questions:**
1. "What's the post about?"
2. "Tone?"
3. "Length?" (Short punchy / Medium / Long form)

---

## BLUESKY WORKFLOWS

### Bluesky Post (Image + Text)
**Command:** `bsky-post`
**Dimensions:** 1200x675 (16:9)
**Questions:**
1. "What's the post about?"
2. "Tone?" (Thoughtful / Casual / Community-focused / Technical)
3. "Image style?"
4. "Quality tier?"

---

## SNAPCHAT WORKFLOWS

### Snapchat Story
**Command:** `snap-story`
**Dimensions:** 1080x1920 (9:16)
**Questions:**
1. "Story concept?"
2. "Visual style?" (Fun & playful / Branded / UGC-style / Event coverage)
3. "Text/sticker elements?"
4. "Quality tier?"

### Snapchat Ad
**Command:** `snap-ad`
**Dimensions:** 1080x1920 (9:16)
**Questions:**
1. "What are you promoting?"
2. "Ad style?" (Full-screen takeover / Story ad / Collection ad)
3. "CTA?" (Swipe Up / Shop Now / Learn More)
4. "Target audience?" (Snapchat skews younger — 13-34)
5. "Quality tier?"

---

## WHATSAPP WORKFLOWS

### WhatsApp Status
**Command:** `wa-status`
**Dimensions:** 1080x1920 (9:16)
**Questions:**
1. "Status purpose?" (Personal update / Business promo / Event / Announcement)
2. "Visual style?" (Clean / Fun / Professional / Festive)
3. "Text overlay?"
4. "Quality tier?"

---

## GOOGLE ADS WORKFLOWS

### Google Display Ad (Rectangle)
**Command:** `gad-display-rect`
**Dimensions:** 300x250
**Questions:**
1. "What are you advertising?"
2. "Headline?" (under 30 characters)
3. "CTA?" (Learn More / Shop Now / Get Quote / Sign Up)
4. "Brand colors and logo?"
5. "Quality tier?"
**Prompt construction:** Use Gemini (text rendering). "Google display ad, 300x250 rectangle, clean layout, headline '[text]', CTA button '[CTA]', brand colors [colors], professional, high contrast, advertising design".

### Google Leaderboard Ad
**Command:** `gad-leaderboard`
**Dimensions:** 728x90
**Questions:** Same as rectangle but note: "This is a very wide, thin banner — keep text minimal and impactful."

### Google Skyscraper Ad
**Command:** `gad-skyscraper`
**Dimensions:** 160x600
**Questions:** Same as rectangle but note: "This is a tall, narrow sidebar ad — stack content vertically."

### Google Responsive Ad (Landscape)
**Command:** `gad-responsive-landscape`
**Dimensions:** 1200x628
**Questions:** Same as rectangle.

### Google Responsive Ad (Square)
**Command:** `gad-responsive-square`
**Dimensions:** 1200x1200
**Questions:** Same as rectangle.

---

## CROSS-PLATFORM WORKFLOWS

### Repurpose Workflow
**Command:** `repurpose`
**Trigger:** "repurpose this", "adapt for other platforms", "cross-post"
**Questions:**
1. "What's the source content?" (paste text / describe image / reference previous generation)
2. "Which platforms to adapt for?" (list platforms)
3. "Adapt tone per platform?" (Yes, optimize each / No, keep consistent)
4. "Quality tier?"
**Cost gate:** "Repurposing to [N] platforms will generate [N] images + [N] captions. Estimated cost: ~$X.XX. Proceed?"
**Generate:** Adapt dimensions, tone, hashtags, and format for each platform. Deliver all together.

### Batch Generate
**Command:** `batch-generate`
**Trigger:** "create a week of content", "batch create", "bulk generate"
**Questions:**
1. "How many pieces?" (e.g., 7 for a week, 30 for a month)
2. "Which platforms?"
3. "Content themes/topics for each?"
4. "Consistent style or varied?"
5. "Quality tier?"
**Cost gate:** "[N] pieces × $X.XX per piece = ~$X.XX total. Proceed?"

### Content Strategy & Calendar Wizard
**Trigger:** "content strategy", "content calendar", "plan my content"
**Questions:**
1. "Brand/business name?"
2. "One-sentence brand description?"
3. "Target audience?"
4. "Which platforms?" (select all that apply)
5. "Content types per platform?" (images/videos/carousels/text)
6. "3-5 content pillars/topics?"
7. "Brand voice/tone?"
8. "Brand colors?"
9. "Posting frequency per platform?" (daily/3x week/weekly)
10. "Quality tier?"
**THEN:** Calculate and display:
- Cost per post (by type)
- Daily cost
- Weekly cost
- Monthly cost
- Yearly cost
**THEN:** "Your content plan will cost approximately $X.XX/month ($X.XX/year). Approve? (yes/no)"
**THEN:** Only after "yes" → Save brand profile + content plan + set up automation.
**THEN:** "Where should completed content be delivered?" (OpenClaw control board / Download / Both)

### Recurring Automation Setup
**Trigger:** "schedule posts", "automate this", "set up daily posting"
**Questions:**
1. "What content to automate?" (reference a template or describe)
2. "Which platforms?"
3. "Frequency?" (Daily / Every other day / 3x per week / Weekly)
4. "What time of day?" (Morning / Afternoon / Evening / Custom)
5. "How long?" (1 week trial / 1 month / 3 months / Ongoing)
6. "Quality tier?"
7. "Auto-approve each post or queue for review?"
**THEN:** Calculate total cost:
- Per post: $X.XX
- Per day: $X.XX
- Per week: $X.XX
- Per month: $X.XX
- For full duration: $X.XX
**THEN:** "This automation will cost approximately $X.XX/month for [duration]. Approve? (yes/no)"
**THEN:** Only after explicit "yes" → Save schedule + activate cron.
**THEN:** Confirm: "Automation active. I'll generate [content type] for [platforms] every [frequency]. You can check status with 'show schedule' or cancel with 'cancel schedule'."
