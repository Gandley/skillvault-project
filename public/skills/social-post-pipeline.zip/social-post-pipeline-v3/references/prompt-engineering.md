# Prompt Engineering Guide for Content Generation

This document provides the templates and strategies for generating high-quality text, image, and video content using the OpenRouter API.

## Text Generation Prompts

When generating text posts, use these templates to ensure the LLM outputs the correct format and tone.

### 1. The "Thought Leader" Post (LinkedIn/Twitter)
**Prompt:**
> Act as a top-tier copywriter and thought leader in the [Industry/Niche] space. Write a compelling [Platform] post about [Topic].
>
> Requirements:
> - Start with a strong, counter-intuitive hook (under 10 words).
> - Share a brief personal anecdote or observation related to the topic.
> - Provide 3 actionable takeaways or insights.
> - End with a thought-provoking question to drive comments.
> - Tone: Professional, insightful, slightly conversational.
> - Length: [Short/Medium/Long].
> - Include 3-5 relevant hashtags at the bottom.

### 2. The "Educational Carousel" Script (Instagram/LinkedIn)
**Prompt:**
> Write the text for a [Number]-slide educational carousel for [Platform] about [Topic].
>
> Requirements:
> - Slide 1 (Hook): A bold statement or question that makes the user stop scrolling.
> - Slides 2-[Number-1] (Body): Break down the topic into simple, digestible steps or facts. One core idea per slide. Keep text minimal (under 30 words per slide).
> - Slide [Number] (CTA): A clear call to action (e.g., "Save this for later," "Follow for more," "Link in bio").
> - Tone: Educational, clear, authoritative.

### 3. The "Direct Response Ad" Copy (Facebook/Google)
**Prompt:**
> Write direct response ad copy for [Product/Service] targeting [Target Audience].
>
> Requirements:
> - Primary Text: Focus on the main pain point of the audience and how the product solves it. Use the PAS (Problem-Agitation-Solution) framework.
> - Headline: Short, punchy, benefit-driven (under 40 characters).
> - Description: A brief supporting statement or social proof (under 30 characters).
> - Call to Action: [Learn More / Shop Now / Sign Up].
> - Tone: Persuasive, urgent, benefit-focused.

## Image Generation Prompts (Flux / Nano Banana)

When generating images, the prompt must be highly descriptive regarding style, lighting, and composition.

### 1. Product Photography
**Prompt Structure:**
> [Subject/Product], [Setting/Background], [Lighting], [Camera Angle/Shot Type], [Style/Vibe], high resolution, photorealistic, 8k, highly detailed.
>
> **Example:** A sleek, modern smartwatch, resting on a dark slate table, dramatic studio lighting with soft shadows, macro close-up shot, minimalist and premium aesthetic, high resolution, photorealistic, 8k, highly detailed.

### 2. Lifestyle / Editorial
**Prompt Structure:**
> [Subject/Person doing an action], [Environment/Location], [Time of Day/Lighting], [Mood/Atmosphere], shot on [Camera Type/Film Stock], cinematic, candid.
>
> **Example:** A young professional woman working on a laptop in a bright, airy coffee shop, morning sunlight streaming through the window, warm and productive atmosphere, shot on 35mm film, cinematic, candid.

### 3. Abstract / Conceptual (For Backgrounds or Metaphors)
**Prompt Structure:**
> Abstract representation of [Concept], [Colors/Palette], [Shapes/Textures], [Lighting/Effects], 3D render, Octane render, unreal engine 5, masterpiece.
>
> **Example:** Abstract representation of artificial intelligence and data flow, glowing neon blue and purple colors, geometric floating shapes and digital grids, volumetric lighting, 3D render, Octane render, unreal engine 5, masterpiece.

## Video Generation Prompts (Veo 3.1 / Sora)

Video prompts require explicit instructions on motion, camera movement, and duration.

### 1. Cinematic Establishing Shot
**Prompt Structure:**
> [Camera Movement], [Subject/Scene], [Lighting/Time of Day], [Atmosphere/Style], high quality, cinematic, 4k.
>
> **Example:** Slow panning shot from left to right, revealing a bustling futuristic cityscape with flying cars, neon lights illuminating the rainy streets at night, cyberpunk aesthetic, high quality, cinematic, 4k.

### 2. Product Showcase (Motion)
**Prompt Structure:**
> [Action/Movement], [Product], [Environment], [Lighting], [Camera Angle], smooth motion, commercial quality.
>
> **Example:** A slow, 360-degree orbit around a new luxury perfume bottle, resting on a velvet pedestal, dramatic spotlighting highlighting the glass facets, macro shot, smooth motion, commercial quality.

### 3. Lifestyle Action
**Prompt Structure:**
> [Subject doing an action], [Environment], [Camera Movement/Style], [Mood], realistic, high definition.
>
> **Example:** A person running through a dense, misty forest, tracking shot following from behind, early morning light filtering through the trees, energetic and adventurous mood, realistic, high definition.
