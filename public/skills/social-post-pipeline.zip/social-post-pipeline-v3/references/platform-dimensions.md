# Social Media Platform Dimensions Database

This document contains the complete, up-to-date dimensions for every major social media platform. **Always** reference these dimensions when generating image or video content to ensure perfect cropping and display.

## Instagram

| Content Type | Dimensions (px) | Aspect Ratio | Notes |
|---|---|---|---|
| Feed Post (Square) | 1080 × 1080 | 1:1 | Classic format |
| Feed Post (Portrait) | 1080 × 1350 | 4:5 | **RECOMMENDED** for maximum feed space |
| Feed Post (Landscape) | 1080 × 566 | 1.91:1 | Best for wide photography |
| Story / Reel | 1080 × 1920 | 9:16 | Keep text within safe zones (avoid top/bottom 250px) |
| Carousel | 1080 × 1080 or 1080 × 1350 | 1:1 or 4:5 | Up to 20 slides. Keep aspect ratio consistent across all slides. |
| Profile Photo | 320 × 320 | 1:1 | Displays as circle |
| IGTV Cover | 420 × 654 | 1:1.55 | |
| Ad (Feed) | 1080 × 1080 or 1080 × 1350 | 1:1 or 4:5 | |
| Ad (Story) | 1080 × 1920 | 9:16 | |

## Facebook

| Content Type | Dimensions (px) | Aspect Ratio | Notes |
|---|---|---|---|
| Feed Post (Landscape) | 1200 × 630 | 1.91:1 | Standard link preview size |
| Feed Post (Square) | 1080 × 1080 | 1:1 | |
| Story | 1080 × 1920 | 9:16 | |
| Cover Photo | 820 × 312 | 2.62:1 | Desktop: 820x312, Mobile: 640x360 |
| Profile Photo | 170 × 170 | 1:1 | Displays as circle |
| Event Cover | 1920 × 1005 | 1.91:1 | |
| Ad (Feed) | 1200 × 628 or 1080 × 1080 | 1.91:1 or 1:1 | |
| Ad (Story) | 1080 × 1920 | 9:16 | |
| Carousel Ad | 1080 × 1080 | 1:1 | Per card |
| Video | 1280 × 720 (min) | 16:9 | 1080x1920 for vertical |

## Twitter / X

| Content Type | Dimensions (px) | Aspect Ratio | Notes |
|---|---|---|---|
| Post Image (Landscape) | 1600 × 900 | 16:9 | Standard in-stream photo |
| Post Image (Square) | 1080 × 1080 | 1:1 | |
| Header | 1500 × 500 | 3:1 | Account for profile picture overlap |
| Profile Photo | 400 × 400 | 1:1 | Displays as circle |
| Card Image | 800 × 418 | 1.91:1 | Link preview |
| Ad | 1200 × 675 or 1080 × 1080 | 16:9 or 1:1 | |

## LinkedIn

| Content Type | Dimensions (px) | Aspect Ratio | Notes |
|---|---|---|---|
| Post Image (Landscape) | 1200 × 628 | 1.91:1 | Standard link preview |
| Post Image (Square) | 1080 × 1080 | 1:1 | |
| Article Cover | 1200 × 644 | 1.86:1 | |
| Company Page Cover | 1128 × 191 | 5.9:1 | |
| Profile Photo | 400 × 400 | 1:1 | Displays as circle |
| Ad | 1200 × 628 or 1080 × 1080 | 1.91:1 or 1:1 | |
| Carousel (Document) | 1080 × 1080 or 1080 × 1350 | 1:1 or 4:5 | Per page (PDF upload) |

## TikTok

| Content Type | Dimensions (px) | Aspect Ratio | Notes |
|---|---|---|---|
| Video | 1080 × 1920 | 9:16 | Keep text in safe zones (avoid right edge and bottom) |
| Profile Photo | 200 × 200 | 1:1 | Displays as circle |
| Ad | 1080 × 1920 | 9:16 | |

## YouTube

| Content Type | Dimensions (px) | Aspect Ratio | Notes |
|---|---|---|---|
| Thumbnail | 1280 × 720 | 16:9 | Max 2MB |
| Shorts | 1080 × 1920 | 9:16 | |
| Channel Banner | 2560 × 1440 | 16:9 | Safe area for text/logos: 1546 x 423 |
| Profile Photo | 800 × 800 | 1:1 | Displays as circle |
| Video (HD) | 1920 × 1080 | 16:9 | |
| Video (4K) | 3840 × 2160 | 16:9 | |
| End Screen | 1920 × 1080 | 16:9 | |
| Ad (Display) | 300×250, 300×60, 728×90 | Various | |

## Pinterest

| Content Type | Dimensions (px) | Aspect Ratio | Notes |
|---|---|---|---|
| Standard Pin | 1000 × 1500 | 2:3 | Recommended ratio |
| Idea Pin | 1080 × 1920 | 9:16 | |
| Profile Photo | 165 × 165 | 1:1 | Displays as circle |
| Board Cover | 222 × 150 | 1.48:1 | |
| Ad | 1000 × 1500 | 2:3 | |

## Threads

| Content Type | Dimensions (px) | Aspect Ratio | Notes |
|---|---|---|---|
| Post Image (Square) | 1080 × 1080 | 1:1 | |
| Post Image (Portrait) | 1080 × 1350 | 4:5 | |
| Profile Photo | 320 × 320 | 1:1 | Syncs with Instagram |

## Bluesky

| Content Type | Dimensions (px) | Aspect Ratio | Notes |
|---|---|---|---|
| Post Image (Landscape) | 1200 × 675 | 16:9 | |
| Post Image (Square) | 1080 × 1080 | 1:1 | |
| Profile Photo | 400 × 400 | 1:1 | Displays as circle |
| Banner | 1500 × 500 | 3:1 | |

## Snapchat

| Content Type | Dimensions (px) | Aspect Ratio | Notes |
|---|---|---|---|
| Snap / Story | 1080 × 1920 | 9:16 | |
| Ad | 1080 × 1920 | 9:16 | |
| Profile Photo | 320 × 320 | 1:1 | |

## WhatsApp

| Content Type | Dimensions (px) | Aspect Ratio | Notes |
|---|---|---|---|
| Status | 1080 × 1920 | 9:16 | |
| Profile Photo | 500 × 500 | 1:1 | Displays as circle |

## Google Ads

| Content Type | Dimensions (px) | Aspect Ratio | Notes |
|---|---|---|---|
| Display (Square/Rect) | 300×250, 336×280 | Various | |
| Display (Leaderboard) | 728×90, 320×50, 970×250 | Various | |
| Display (Skyscraper) | 160×600 | Various | |
| Responsive (Landscape) | 1200 × 628 | 1.91:1 | |
| Responsive (Square) | 1200 × 1200 | 1:1 | |
| Responsive (Marketing) | 600 × 314 | 1.91:1 | |
