# Social Post Pipeline API Reference

## Control Board API

Base URL: `https://control.clawlauncher.io`

### Authentication
```
Authorization: Bearer {CONTROLBOARD_API_TOKEN}
X-Workspace-Id: {workspace_id}
```

### List Workspaces
```
GET /api/workspaces
Authorization: Bearer {TOKEN}
```

**Response:**
```json
{
  "workspaces": [
    {
      "id": "69d3f36887058987d24aa37a",
      "name": "qwe",
      "slug": "qwe",
      "owner_id": "69cc5124de0e5bb0c5b6f2fa"
    }
  ]
}
```

### Create Workspace
```
POST /api/workspaces
Authorization: Bearer {TOKEN}
Content-Type: application/json

{
  "name": "My Social Posts",
  "slug": "my-social-posts"
}
```

**Response:**
```json
{
  "id": "69d3f36887058987d24aa37a",
  "name": "My Social Posts",
  "slug": "my-social-posts",
  "owner_id": "69cc5124de0e5bb0c5b6f2fa"
}
```

### List Social Posts
```
GET /api/social-posts?status={status}
Authorization: Bearer {TOKEN}
X-Workspace-Id: {workspace_id}
```

**Query Parameters:**
- `status` - Filter by status: `big_idea`, `approved`, `scheduled`, `approved_post`, `published`

### Create Social Post
```
POST /api/social-posts
Authorization: Bearer {TOKEN}
X-Workspace-Id: {workspace_id}
Content-Type: application/json

{
  "title": "Post Title",
  "description": "Post description",
  "caption": "Post caption",
  "image_url": "https://example.com/image.jpg",
  "platforms": ["instagram", "x"],
  "format": "image",
  "status": "big_idea"
}
```

**Required Fields:**
- `title` - Post title
- `description` - Post description
- `caption` - Social media caption
- `status` - Must be "big_idea" for drafts

### Update Social Post Content (PUT)
```
PUT /api/social-posts
Authorization: Bearer {TOKEN}
X-Workspace-Id: {workspace_id}
Content-Type: application/json

{
  "id": "post_id_here",
  "action": "update_content",
  "image_url": "https://example.com/image.jpg",
  "platforms": ["instagram", "youtube"],
  "platform_captions": {
    "instagram": "Caption text",
    "youtube": "YouTube caption"
  }
}
```

### Update Social Post Status (PUT)
```
PUT /api/social-posts
Authorization: Bearer {TOKEN}
X-Workspace-Id: {workspace_id}
Content-Type: application/json

{
  "id": "post_id_here",
  "action": "scheduled"
}
```

**Available actions:**
- `update_content` — Update image_url, platforms, platform_captions
- `big_idea` | `approved` | `scheduled` | `approved_post` | `published` | `rejected` — Change status

**Note:** Response contains `status` field with the current status

## Letterman API

Base URL: `https://api.letterman.ai`

### Upload Image
```
POST /api/ai/images
Authorization: Bearer {LETTERMAN_API_KEY}
Content-Type: multipart/form-data

images=@/path/to/image.png
```

**Response:**
```json
{
  "imageUrls": ["https://cdn.letterman.ai/images/xxx.jpg"]
}
```

## OpenRouter API

Base URL: `https://openrouter.ai/api/v1`

### Generate Content
```
POST /chat/completions
Authorization: Bearer {OPENROUTER_API_KEY}
Content-Type: application/json

{
  "model": "anthropic/claude-3.5-sonnet",
  "messages": [
    {
      "role": "system",
      "content": "You are an expert social media content creator."
    },
    {
      "role": "user",
      "content": "Create Instagram content about..."
    }
  ]
}
```
