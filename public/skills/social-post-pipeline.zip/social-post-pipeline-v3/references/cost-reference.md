# OpenRouter Cost Reference & Budgeting

This document outlines the pricing for the recommended OpenRouter models used by the `content-creator-godfather` skill. **The skill prioritizes FREE models by default** to ensure maximum cost efficiency for all content generation tasks.

## Cost Efficiency Tiers

The skill categorizes all models into four distinct tiers. You can set your preferred tier using the `--tier` flag or by configuring your default preferences.

### Tier 1: FREE ($0.00)
These models are completely free to use on OpenRouter. They are the default choice for all text generation tasks and should be used whenever possible.

**Text Generation (Free):**
*   `qwen/qwen3.6-plus:free` - Best overall free model, 1M context window, excellent for marketing copy.
*   `stepfun/step-3.5-flash:free` - Fast reasoning model, 256K context.
*   `nvidia/nemotron-3-super:free` - 120B parameter model, excellent for complex planning.
*   `arcee-ai/trinity-large-preview:free` - Excels at creative writing and storytelling.
*   `nvidia/nemotron-nano-12b-2-vl:free` - Multimodal model, good for vision tasks.
*   `openai/gpt-oss-120b:free` - High-reasoning open-weight model from OpenAI.
*   `meta-llama/llama-3.3-70b-instruct:free` - Excellent instruction-following model.
*   `openrouter/free` - Auto-router that automatically selects the best available free model.

### Tier 2: Budget ($0.001 - $0.05 per generation)
These models offer excellent quality at a minimal cost. They are the recommended choice for image generation when free options are not available or sufficient.

**Image Generation (Budget):**
*   `google/gemini-2.5-flash-image` (Nano Banana) - ~$0.003 per image. Cheapest verified model, great quality and text rendering. **VERIFIED WORKING.**
*   `black-forest-labs/flux.2-klein-4b` - ~$0.014 per image. Fast and cost-effective FLUX model.
*   `sourceful/riverflow-v2-fast` - ~$0.02 per 1K image. Extremely fast, SOTA performance.
*   `sourceful/riverflow-v2-fast-preview` - $0.03 flat rate per image.
*   `bytedance-seed/seedream-4.5` - $0.04 flat rate per image. Excellent multi-image composition.

**Video Generation (Budget):**
*   `alibaba/wan-2.6` - $0.04 per second (480p), $0.08 per second (720p).

### Tier 3: Standard ($0.05 - $0.15 per generation)
These models provide high-quality outputs suitable for professional use cases where budget models might fall short.

**Image Generation (Standard):**
*   `google/gemini-3.1-flash-image-preview` (Nano Banana 2) - ~$0.03 - $0.05 per image. Pro-level visual quality at Flash speed.
*   `sourceful/riverflow-v2-max-preview` - $0.075 flat rate per image.
*   `sourceful/riverflow-v2-pro` - $0.15 per 1K/2K image. Top-tier control and perfect text rendering.

**Video Generation (Standard):**
*   `alibaba/wan-2.6` - $0.12 per second (1080p).
*   `google/veo-3.1` - $0.20 per second (720p/1080p, no audio).

### Tier 4: Premium ($0.15+ per generation)
These models represent the absolute state-of-the-art and should be used when quality is the only metric that matters.

**Image Generation (Premium):**
*   `google/gemini-3-pro-image-preview` (Nano Banana Pro) - ~$0.15+ per image. Industry-leading text rendering and multi-image blending.
*   `openai/gpt-5-image-mini` - Premium pricing based on token usage.
*   `openai/gpt-5-image` - Premium pricing based on token usage.

**Video Generation (Premium):**
*   `openai/sora-2-pro` - $0.30 per second (720p), $0.50 per second (1080p).
*   `google/veo-3.1` - $0.40 per second (720p/1080p with audio), $0.60 per second (4K with audio).
*   `bytedance/seedance-1-5-pro` - $1.20 per video token.

## Recommended Cost-Effective Workflows

To maximize your content creation budget, we recommend the following workflows:

1.  **Ideation & Copywriting:** Always use `qwen/qwen3.6-plus:free` or `openrouter/free`. This ensures all your text generation costs remain at $0.00.
2.  **Daily Social Media Images:** Use `google/gemini-2.5-flash-image` (Nano Banana). At ~$0.003 per image, you can generate 300+ images for just $1.00.
3.  **High-Quality Campaign Images:** Use `google/gemini-3.1-flash-image-preview` (Nano Banana 2) for pro-level visual quality.
4.  **Short-Form Video (Reels/TikToks):** Use `alibaba/wan-2.6` at 720p ($0.08/sec). A 5-second clip will cost $0.40.

## Estimating Costs

You can estimate the cost of any generation task before running it using the `estimate-cost` command:

```bash
python3 scripts/openrouter_generate.py estimate-cost --type image --count 5 --tier budget
```

The skill will always present the FREE option first in the estimation display.

## Budgeting & Automation Rules

1.  **Always Estimate First:** Before calling the OpenRouter API, calculate the estimated cost based on the selected model and quantity.
2.  **Require Confirmation:** Display the estimate to the user and require explicit confirmation (e.g., "Proceed? (yes/no)") before generating.
3.  **Monthly Projections:** For scheduled or recurring tasks (e.g., "Post daily to Instagram"), calculate the daily cost and multiply by 30 to show the projected monthly spend. Require explicit approval for this recurring cost.
4.  **Track Spending:** Log all generation costs to `~/.openclaw-content-creator/config/budget.json` to monitor cumulative spending against user-defined limits.
