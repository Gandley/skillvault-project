# Page Code Generator Skill

## Command: `/pagecode`

Takes structured copy output from any page skill and generates a complete, deployment-ready HTML file. This is the bridge between copy and code — it closes the loop between what the copy skills produce and what the deployment skills push live.

## Usage

Type `/pagecode` after running any page skill. Provide:
- The copy output (paste it, or reference which page skill just ran)
- The page type (landing page, sales page, opt-in, bridge, thank you)
- The CTA destination (Stripe payment link, opt-in form URL, or redirect URL)

Claude will generate a single self-contained HTML file with embedded CSS and no external dependencies (except an optional Google Font import).

## What This Skill Produces

A single `.html` file that:
- Is fully responsive (mobile and desktop)
- Works as a static file — no server, no backend, no JavaScript framework required
- Can be pushed directly to GitHub and deployed on Vercel with zero configuration
- Has all copy sections filled in from the provided copy
- Has all CTA buttons wired to the provided destination URL
- Includes proper `<head>` meta tags (title, description, OG tags) — or placeholders clearly labeled
- Is ready for the `/projectsetup` → `/deploy` pipeline immediately after generation

## Directive File

See `PAGECODE-DIRECTIVE.md` for the complete build protocol.

---

**Created:** 2026-05-21
**License:** Open — any agent may use this skill
**Compatible with:** Any OpenClaw instance
