# OPENCLAW PAGE CODE GENERATOR DIRECTIVE

**Purpose:** Transform structured copy output from any page skill into a single, complete, deployment-ready HTML file. This skill produces the actual page that goes live — not a wireframe, not a mockup, not a template to fill in later.

**Core Principle:** Every HTML file this skill produces must work immediately after generation. No broken links, no unfilled placeholders in the code itself, no missing sections. Every placeholder must be visibly labeled so a human can find and fill it — but the page must render correctly even with placeholders in place.

---

## INPUT VARIABLES

| Variable | Purpose |
|---|---|
| `copy_source` | The structured copy output from a page skill (paste or reference) |
| `page_type` | landing / sales / optin / bridge / thankyou |
| `cta_url` | The destination URL for all CTA buttons (Stripe link, form URL, redirect) |
| `brand_name` | The name of the brand or product — used in title tag and footer |
| `meta_title` | Optional — if /metacopy has already run, use its output |
| `meta_description` | Optional — if /metacopy has already run, use its output |
| `color_scheme` | Optional — primary color in hex (defaults to clean dark if not provided) |

---

## STEP 1 — INPUT EVALUATION

Before writing a single line of HTML, evaluate the inputs:

### 1. Copy Completeness Check

Scan the provided copy for:
- `[PLACEHOLDER]` markers — note how many and which sections
- Missing sections for the page type (e.g. a landing page with no guarantee section)
- CTA URL — if blank or missing, flag and use `#` as a safe fallback with a visible note

Output:
```
## INPUT EVALUATION
---
Copy completeness: [Complete / X placeholders found — listed below]
Missing sections: [None / list any gaps]
CTA URL: [Confirmed / Missing — using fallback #]
Color scheme: [User-provided: #XXXXXX / Using default]
---
```

### 2. Page Type Detection

If page_type is not provided, infer it from the copy structure:
- Has opt-in form → `optin`
- Has price + guarantee + long sections → `sales`
- Short, single CTA, no price → `landing` or `bridge`
- Has "thank you" / "you're in" confirmation → `thankyou`

State the detected page type before proceeding.

---

## STEP 2 — HTML BUILD PROTOCOL

### UNIVERSAL RULES (apply to every page type)

**Structure:**
- Single `.html` file — all CSS embedded in `<style>` tags, no external stylesheets
- Google Fonts import is acceptable (one font family maximum)
- No JavaScript frameworks — vanilla JS only, and only if functionally required
- No external CSS libraries (no Bootstrap, no Tailwind CDN)
- All images referenced as `[IMAGE-URL-PLACEHOLDER]` with a visible comment noting what the image should contain
- All icon use via Unicode characters or CSS — no icon font libraries

**Meta Tags (always include):**
```html
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>[Meta title from /metacopy output or brand_name + primary outcome]</title>
<meta name="description" content="[Meta description from /metacopy output or generated from copy]">
<meta property="og:title" content="[OG title]">
<meta property="og:description" content="[OG description]">
<meta property="og:image" content="[OG-IMAGE-PLACEHOLDER]">
<meta property="og:type" content="website">
```

If `/metacopy` output is not provided, generate appropriate meta tags from the copy. Label any unfilled values with `[PLACEHOLDER — fill before launch]`.

**Thank you pages:** Always add `<meta name="robots" content="noindex, nofollow">`.

**Typography:**
- Import one Google Font — default: `Inter` (clean, readable, professional)
- Body: 16–18px, line-height 1.6–1.8
- Headlines: sized proportionally to page section importance
- Maximum line width: 680px for body copy (readability)

**Color defaults (if no color_scheme provided):**
```css
--color-bg: #ffffff;
--color-text: #1a1a1a;
--color-heading: #0f0f0f;
--color-primary: #1a1a1a;
--color-primary-text: #ffffff;
--color-accent: #f5f5f5;
--color-border: #e5e5e5;
--color-muted: #666666;
```

If a primary color is provided, derive:
- Primary button background: user color
- Primary button text: white (or dark if user color is light)
- Accent sections: 8% opacity of user color
- All other colors remain neutral

**Responsive breakpoints:**
- Mobile-first CSS
- Single breakpoint at `768px` for desktop layout
- Navigation (if any) collapses to stacked on mobile
- CTA buttons full-width on mobile

**CTA Buttons — universal rules:**
- Every CTA button links to `cta_url`
- `target="_blank"` on all external links (Stripe, external forms)
- Button style: solid, high-contrast, clearly clickable
- Never use `<form>` tags for CTA buttons — use `<a href="...">` styled as buttons
- Button text pulled directly from the copy output

**Placeholders — labeling standard:**
All unfilled content must be wrapped in HTML comments AND visually visible on the page during development:
```html
<!-- PLACEHOLDER: Replace this with real testimonial photo -->
<div class="placeholder-img">[PHOTO PLACEHOLDER]</div>
```

---

## STEP 3 — PAGE TYPE BUILD SPECIFICATIONS

### LANDING PAGE

**Section order:**
1. `<nav>` — minimal: logo/brand name left, single CTA button right (optional, can be omitted)
2. Hero section — full-width, headline + sub + CTA + micro reassurance
3. Problem statement section — dark or accent background
4. Mechanism / how it works section — alternating or icon-based layout
5. Social proof / testimonials section — card grid or pull-quote style
6. Offer + CTA stack section
7. Guarantee section — distinct visual treatment (badge style or bordered box)
8. Final CTA section — closing headline + button
9. `<footer>` — brand name, minimal links, legal placeholder

**Layout style:** Single column, centered, max-width 800px content area, full-width section backgrounds for visual rhythm.

---

### SALES PAGE

**Section order:**
1. Pre-headline bar (optional) — short attention bar above nav for urgency
2. `<nav>` — minimal or none (sales pages often remove nav to reduce exits)
3. Hero section
4. Social proof intro — early trust signal before the pitch
5. Problem agitation section
6. Mechanism / why this is different
7. Proof + results section — testimonial grid or result callouts
8. What you get — offer breakdown with value stack
9. Objection handling section — FAQ style or flowing copy
10. Future visualization / identity shift section
11. Guarantee section
12. Urgency + CTA stack
13. Final CTA
14. Footer — minimal

**Layout style:** Single column, max-width 700px content, generous section padding. Sales pages use more vertical space than landing pages — do not compress.

**No navigation links** — sales pages do not give readers an exit path. Nav is either removed entirely or contains only the CTA button.

---

### OPT-IN PAGE

**Section order:**
1. Minimal header — logo/brand name only, no navigation
2. Hero section — headline + sub-headline + form above the fold
3. Bullet benefit stack — directly below or beside the form
4. Social proof — one pull-quote maximum (optional, only if Tier 1 proof available)
5. Footer — minimal, privacy note, unsubscribe mention

**Form build:**
```html
<form action="[FORM-ACTION-URL-PLACEHOLDER]" method="POST">
  <input type="text" name="first_name" placeholder="First name" required>
  <input type="email" name="email" placeholder="Enter your best email" required>
  <button type="submit">[CTA BUTTON TEXT FROM COPY]</button>
</form>
<p class="reassurance">[MICRO REASSURANCE LINE FROM COPY]</p>
```

Note: `[FORM-ACTION-URL-PLACEHOLDER]` must be replaced with the actual form handler URL (ConvertKit, Mailchimp, ActiveCampaign, etc.). Label this clearly.

**Layout constraint:** Form must be above the fold on desktop. If the headline + sub-headline + form exceed viewport height at 768px, shorten headline or reduce padding.

---

### BRIDGE PAGE

**Section order:**
1. No navigation — bridge pages have no exits
2. Hero section — pattern interrupt headline, curiosity copy
3. Story or proof snippet
4. Identity bridge paragraph
5. CTA section — soft CTA button + micro reassurance
6. Optional: video embed placeholder (if VSL+text mode)

**Video embed placeholder:**
```html
<!-- PLACEHOLDER: Replace with actual video embed code -->
<div class="video-placeholder">
  <div class="video-inner">
    <p>▶ [VIDEO EMBED PLACEHOLDER — paste iframe or video URL here]</p>
  </div>
</div>
```

**Layout style:** Minimal, focused, no distractions. Max-width 640px. Bridge pages should feel lighter than landing or sales pages.

---

### THANK YOU PAGE

**Section order:**
1. No navigation
2. Confirmation headline + sub
3. What happens next — numbered steps
4. Upsell block (conditional — only if copy includes one)
5. Community/social invite (conditional — only if copy includes one)
6. Reassurance close
7. Footer — support email placeholder, brand name

**Special handling:**
- Add `<meta name="robots" content="noindex, nofollow">` — always
- Access link placeholder must be clearly visible:
  ```html
  <!-- PLACEHOLDER: Replace with actual access link -->
  <a href="[ACCESS-LINK-PLACEHOLDER]" class="btn-primary">Access Your Purchase →</a>
  ```

---

## STEP 4 — CSS ARCHITECTURE

Write all CSS in a single `<style>` block in the `<head>`. Structure it in this order:

```css
/* 1. CSS Variables */
:root { ... }

/* 2. Reset + Base */
*, *::before, *::after { box-sizing: border-box; }
body { ... }

/* 3. Typography */
h1, h2, h3, h4, p, a { ... }

/* 4. Layout utilities */
.container { max-width: [width]px; margin: 0 auto; padding: 0 24px; }
.section { padding: 80px 0; }

/* 5. Components */
/* Buttons */
/* Cards */
/* Forms */
/* Proof blocks */

/* 6. Page sections (in order of appearance) */
/* Nav */
/* Hero */
/* [Each section] */
/* Footer */

/* 7. Responsive overrides */
@media (max-width: 768px) { ... }
```

**Button styles — required variants:**
```css
.btn-primary { /* Main CTA — high contrast, full color */ }
.btn-secondary { /* Secondary CTA — outlined or lighter */ }
.btn-ghost { /* Soft CTA for bridge/thank you pages */ }
```

**All buttons must have:**
- Visible hover state (color shift or shadow)
- `cursor: pointer`
- Adequate padding (min 14px vertical, 28px horizontal)
- Readable font size (min 16px)
- No underlines

---

## STEP 5 — FILE DELIVERY

**Output the complete HTML file** — not a summary, not a partial, not a code block that stops early.

The file must:
- Open and render correctly in a browser with zero modifications
- Have all copy sections populated from the input
- Have all CTA buttons pointing to `cta_url` (or `#` with a visible placeholder note if URL was missing)
- Have all placeholder items clearly labeled with HTML comments
- Be named: `index.html`

**After the HTML output, deliver a deployment checklist:**

```
## BEFORE GOING LIVE — CHECKLIST

Placeholders to fill:
- [ ] [List every placeholder found in the file with its location]

Copy to verify:
- [ ] All headlines match approved copy
- [ ] Price is correct
- [ ] Guarantee details are accurate
- [ ] CTA URL is live and working

Technical checks:
- [ ] Open in mobile browser — layout looks correct
- [ ] All buttons click through to the correct destination
- [ ] Meta title and description look correct when pasted into a social share previewer
- [ ] Thank you page noindex tag is present (if applicable)

Ready to deploy:
- [ ] Run /projectsetup if GitHub + Vercel aren't configured
- [ ] Run /deploy to push live
```

---

## RULES

- ✅ Always output the complete file — never truncate
- ✅ Always label every placeholder visibly
- ✅ Never output broken HTML — validate mentally before delivering
- ✅ Never use JavaScript frameworks or external CSS libraries
- ✅ Never use `<form>` for CTA buttons — use `<a>` styled as buttons
- ✅ Always include responsive CSS
- ✅ Always include meta tags (filled or clearly placeholdered)
- ✅ Sales pages: remove navigation to eliminate exit paths
- ✅ Thank you pages: always add noindex tag
- ✅ Opt-in pages: form must be above the fold on desktop

---

## SUCCESS STATE

When this skill completes, the user has:
- [ ] A single `index.html` file that renders correctly in a browser
- [ ] All copy from the page skill integrated into the HTML
- [ ] CTA buttons wired to the correct destination
- [ ] All placeholders labeled and inventoried in the deployment checklist
- [ ] A clear list of what to fill in before the page goes live
- [ ] A file that can be pushed to GitHub and deployed on Vercel immediately

---

*License: Open — any agent may use this skill*
*Created: 2026-05-21*
