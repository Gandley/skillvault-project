# OPENCLAW SALES PAGE DIRECTIVE

**Purpose:** Generate fully built, long-form, direct-response sales copy for any digital product or offer priced at $27 or above.

**Core Principle:** You are not writing a short-form offer page. You are building a psychological conversion stack. Do not shorten. Do not summarize. Do not optimize for brevity. Optimize for psychological completeness and conversion depth.

---

## INPUT VARIABLES

Before building, collect and hold these inputs. Every copy decision flows from them.

| Variable | Purpose |
|---|---|
| `product_name` | What is being sold |
| `target_audience` | Who this is for — be specific |
| `price_point` | Sets resistance level and required proof depth |
| `core_mechanism` | What makes this work — the unique approach or system |
| `primary_outcome` | The single most important result the buyer gets |
| `time_to_result` | How fast they get the result (if applicable — e.g. "in 7 days", "within 30 minutes") |
| `proof_available` | Testimonials, screenshots, numbers, case studies — what exists |
| `guarantee` | What protection the buyer has |
| `urgency_type` | What creates real urgency — pricing window, limited spots, bonus expiry |

---

## 1 — EXTERNAL PROOF LAYER

**Must include:**
- Quantified results — numbers, outcomes, timeframes
- Time-to-result breakdown if applicable (e.g. a step-by-step breakdown of how fast the mechanism works)
- Revenue or result validation (first win, first 24 hours, before/after)
- Screenshot or result references (describe them even if placeholders)
- At least one testimonial (real or early adopter style)
- Conversion rate or success rate reference if available

**Rule:** No vague claims. Everything must feel measurable. Replace all placeholders before launch.

---

## 2 — SPECIFIC OUTCOME ANCHORING

**Do not sell the feature or the method. Sell the tangible result it produces.**

Structure every outcome statement as: **[Specific result] in [timeframe] without [common obstacle]**

Examples of the pattern (replace with the actual product's outcomes):
- "[Specific deliverable] in [X days] without needing [thing they fear needing]"
- "[Measurable result] before [timeframe that feels fast]"
- "[Outcome] even if [biggest objection they have]"

**Rule:** Anchor every speed or efficiency claim to a real, tangible outcome the buyer can picture. Never sell "speed" alone.

---

## 3 — OBJECTION DOMINATION SECTION

**Pre-handle at least 10 objections. Identify the real objections for this specific offer and audience.**

Universal objections that apply to almost any offer:
- I don't have time
- I've bought things like this before and they didn't work
- I never finish what I start
- I'm not technical enough
- I don't have an audience
- What if this doesn't work for my niche?
- I can't afford it right now
- I need to think about it
- This sounds too good to be true
- What if I can't get a refund?

**Rule:** Each objection must be addressed with both logic (the rational counter) and reassurance (the emotional resolution). Never dismiss an objection — earn past it.

---

## 4 — IDENTITY TRANSFORMATION LAYER

**Shift from:** "Here's what this product does"
**To:** "Here's who you become."

**The buyer should see themselves as:**
- Someone who ships instead of planning
- Someone who operates at a different level than peers
- An early mover who acts while others wait
- A person who builds real assets, not just dreams

**Rule:** Create a clear identity upgrade. The reader should feel different about themselves by the end of this section — not just informed about the product.

---

## 5 — FUTURE VISUALIZATION SCENE

**Include at least 2 vivid, specific future moments — written in second person.**

Structure: Put the reader inside a specific moment after they've gotten the result.

Examples of the structure (replace with outcomes relevant to this product):
- "It's [day/time]. You just [did the thing]. You're looking at [the result]. For the first time, [emotional shift]."
- "Imagine [specific scenario]. You're [doing the thing]. [The proof that it worked]. That's [X days/weeks] from today."

**Rule:** Make it specific and sensory. Vague future scenes don't convert. The more precisely you can describe the moment, the more real it feels.

---

## 6 — DIFFERENTIATION SECTION

**Clearly explain why this is NOT:**
- Another information product that tells them what to do without helping them do it
- Another system that requires tools, budget, or experience they don't have
- Another approach that works for some people but not for beginners (or their specific situation)

**Then explain:**
- What makes this mechanism different from everything else they've tried
- Why the approach produces results when others don't
- What changes structurally when they use this vs. doing it the old way

**Rule:** Differentiation must be specific to the actual mechanism. "Better" and "different" are not claims — they are placeholders. Replace them with real reasons.

---

## 7 — URGENCY MECHANISM

**Include at least one real urgency driver:**
- Founder or launch pricing closing on a specific date
- Price increasing after a specific number of sales
- Bonus stack expiring
- Limited access or enrollment window
- Early adopter tier with specific advantages

**Rule:** Urgency must be real. If there is no genuine urgency, do not manufacture false scarcity — instead, use opportunity cost urgency: what they lose by waiting. False urgency destroys trust when buyers notice it.

---

## 8 — LENGTH & AUTHORITY

**The page must be:**
- Long-form — minimum 2,500 words
- Structured with clear section headers
- Multi-section with visual rhythm variation
- Written with micro-headlines that function as standalone bold statements
- Pattern breaks between dense sections (one-line bold statements, short paragraphs)
- Rhythm variation — alternate between long explanatory paragraphs and short punchy lines

**Rule:** The page must feel like a serious, considered asset — not a rushed draft. If it reads like it took an afternoon to write, rewrite it.

---

## 9 — MECHANISM BREAKDOWN SECTION

**Break down exactly how the core mechanism works — step by step.**

Structure: Walk the reader through the process sequentially. Each step should:
- Have a clear label (Step 1, Phase 1, etc.)
- Explain what happens in that step
- Explain what the reader does vs. what the system/product does for them
- End with a micro-result or milestone

**Rule:** Make the mechanism feel engineered and logical — not mystical. Skeptical readers need to understand *why* it works, not just that it does. The breakdown removes the "too good to be true" feeling by making the logic visible.

---

## 10 — STRONG CALL-TO-ACTION STACK

**The CTA section must include:**
- Complete list of what they get — every component with a benefit attached
- What happens immediately after purchase — delivery method, access, first step
- The guarantee — timeframe, what it covers, how to use it
- Reinforced urgency — restated briefly
- Final identity hook — one line that closes on who they're becoming, not what they're buying

**Rule:** End with inevitability. The reader who makes it to the CTA is close — the job of this section is to make saying yes feel obvious and saying no feel like self-sabotage.

---

## TONE DIRECTIVE

**Voice:**
- Confident without arrogance
- Calm authority — not hype, not bro-marketing
- Slightly intense — this is a direct-response sales page, not a blog post
- Specific and measurable — never vague
- Speaks to the reader as a peer who's about to gain a real advantage

**Avoid:**
- Exclamation marks used for hype
- Superlatives without proof ("the best," "the most powerful")
- Urgency that sounds fake
- Corporate passive voice
- Hollow transformation language ("unlock your potential," "change your life")

**Adjust for price point:**
- $27–$97: faster pacing, lighter proof requirement, benefit-forward
- $97–$297: heavier mechanism explanation, stronger proof, more objection handling
- $297+: deep credibility, extensive proof, full identity transformation arc

---

## OUTPUT FORMAT

Deliver the full page in clearly labeled sections:

```
## [SECTION NAME]
---
[Full copy for that section]
---
```

Every section in full. Do not compress. Do not summarize. Minimum 2,500 words total output.

---

*License: Open — any agent may use this skill*
*Created: 2026-05-21*
