# SKILL: Project Setup
**Trigger:** `/projectsetup`
**Purpose:** Prepare a GitHub repository + Vercel project for future deployment skills.
**Job:** Setup and infrastructure only. No content generation, no live deployments, no file pushing.

---

## BEFORE STARTING — Check Deployment Setup

Credentials required:
- GitHub username + token
- Vercel token
- Vercel scope (saved from `/deploy`)

If GitHub is not connected:
> GitHub is not connected yet. Please run /deploy first.

If Vercel is not connected:
> Vercel is not connected yet. Please run /deploy first.

---

## STEP 1 — Get Project Name

Say:
> Let's set up your project destination.
>
> What would you like to name this project?
> - Keep it simple
> - Lowercase preferred
> - Use dashes instead of spaces (e.g. `my-project`)
> - This name will be used for both GitHub and Vercel

If name has spaces or invalid characters, suggest a cleaned version and confirm before using.

---

## STEP 2 — Verify GitHub Access

```powershell
$ghToken = "[TOKEN FROM CREDENTIAL STORE]"
$ghHeaders = @{ "Authorization" = "Bearer $ghToken"; "User-Agent" = "OpenClaw" }
$r = Invoke-RestMethod -Uri "https://api.github.com/user" -Headers $ghHeaders -TimeoutSec 10
Write-Host "GitHub user: $($r.login)"
```

If fails:
> I could not connect to GitHub with your saved setup. Please run /deploy again.

---

## STEP 3 — Choose Repository Owner

Ask:
> Do you want this repository under your **personal GitHub account**, or under a **GitHub organization**?

- Personal (default): use authenticated username
- Organization: ask for org name, verify access

---

## STEP 4 — Check Hobby + Private Org Repo Risk

**STOP** if ALL of these are true:
- Vercel scope is Hobby/personal team
- Repository will be under a GitHub organization
- Repository will be private

Say:
> This setup can cause deployment problems on Vercel Hobby. Private repositories owned by a GitHub organization are not supported for Hobby team deployments. Use a personal repository, make it public, or upgrade Vercel before continuing.

---

## STEP 5 — Check if GitHub Repo Already Exists

```powershell
$owner = "[authenticated username or org]"
$repoName = "[project-name]"
try {
    $repo = Invoke-RestMethod -Uri "https://api.github.com/repos/$owner/$repoName" -Headers $ghHeaders -TimeoutSec 10
    Write-Host "Repo exists: $($repo.full_name) | private: $($repo.private)"
} catch {
    Write-Host "Repo does not exist"
}
```

If exists:
> I found an existing GitHub repository with this name. Do you want to use it or create a new one with a different name?

If using existing: verify it's accessible for future pushes.

---

## STEP 6 — Create GitHub Repo (if needed)

```powershell
$body = @{
    name = $repoName
    private = $false  # public by default; set true if user requests private
    auto_init = $true  # initialize with README so Vercel can link
} | ConvertTo-Json

$repo = Invoke-RestMethod -Uri "https://api.github.com/user/repos" -Method POST -Headers $ghHeaders -Body $body -ContentType "application/json" -TimeoutSec 15
Write-Host "Created: $($repo.full_name) | URL: $($repo.html_url)"
```

Default: **public**. Ask if user wants private.
Do NOT push generated content here.

If fails:
> I could not create the GitHub repository. Please check your GitHub setup and permissions.

---

## STEP 7 — Verify Vercel Scope

```powershell
$vcToken = "[TOKEN FROM CREDENTIAL STORE]"
$vcHeaders = @{ "Authorization" = "Bearer $vcToken" }

$teams = Invoke-RestMethod -Uri "https://api.vercel.com/v2/teams" -Headers $vcHeaders -TimeoutSec 10
# Auto-select if only one team; ask if multiple
$teamId = $teams.teams[0].id
$teamSlug = $teams.teams[0].slug
Write-Host "Vercel scope: $($teams.teams[0].name) ($teamId)"
```

If multiple scopes found, list them and ask the user which to use.

---

## STEP 8 — Check if Vercel Project Already Exists

```powershell
$projects = Invoke-RestMethod -Uri "https://api.vercel.com/v9/projects?teamId=$teamId" -Headers $vcHeaders -TimeoutSec 10
$existing = $projects.projects | Where-Object { $_.name -eq $repoName }
if ($existing) { Write-Host "Vercel project exists: $($existing.id)" }
else { Write-Host "No existing Vercel project" }
```

If exists: ask to use it or create new with different name.

---

## STEP 9 — Create Vercel Project (if needed)

```powershell
$vcBody = @{
    name = $repoName
    framework = "nextjs"  # or null if unknown
} | ConvertTo-Json

$vcProject = Invoke-RestMethod -Uri "https://api.vercel.com/v10/projects?teamId=$teamId" -Method POST -Headers $vcHeaders -Body $vcBody -ContentType "application/json" -TimeoutSec 15
Write-Host "Vercel project created: $($vcProject.id)"
```

Do NOT deploy content here.

---

## STEP 10 — Link GitHub Repo to Vercel Project

```powershell
$linkBody = @{
    type = "github"
    repo = "$owner/$repoName"
} | ConvertTo-Json

$linked = Invoke-RestMethod -Uri "https://api.vercel.com/v10/projects/$($vcProject.id)/link?teamId=$teamId" -Method POST -Headers $vcHeaders -Body $linkBody -ContentType "application/json" -TimeoutSec 15
Write-Host "Linked: $($linked.link.type) - $($linked.link.repo)"
```

If linking fails:
> The GitHub repository and Vercel project both exist, but I could not link them together. This is usually a permissions, integration, or repository ownership issue.

Common causes:
- Missing Git provider connection in Vercel
- Wrong Vercel scope
- Incompatible private organization repository on Hobby
- Repository not accessible from the connected Vercel account

---

## STEP 11 — Save Project Metadata

Save to `projects/[project-name]/project-info.json`:

```json
{
  "projectName": "[project-name]",
  "cleanedName": "[project-name]",
  "github": {
    "owner": "[github-username-or-org]",
    "repo": "[project-name]",
    "fullName": "[github-username-or-org]/[project-name]",
    "visibility": "public",
    "isOrganization": false,
    "isNew": true
  },
  "vercel": {
    "projectId": "[vercel-project-id]",
    "projectName": "[project-name]",
    "scope": "[vercel-scope-name]",
    "teamId": "[vercel-team-id]",
    "isNew": true
  },
  "linkedAt": "[date]",
  "status": "ready"
}
```

**Never store tokens in this file.**

---

## STEP 12 — Final Success Message

> ✅ Project setup is complete.
>
> **GitHub:** `[owner/repo-name]` — ready
> **Vercel:** `[project-name]` — ready
> **Linked:** GitHub → Vercel ✓
> **Scope:** [Vercel scope name]
>
> Future build skills can now use this GitHub repository and Vercel project for deployments.

---

## FAILURE MESSAGES (quick reference)

| Failure | Message |
|---------|---------|
| GitHub auth fails | "I could not connect to GitHub. Please run /deploy again." |
| GitHub repo creation fails | "I could not create the GitHub repository. Please check your GitHub permissions and try again." |
| Repo exists but not accessible | "I found the repository, but I could not verify access for future updates." |
| Vercel auth fails | "I could not connect to Vercel. Please run /deploy again." |
| Vercel project creation fails | "I could not create the Vercel project. Please check your Vercel access and selected scope." |
| Linking fails | "The repo and project exist, but linking them failed. This may be caused by permissions, wrong scope, missing Git provider access in Vercel, or an unsupported private organization repository on Hobby." |
| Hobby + private org repo | "This setup is likely to fail on Vercel Hobby because private organization-owned Git repositories are not supported for this deployment path." |

---

## RULES

- ✅ Setup only — no content, no copy, no app files
- ✅ Never expose tokens
- ✅ Never store secrets in plain text
- ✅ Default to personal GitHub repos
- ✅ Default to public visibility
- ✅ Always check Hobby/private-org-repo conflict before linking
- ✅ Always ask before reusing an existing repo or project
- ✅ Stop and explain clearly if any step fails

---

## SUCCESS STATE

- [ ] Project name defined and cleaned
- [ ] GitHub auth verified
- [ ] Repository owner chosen (personal vs org)
- [ ] Hobby/private-org-repo risk checked
- [ ] GitHub repository exists and accessible
- [ ] Vercel auth verified
- [ ] Vercel project exists and accessible
- [ ] Repo linked to Vercel project
- [ ] Vercel scope confirmed
- [ ] Project metadata saved to `projects/[name]/project-info.json`
- [ ] User told setup is complete
