---
name: cloudinary
description: Manages file hosting on Cloudinary for the course video pipeline. Use this skill whenever OpenClaw needs to upload audio files, video files, slide images, or any assets to Cloudinary and get back a public URL. Also handles project folder setup, asset organization, listing assets by folder, and deleting old files. Triggers on phrases like "upload this audio", "upload this image", "host this file", "get the public URL", "set up the Cloudinary folders", "list assets for phase X", or any request to store or retrieve files for the video pipeline.
---

# Cloudinary Skill

Upload, organize, and retrieve course assets on Cloudinary. Returns public URLs ready for use in Shotstack JSON payloads.

## Required credentials (store in OpenClaw config)

- `CLOUDINARY_CLOUD_NAME` — your cloud name (e.g. `dxyz1234`)
- `CLOUDINARY_API_KEY` — your API key
- `CLOUDINARY_API_SECRET` — your API secret

## Base upload URL

```
https://api.cloudinary.com/v1_1/{CLOUD_NAME}/{resource_type}/upload
```

## Important: resource types

| File type | resource_type |
|---|---|
| MP3, WAV, audio | `video` (not raw — this enables transformations) |
| MP4, video | `video` |
| PNG, JPG, slide images | `image` |

## Project folder structure

All course assets live under this folder hierarchy:

```
ai-operator-blueprint/
  phase1/
    audio/     ← ElevenLabs MP3s
    slides/    ← Rendered slide PNG/JPG images
    video/     ← Shotstack rendered segment MP4s
  phase2/
    audio/
    slides/
    video/
  phase3/
    audio/
    slides/
    video/
  logo/        ← AI Operator logo and brand assets
```

Always use this structure. Never upload to the root.

## Authentication — generating a signature

Cloudinary signed uploads require a SHA1 signature. Generate it like this:

```bash
TIMESTAMP=$(date +%s)
FOLDER="ai-operator-blueprint/phase1/audio"
PUBLIC_ID="phase1-01-intro"

STRING_TO_SIGN="folder=${FOLDER}&public_id=${PUBLIC_ID}&timestamp=${TIMESTAMP}${CLOUDINARY_API_SECRET}"

SIGNATURE=$(echo -n "$STRING_TO_SIGN" | openssl sha1 | awk '{print $2}')
```

## Core operations

---

### 1. Upload an audio file (MP3)

Use `resource_type=video` for all audio files.

```bash
TIMESTAMP=$(date +%s)
FOLDER="ai-operator-blueprint/phase1/audio"
PUBLIC_ID="phase1-01-intro"
STRING_TO_SIGN="folder=${FOLDER}&public_id=${PUBLIC_ID}&timestamp=${TIMESTAMP}${CLOUDINARY_API_SECRET}"
SIGNATURE=$(echo -n "$STRING_TO_SIGN" | openssl sha1 | awk '{print $2}')

curl -X POST \
  "https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/video/upload" \
  -F "file=@/path/to/phase1-01-intro.mp3" \
  -F "public_id=${PUBLIC_ID}" \
  -F "folder=${FOLDER}" \
  -F "timestamp=${TIMESTAMP}" \
  -F "api_key=${CLOUDINARY_API_KEY}" \
  -F "signature=${SIGNATURE}"
```

**Response — extract the public URL:**
```json
{
  "secure_url": "https://res.cloudinary.com/CLOUD_NAME/video/upload/ai-operator-blueprint/phase1/audio/phase1-01-intro.mp3",
  "public_id": "ai-operator-blueprint/phase1/audio/phase1-01-intro",
  "duration": 19.2
}
```

Return `secure_url` to the user and pass it to the Shotstack JSON `soundtrack.src` field.

---

### 2. Upload a slide image (JPG/PNG)

Use `resource_type=image` for all slide images.

```bash
TIMESTAMP=$(date +%s)
FOLDER="ai-operator-blueprint/phase1/slides"
PUBLIC_ID="phase1-03-decision-lock-slide"
STRING_TO_SIGN="folder=${FOLDER}&public_id=${PUBLIC_ID}&timestamp=${TIMESTAMP}${CLOUDINARY_API_SECRET}"
SIGNATURE=$(echo -n "$STRING_TO_SIGN" | openssl sha1 | awk '{print $2}')

curl -X POST \
  "https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/image/upload" \
  -F "file=@/path/to/slide-03.jpg" \
  -F "public_id=${PUBLIC_ID}" \
  -F "folder=${FOLDER}" \
  -F "timestamp=${TIMESTAMP}" \
  -F "api_key=${CLOUDINARY_API_KEY}" \
  -F "signature=${SIGNATURE}"
```

**Response:**
```json
{
  "secure_url": "https://res.cloudinary.com/CLOUD_NAME/image/upload/ai-operator-blueprint/phase1/slides/phase1-03-decision-lock-slide.jpg",
  "public_id": "ai-operator-blueprint/phase1/slides/phase1-03-decision-lock-slide",
  "width": 1748,
  "height": 984
}
```

Return `secure_url` and pass it to `slide-renderer` for the Shotstack JSON `asset.src` field.

---

### 3. Upload a video file (MP4)

```bash
TIMESTAMP=$(date +%s)
FOLDER="ai-operator-blueprint/phase1/video"
PUBLIC_ID="phase1-01-intro"
STRING_TO_SIGN="folder=${FOLDER}&public_id=${PUBLIC_ID}&timestamp=${TIMESTAMP}${CLOUDINARY_API_SECRET}"
SIGNATURE=$(echo -n "$STRING_TO_SIGN" | openssl sha1 | awk '{print $2}')

curl -X POST \
  "https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/video/upload" \
  -F "file=@/path/to/phase1-01-intro.mp4" \
  -F "public_id=${PUBLIC_ID}" \
  -F "folder=${FOLDER}" \
  -F "timestamp=${TIMESTAMP}" \
  -F "api_key=${CLOUDINARY_API_KEY}" \
  -F "signature=${SIGNATURE}"
```

---

### 4. Upload from a URL (no local file needed)

When Shotstack returns an MP4 URL, upload it directly to Cloudinary without downloading first:

```bash
TIMESTAMP=$(date +%s)
FOLDER="ai-operator-blueprint/phase1/video"
PUBLIC_ID="phase1-01-intro"
STRING_TO_SIGN="folder=${FOLDER}&public_id=${PUBLIC_ID}&timestamp=${TIMESTAMP}${CLOUDINARY_API_SECRET}"
SIGNATURE=$(echo -n "$STRING_TO_SIGN" | openssl sha1 | awk '{print $2}')

curl -X POST \
  "https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/video/upload" \
  -F "file=SHOTSTACK_MP4_URL" \
  -F "public_id=${PUBLIC_ID}" \
  -F "folder=${FOLDER}" \
  -F "timestamp=${TIMESTAMP}" \
  -F "api_key=${CLOUDINARY_API_KEY}" \
  -F "signature=${SIGNATURE}"
```

This is the preferred method for saving Shotstack renders permanently — Shotstack URLs expire in 24 hours, Cloudinary URLs are permanent.

---

### 5. List assets in a folder

```bash
# List audio files
curl -X GET \
  "https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/resources/video?prefix=ai-operator-blueprint/phase1/audio&max_results=50" \
  -u "${CLOUDINARY_API_KEY}:${CLOUDINARY_API_SECRET}"

# List slide images
curl -X GET \
  "https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/resources/image?prefix=ai-operator-blueprint/phase1/slides&max_results=50" \
  -u "${CLOUDINARY_API_KEY}:${CLOUDINARY_API_SECRET}"
```

---

### 6. Delete an asset

```bash
TIMESTAMP=$(date +%s)
PUBLIC_ID="ai-operator-blueprint/phase1/audio/phase1-01-intro"
STRING_TO_SIGN="public_id=${PUBLIC_ID}&timestamp=${TIMESTAMP}${CLOUDINARY_API_SECRET}"
SIGNATURE=$(echo -n "$STRING_TO_SIGN" | openssl sha1 | awk '{print $2}')

curl -X POST \
  "https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/video/destroy" \
  -F "public_id=${PUBLIC_ID}" \
  -F "timestamp=${TIMESTAMP}" \
  -F "api_key=${CLOUDINARY_API_KEY}" \
  -F "signature=${SIGNATURE}"
```

---

## Public URL pattern

Once uploaded, assets follow this predictable URL pattern:

```
https://res.cloudinary.com/{CLOUD_NAME}/video/upload/{folder}/{public_id}.mp3
https://res.cloudinary.com/{CLOUD_NAME}/video/upload/{folder}/{public_id}.mp4
https://res.cloudinary.com/{CLOUD_NAME}/image/upload/{folder}/{public_id}.jpg
```

Examples:
```
https://res.cloudinary.com/dxyz1234/video/upload/ai-operator-blueprint/phase1/audio/phase1-01-intro.mp3
https://res.cloudinary.com/dxyz1234/image/upload/ai-operator-blueprint/phase1/slides/phase1-03-decision-lock-slide.jpg
```

You can construct these URLs without an API call if you know the cloud name, folder, and public ID.

---

## Pipeline integration

This skill slots into the pipeline at three points:

**Point 1 — After ElevenLabs, before slide-renderer:**
```
ElevenLabs generates MP3
→ cloudinary: upload MP3 → returns secure_url (audio)
→ slide-renderer injects audio URL into Shotstack JSON soundtrack.src
```

**Point 2 — After slide-renderer converts PPTX to PNGs:**
```
slide-renderer exports slide-XX.jpg files
→ cloudinary: upload each JPG → returns secure_url (image)
→ slide-renderer injects image URL into Shotstack JSON asset.src
```

**Point 3 — After Shotstack renders segment MP4:**
```
video-assembler gets Shotstack MP4 URL (expires 24h)
→ cloudinary: upload from URL → returns permanent secure_url
→ Store permanent URL in segment render log
→ video-stitcher uses permanent URLs for final stitch
```

---

## Error handling

| Error | Cause | Fix |
|---|---|---|
| 401 Unauthorized | Wrong API key or bad signature | Verify credentials, regenerate signature |
| 400 Bad Request | Wrong resource_type for file | Use `video` for MP3/MP4, `image` for PNG/JPG |
| File too large | Free tier limit | Compress or upgrade plan |
| Folder not found | Folder doesn't exist yet | Upload creates it automatically |

## What this skill does NOT do

- Does not generate audio — that is the elevenlabs-voice skill's job
- Does not render video — that is video-assembler's job
- Does not build slides — that is slide-renderer's job
- Does not transform or edit files — uploads only
