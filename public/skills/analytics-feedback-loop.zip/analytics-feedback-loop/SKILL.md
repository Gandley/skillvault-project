---
name: analytics-feedback-loop
description: >
  Pulls content performance data, identifies what is working and what is not, and feeds
  actionable recommendations back into Nova's content strategy. Activate immediately when
  the user types /analytics, /performance report, /what's working, /content performance,
  /review my stats, /how did my content do, or asks anything like "what performed best this
  week", "which posts got the most engagement", "what should I do more of", "what's not working",
  "give me a performance summary", "analyze my content results", or "what does the data say".
  Also activate at the end of any content week or campaign — Nova should proactively suggest
  running analytics after a full week of publishing. This skill queries PostStream for published
  post performance, pulls engagement metrics, identifies top and bottom performers, diagnoses
  patterns, and outputs a plain-language performance report with specific recommendations for
  the next content cycle. Requires at least 5 published posts to generate meaningful analysis —
  if fewer exist, tell the user and offer to run a lighter check instead.
---

# Analytics Feedback Loop

Pulls performance data from published content, identifies patterns, and outputs actionable
recommendations that make every content cycle smarter than the last.

## Primary command

`/analytics` — Full performance report across all platforms for the last 7 days.

## Supporting commands

- `/analytics 30` — 30-day performance report
- `/analytics instagram` — Instagram-only performance report
- `/analytics youtube` — YouTube-only performance report
- `/analytics linkedin` — LinkedIn-only performance report
- `/analytics top` — Quick view of top 5 performing posts only, no full report
- `/analytics bottom` — Quick view of bottom 5 performing posts — what to stop doing
- `/analytics compare` — Side-by-side platform comparison (which platform is delivering most)
- `/analytics pillar` — Performance breakdown by content pillar (Educate/Entertain/Convert/Engage)
- `/analytics format` — Performance breakdown by content format (Reel/Carousel/Text/Short/etc.)
- `/what should I post more of` — Shortcut that runs format + pillar analysis and outputs one recommendation

---

## Data sources

### Primary — PostStream API

PostStream is the primary data source. Query it for all published posts and their metrics.

**PostStream metrics available per post:**
- Platform
- Post type / format
- Published date and time
- Reach / impressions
- Likes
- Comments
- Shares / reposts
- Saves (Instagram)
- Click-through (if link in post)
- Status (published / failed / pending)

**PostStream API query — fetch published posts:**
```bash
curl -X GET "https://api.poststream.io/v1/posts?status=published&limit=50" \
  -H "x-api-key: $POSTSTREAM_API_KEY"
```

**PostStream API query — fetch post metrics:**
```bash
curl -X GET "https://api.poststream.io/v1/posts/{post_id}/metrics" \
  -H "x-api-key: $POSTSTREAM_API_KEY"
```

Filter by date range using `published_after` and `published_before` query params.

### Fallback — Manual input

If PostStream API returns no metric data (platform API limitations, new account, etc.):

```
⚠️ PostStream returned limited metric data for [platform].

For a full analysis I need engagement numbers. You can:
1. Paste your top 5 posts with their stats (likes, comments, saves/shares, reach)
2. Skip [platform] and analyze the platforms where data is available
3. Run /analytics [different platform] for a platform with data

Which would you prefer?
```

---

## Analytics workflow

---

### STAGE 1 — Data pull

Query PostStream for all published posts in the specified date range.
Default range: last 7 days. Adjust based on command used.

```
🔄 Pulling performance data...
Fetching published posts: [date range]
Platforms: [Instagram / YouTube / LinkedIn / All]
```

If API call succeeds, proceed to Stage 2.
If API call fails, surface the error clearly and offer the manual fallback.

📲 *Telegram push — send immediately on API failure:*
```
⚠️ Nova Analytics Error

PostStream data pull failed for [platform].
Manual input required to run the report.

Open Nova → /analytics to resolve
```

---

### STAGE 2 — Data validation

Before analysis, check data quality:

- Minimum posts required: 5 (across all platforms combined)
- If fewer than 5: "Not enough data for meaningful analysis. [X] posts found.
  Run more content first, or expand the date range with `/analytics 30`."
- Flag any posts with 0 metrics (may indicate failed posts or tracking issues)
- Flag posts published less than 24 hours ago — engagement is still accumulating,
  exclude from averages but note them

---

### STAGE 3 — Metric calculation

Calculate the following for each platform and overall:

**Engagement Rate (ER):**
```
ER = (Likes + Comments + Shares + Saves) / Reach × 100
```

Platform benchmarks for this niche (AI automation + entrepreneur):
- Instagram: Good ≥ 3% | Strong ≥ 6% | Exceptional ≥ 10%
- YouTube Shorts: Good ≥ 5% | Strong ≥ 10% | Exceptional ≥ 15%
- LinkedIn: Good ≥ 2% | Strong ≥ 4% | Exceptional ≥ 8%

**Top performers:** Top 3 posts by engagement rate per platform
**Bottom performers:** Bottom 3 posts by engagement rate per platform
**Format breakdown:** Average ER by content format (Reel, Carousel, Single, Text, Short)
**Pillar breakdown:** Average ER by content pillar (Educate, Entertain, Convert, Engage)
**Posting time breakdown:** Average ER by day of week and time of day
**Best posting day:** Day with highest average ER across the period

---

### STAGE 4 — Pattern diagnosis

After calculating metrics, identify patterns. This is the most important stage —
raw numbers without diagnosis are useless.

**Pattern checklist — run every one of these:**

1. **Format winner** — Which content format has the highest average ER?
2. **Format loser** — Which format is consistently underperforming?
3. **Pillar imbalance** — Is any pillar dramatically outperforming or underperforming?
4. **Timing signal** — Is there a consistent day or time when posts perform better?
5. **Platform gap** — Is one platform significantly outperforming the others?
6. **Hook failure pattern** — Are low performers clustered around a specific opening style?
7. **Save rate signal (Instagram)** — Are saves high but comments low? (Educational content
   doing well but not generating conversation — adjust Engage pillar)
8. **Comment rate signal (LinkedIn)** — Are posts getting impressions but no comments?
   (Reach is working, CTA or hook is failing)
9. **Cross-niche signal** — Did any post that bridged AI automation + entrepreneur
   outperform niche-specific posts?

Flag each pattern found with a confidence level:
- 🔴 STRONG SIGNAL — 3+ data points confirm this pattern
- 🟡 WEAK SIGNAL — 1–2 data points, worth watching but not actionable yet
- ⚪ NO SIGNAL — not enough data on this dimension

---

### STAGE 5 — Output the performance report

Compile everything into the structured report format. Present once — do not drip sections.

---

## Performance report output format

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 NOVA PERFORMANCE REPORT
[Date range] | [X] posts analyzed | [Platforms]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## OVERALL SNAPSHOT

Total posts published: [X]
Average engagement rate: [X]% (Benchmark for niche: [X]%)
Best platform this period: [Platform] ([X]% avg ER)
Best format this period: [Format] ([X]% avg ER)
Best posting day: [Day] ([X]% avg ER)

Status: [🟢 Above benchmark / 🟡 At benchmark / 🔴 Below benchmark]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## TOP PERFORMERS 🏆

### #1 — [Post title or description]
Platform: [Platform] | Format: [Format] | Pillar: [Pillar]
Published: [Date] at [Time]
Engagement rate: [X]% | Reach: [X] | Likes: [X] | Comments: [X] | Saves/Shares: [X]
Why it worked: [1–2 sentences — specific diagnosis based on the data]

### #2 — [Post]
[Same structure]

### #3 — [Post]
[Same structure]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## BOTTOM PERFORMERS ⚠️

### #1 — [Post title or description]
Platform: [Platform] | Format: [Format] | Pillar: [Pillar]
Published: [Date] at [Time]
Engagement rate: [X]% | Reach: [X] | Likes: [X] | Comments: [X]
Why it underperformed: [1–2 sentences — specific diagnosis]
Fix for next time: [One specific change to make]

### #2 — [Post]
[Same structure]

### #3 — [Post]
[Same structure]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## FORMAT BREAKDOWN

| Format | Posts | Avg ER | vs Benchmark | Signal |
|--------|-------|--------|--------------|--------|
| [Format 1] | [X] | [X]% | [+/-X%] | [🔴/🟡/⚪] |
| [Format 2] | [X] | [X]% | [+/-X%] | |
| [Format 3] | [X] | [X]% | [+/-X%] | |

Winner: [Format] — [One sentence on why and what to do about it]
Underperformer: [Format] — [One sentence on why and whether to cut or adjust]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## PILLAR BREAKDOWN

| Pillar | Posts | Avg ER | Target % | Actual % |
|--------|-------|--------|----------|----------|
| Educate | [X] | [X]% | 35% | [X]% |
| Entertain | [X] | [X]% | 25% | [X]% |
| Convert | [X] | [X]% | 20% | [X]% |
| Engage | [X] | [X]% | 20% | [X]% |

Pillar diagnosis: [Which pillar is over/under-represented and what that means]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## PLATFORM COMPARISON

| Platform | Posts | Avg ER | Best Format | Best Day |
|----------|-------|--------|-------------|----------|
| Instagram | [X] | [X]% | [Format] | [Day] |
| YouTube | [X] | [X]% | [Format] | [Day] |
| LinkedIn | [X] | [X]% | [Format] | [Day] |

Platform diagnosis: [Which platform is delivering and which needs attention]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## PATTERNS DETECTED

[List only patterns with 🔴 STRONG SIGNAL or 🟡 WEAK SIGNAL — skip ⚪]

🔴 [Pattern name]: [What the data shows + why it matters]
🟡 [Pattern name]: [What the data suggests + what to watch]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## RECOMMENDATIONS FOR NEXT CYCLE

Based on this data, here is exactly what Nova should do differently next week:

DO MORE:
→ [Specific action — e.g. "Post LinkedIn carousels on Tuesday mornings — 2x ER of other formats"]
→ [Specific action]
→ [Specific action — maximum 3]

DO LESS:
→ [Specific action — e.g. "Cut single image posts on Instagram — consistently below 2% ER"]
→ [Specific action — maximum 2]

TEST NEXT WEEK:
→ [One specific experiment — e.g. "Try a Reel with a pattern interrupt hook on Wednesday to test
   against the controversy hooks that performed well this week"]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Next step: Run /trends to check what's performing on the algorithm right now,
then run /content calendar to build next week's plan around these findings.
```

📲 *Telegram push — send when full report is complete:*
```
📊 Nova Weekly Performance Report

[Date range] | [X] posts analyzed
Avg engagement rate: [X]% ([above/at/below] benchmark)
Top platform: [platform] | Top format: [format]
🔴 Strong signals: [count]

Open Nova to review → /analytics
```

---

## Quick commands — output formats

### `/analytics top`

Pull top 5 posts only. No full report.

```
🏆 TOP 5 POSTS — Last [X] Days

1. [Post description] — [Platform] — [ER]% — [Format]
2. [Post] — [Platform] — [ER]% — [Format]
3. [Post] — [Platform] — [ER]% — [Format]
4. [Post] — [Platform] — [ER]% — [Format]
5. [Post] — [Platform] — [ER]% — [Format]

Common thread: [One sentence on what these top posts share]
```

### `/analytics bottom`

Pull bottom 5 posts only. No full report.

```
⚠️ BOTTOM 5 POSTS — Last [X] Days

1. [Post description] — [Platform] — [ER]% — [Format]
   Issue: [One-line diagnosis]
2–5. [Same structure]

Common thread: [One sentence on what these underperformers share]
Fix: [One specific change to avoid repeating this pattern]
```

### `/analytics compare`

Side-by-side platform comparison only.

```
📊 PLATFORM COMPARISON — Last [X] Days

Instagram: [X]% avg ER | [X] posts | Best format: [Format]
YouTube:   [X]% avg ER | [X] posts | Best format: [Format]
LinkedIn:  [X]% avg ER | [X] posts | Best format: [Format]

Winner: [Platform] — [One sentence on why and what to double down on]
Needs work: [Platform] — [One sentence on what to adjust]
```

### `/analytics pillar`

Pillar breakdown only. No full report.

```
📊 PILLAR PERFORMANCE — Last [X] Days

Educate:  [X]% avg ER | [X] posts | [Status vs target]
Entertain:[X]% avg ER | [X] posts | [Status vs target]
Convert:  [X]% avg ER | [X] posts | [Status vs target]
Engage:   [X]% avg ER | [X] posts | [Status vs target]

What this means: [Two sentences on the imbalance and what to fix]
```

### `/what should I post more of`

Run format + pillar analysis silently, then output one direct recommendation.

```
Based on your last [X] posts:

Post more [FORMAT] on [PLATFORM].

Why: [One sentence — specific data point]
Less of: [FORMAT] — [One sentence on why it's underperforming]
```

---

## Feedback loop integration

After every analytics report, Nova must explicitly connect findings back to the other skills:

**→ Trend Intelligence:** "Run /trends to cross-reference what the algorithm is rewarding
with what your data shows is working. Alignment between the two = highest-confidence content plays."

**→ Content Calendar:** "Take the DO MORE and DO LESS recommendations directly into
/content calendar when building next week's plan."

**→ Repurposing Engine:** "Your top performer this week is a prime candidate for repurposing.
Run /repurpose on [top post] to extract a full week of derivative content."

**→ Content Strategy Agent (when built):** Analytics reports should be surfaced to the
Strategy Agent quarterly so positioning and pillar strategy can be updated based on
what the data shows the audience actually responds to — not just what was planned.

---

## Analytics rules Nova must follow

**No vanity metrics** — Likes alone mean nothing. Engagement rate relative to reach is
the signal. A post with 500 likes and 50,000 reach (1% ER) underperforms a post with
50 likes and 300 reach (16.7% ER). Always calculate ER before drawing conclusions.

**No single-post conclusions** — One viral post doesn't prove a strategy. One flop doesn't
kill a format. Patterns require 3+ data points. Always flag signal strength honestly.

**Diagnosis over description** — "Your carousel got 6% ER" is description. "Your carousel
outperformed your average by 3x — the hook was a direct question which drove saves and
shares — do this again" is diagnosis. Nova always diagnoses, never just describes.

**Recommendations must be specific** — "Post better content" is not a recommendation.
"Switch Tuesday Instagram posts from single images to carousels — carousels averaged 5.2%
ER vs 1.8% for singles this period" is a recommendation.

## What this skill does NOT do

- Does not run ads or manage paid performance — organic content only
- Does not pull data from platform native apps directly — uses PostStream as the data layer
- Does not make permanent strategy decisions — surfaces data for the human to act on
- Does not replace the Content Strategy Agent — feeds data up to it when it exists
- Does not track email list or landing page conversion rates — funnel analytics are out of scope

---

## Telegram notifications

Nova uses Telegram to push time-sensitive updates, approval requests, and pipeline completions
directly to your phone. Connect your Telegram bot token and chat ID via `/nova setup telegram`
before notifications will fire.

**Credentials required:**
- `TELEGRAM_BOT_TOKEN` — from @BotFather on Telegram
- `TELEGRAM_CHAT_ID` — your personal chat ID (send /start to your bot, then fetch from API)

**Send a Telegram message:**
```bash
curl -s -X POST "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage" \
  -H "Content-Type: application/json" \
  -d '{
    "chat_id": "'${TELEGRAM_CHAT_ID}'",
    "text": "YOUR MESSAGE HERE",
    "parse_mode": "Markdown"
  }'
```

If Telegram credentials are not configured, skip silently — do not fail the skill or
ask for credentials mid-pipeline. Surface the missing config note at the end of the output only.
