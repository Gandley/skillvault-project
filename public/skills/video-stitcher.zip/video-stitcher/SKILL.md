---
name: video-stitcher
description: Combines all rendered segment MP4 URLs for a phase into one final video using the Shotstack render API. Use this skill whenever the user wants to stitch segment videos together, combine phase segments into a final MP4, or merge multiple Shotstack output URLs into one complete phase video. Triggers on phrases like "stitch the videos", "combine the segments", "merge phase X videos", "build the final phase video", or any request to combine segment MP4 URLs into one complete video.
---

# Video Stitcher

Combine all rendered segment MP4 URLs for a phase into one final video via Shotstack.

## Input required

A completed segment render log from video-assembler:

| Segment ID | MP4 URL |
|---|---|
| phase1-01-intro | https://cdn.shotstack.io/.../phase1-01-intro.mp4 |
| phase1-02-decision-lock | https://cdn.shotstack.io/.../phase1-02-decision-lock.mp4 |
| phase1-03-brain-dump | https://cdn.shotstack.io/.../phase1-03-brain-dump.mp4 |
| ... | ... |
| phase1-08-outro | https://cdn.shotstack.io/.../phase1-08-outro.mp4 |

**All segments must have status `done` before stitching.** Do not stitch incomplete sets.

## How Shotstack stitches videos

Use the Shotstack Edit API with video assets in sequence. Each segment becomes a clip on the timeline, starting where the previous one ended.

## Step 1 — Calculate cumulative start times

Before building the JSON, get the duration of each segment:

```bash
curl -X GET https://api.shotstack.io/v1/render/RENDER_ID \
  -H "x-api-key: $SHOTSTACK_API_KEY"
```

The response includes `data.timeline` with duration info. Or use the known ElevenLabs audio durations from the segment map as the source of truth.

Build a start time table:

| Segment | Duration | Start Time |
|---|---|---|
| phase1-01-intro | 25s | 0 |
| phase1-02-decision-lock | 60s | 25 |
| phase1-03-brain-dump | 45s | 85 |
| ... | ... | ... |

## Step 2 — Build the stitch payload

```json
{
  "timeline": {
    "background": "#0a0f1e",
    "tracks": [
      {
        "clips": [
          {
            "asset": {
              "type": "video",
              "src": "SEGMENT_1_URL"
            },
            "start": 0,
            "length": SEGMENT_1_DURATION,
            "transition": { "out": "fadeOut" }
          },
          {
            "asset": {
              "type": "video",
              "src": "SEGMENT_2_URL"
            },
            "start": SEGMENT_2_START,
            "length": SEGMENT_2_DURATION,
            "transition": { "in": "fadeIn", "out": "fadeOut" }
          }
        ]
      }
    ]
  },
  "output": {
    "format": "mp4",
    "resolution": "hd",
    "size": { "width": 1920, "height": 1080 }
  }
}
```

Rules:
- First clip: `"transition": { "out": "fadeOut" }` only
- Middle clips: `"transition": { "in": "fadeIn", "out": "fadeOut" }`
- Last clip: `"transition": { "in": "fadeIn" }` only
- All clips on the same track
- `length` = exact segment duration in seconds
- `start` = cumulative sum of all previous segment durations

## Step 3 — Submit stitch render

```bash
curl -X POST https://api.shotstack.io/v1/render \
  -H "Content-Type: application/json" \
  -H "x-api-key: $SHOTSTACK_API_KEY" \
  -d '{STITCH_PAYLOAD}'
```

## Step 4 — Poll for completion

Same polling pattern as video-assembler. Stitch renders take longer — allow up to 3-5 minutes for a full phase video.

```bash
curl -X GET https://api.shotstack.io/v1/render/RENDER_ID \
  -H "x-api-key: $SHOTSTACK_API_KEY"
```

## Step 5 — Deliver final URL

When done, return the final phase MP4 URL to the user.

Final naming convention:
- Phase 1 complete: `phase1-final.mp4`
- Phase 2 complete: `phase2-final.mp4`
- Phase 3 complete: `phase3-final.mp4`

**Reminder:** Download or transfer this URL within 24 hours. Shotstack CDN URLs are temporary.

## Output summary format

Return this to the user when complete:

```
✅ Phase 1 Final Video Complete

Render ID: [id]
Duration: [total seconds]s
URL: [shotstack CDN URL]
Expires: 24 hours from now — download immediately

Segments included:
- phase1-01-intro (25s)
- phase1-02-decision-lock (60s)
- phase1-03-brain-dump (45s)
- ... 
- phase1-08-outro (20s)
```

## What this skill does NOT do

- Does not render individual segments — that is video-assembler's job
- Does not permanently host the final video — user must download or transfer
- Does not upload to Discord or any platform — that is a separate step
- Does not re-render segments if they look wrong — fix in slide-script-architect first
