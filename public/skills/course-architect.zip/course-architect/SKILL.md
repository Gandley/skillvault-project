---
name: course-architect
description: Designs a complete course structure from a niche or topic. Produces a COURSE-OVERVIEW.md file in the exact format required by the course-video-pipeline. Use this skill before running any video production. Triggers on phrases like "build me a course on X", "design a course about X", "create a course outline", "I want to make a course", or any request to go from a topic idea to a structured course ready for video production.
---

# Course Architect

Turn a niche or topic into a complete, structured course — with business recommendations you approve before anything is locked in.

## What this skill produces

1. Business recommendation block (pricing, format, platform) — **requires your approval**
2. `COURSE-OVERVIEW.md` — the course structure file that feeds the entire video pipeline

Do not proceed to video production until `COURSE-OVERVIEW.md` is approved and saved.

---

## Input required

The user provides one or more of:
- **Topic or niche** (required) — e.g. "AI automation for freelancers", "sourdough baking", "Notion for productivity"
- **Target audience** (optional) — e.g. "beginners", "small business owners", "developers"
- **Desired outcome** (optional) — e.g. "make money", "learn a skill", "save time"
- **Constraints** (optional) — e.g. "keep it under 3 hours", "3 phases max", "no tech skills required"

If topic is the only input provided, proceed — infer the rest from the topic and flag assumptions in the recommendation block.

---

## Stage 1 — Research & recommendation

Before designing anything, assess the topic on four dimensions and produce a recommendation block.

### Assessment dimensions

**1. Audience clarity** — Is there a specific, reachable person who would buy this?
- Strong: "freelance copywriters who want to use AI to 10x output"
- Weak: "people interested in AI"

**2. Outcome specificity** — Does the course produce a clear, measurable result?
- Strong: "land your first $1k client in 30 days"
- Weak: "learn about marketing"

**3. Market viability** — Is there demonstrated demand? Is it too crowded or too niche?

**4. Deliverability** — Can this realistically be taught in a structured video course without requiring live coaching, community, or one-on-one elements?

---

### Recommendation block format

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
COURSE ARCHITECT — RECOMMENDATION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

TOPIC: [as provided or inferred]
TARGET AUDIENCE: [specific person description]
CORE OUTCOME: [one sentence — what the student walks away able to do]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ASSESSMENT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Audience Clarity:    [Strong / Needs refinement] — [1 sentence reason]
Outcome Specificity: [Strong / Needs refinement] — [1 sentence reason]
Market Viability:    [Strong / Borderline / Weak] — [1 sentence reason]
Deliverability:      [Strong / Borderline / Weak] — [1 sentence reason]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
BUSINESS RECOMMENDATIONS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

FORMAT
  Recommended: [Video course / Mini-course / Workshop / Hybrid]
  Reasoning: [1–2 sentences]

PRICE POINT
  Recommended: $[X] – $[Y]
  Reasoning: [1–2 sentences — based on outcome, audience, and comparable offers]
  Positioning: [Budget / Mid-tier / Premium]

PLATFORM
  Recommended: [e.g. Gumroad, Teachable, Kajabi, Podia, self-hosted]
  Reasoning: [1–2 sentences — based on tech comfort level, audience, and margin]
  Alternative: [second option if recommended has tradeoffs]

COURSE LENGTH
  Recommended: [X phases / Y modules / Z total hours]
  Reasoning: [1–2 sentences]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ASSUMPTIONS MADE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[List any assumptions made where user didn't provide input]
[e.g. "Assumed beginner audience since no level was specified"]
[If no assumptions, write: None — all inputs provided]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⛔ APPROVAL REQUIRED
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Do you approve these recommendations?
→ YES to proceed to course structure
→ NO + [what to change] to revise any dimension
```

**Do not build the course structure until the user explicitly approves or provides changes.**

If the user says NO, apply their changes and re-present the recommendation block. Repeat until approved.

---

## Stage 2 — Course structure

Once recommendations are approved, build the full course structure.

### Structure rules

- **Phases:** 2–4 phases. Each phase = a major milestone in the student's journey.
- **Modules per phase:** 3–6 modules. Each module = one focused lesson or step.
- **Days:** Assign each module a day number. Total course length matches the approved recommendation.
- **Time estimates:** Every module gets a realistic completion time (15–90 min).
- **No filler:** Every module must produce something tangible — an output, a decision, a completed task. No "intro to X" modules that don't deliver action.

### Naming conventions (required — pipeline depends on these)

- Phase IDs: `phase1`, `phase2`, `phase3`, `phase4`
- Module IDs: `module1.1`, `module1.2`, `module2.1`, etc.
- Day labels: `Day 1`, `Day 2`, etc. — continuous across phases

---

### COURSE-OVERVIEW.md format

Produce this exact format. The pipeline parses it by section headers — do not change the header names.

```markdown
# [COURSE TITLE]

## Course Overview
**Target audience:** [specific person]
**Core promise:** [one sentence outcome]
**Format:** [video course / mini-course / etc.]
**Price:** $[X]
**Platform:** [platform name]
**Total length:** [X phases, Y modules, ~Z hours]

---

## Phase 1 — [Phase Title]
**Days:** [X–Y]
**Milestone:** [What the student achieves by end of this phase]

### Module 1.1 — [Module Title]
**Day:** [X]
**Time:** [X min]
**Objective:** [What the student does or produces]
**Steps:**
1. [Step name] — [time] — [output]
2. [Step name] — [time] — [output]
3. [Step name] — [time] — [output]

### Module 1.2 — [Module Title]
[same structure]

---

## Phase 2 — [Phase Title]
**Days:** [X–Y]
**Milestone:** [What the student achieves by end of this phase]

### Module 2.1 — [Module Title]
[same structure]

[Continue for all phases and modules]

---

## Appendix — Assumed Brand / Voice
**Tone:** [e.g. direct, practical, no fluff]
**Narration style:** [e.g. second-person, present tense, action-oriented]
**Slide style:** [leave as: AI Operator brand — handled by slide-renderer]
```

---

## Stage 3 — Delivery

After producing `COURSE-OVERVIEW.md`, present it to the user in full and confirm:

```
✅ COURSE-OVERVIEW.md ready

[Full file contents displayed here]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Next step: Run course-video-pipeline to begin video production.

Command: /coursevideopipeline Phase 1
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

Save `COURSE-OVERVIEW.md` to the working directory before handing off to the pipeline.

---

## Quality checks

- Every module has a concrete output — not just "learn about X"
- Total module count matches the approved course length recommendation
- Day numbers are continuous across phases (no resets)
- Phase milestones are outcome-based, not topic-based
- No module is named "Introduction to X" without delivering a tangible action
- Tone and narration style in Appendix matches the target audience

---

## What this skill does NOT do

- Does not generate narration scripts — that is slide-script-architect's job
- Does not build slides or video — that is the video pipeline's job
- Does not choose a voice — that is the user's decision, configured in slide-script-architect
- Does not upload anything — course-video-pipeline handles all uploads
