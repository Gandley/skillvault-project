---
name: repurposing-engine
description: >
  Transforms one piece of long-form content into a full week of platform-native derivative content.
  Activate immediately when the user types /repurpose, /repurpose this, /turn this into posts,
  /get more out of this content, /extract content from this, or pastes a blog post, video transcript,
  newsletter, or any long-form content and asks what to do with it. Also activate when someone says
  "I just published [X] — what else can I make from it", "make this into social posts", "turn this
  into a carousel", "clip this into hooks", "I wrote this — now help me get it everywhere", or any
  variation of wanting to multiply content output from a single source. This skill extracts the top
  insights and angles from any long-form input and generates platform-native content for Instagram,
  YouTube, and LinkedIn — respecting each platform's format rules, tone norms, and character limits.
  Always ask which platforms to target if not specified. Never repurpose to all platforms by default
  unless the user explicitly says so — selective targeting produces better content than spray-and-pray.
---

# Content Repurposing Engine

Takes one piece of long-form content and extracts maximum distribution value from it.
One input → a full week of platform-native posts across Instagram, YouTube, and LinkedIn.

## Primary command

`/repurpose` — Guided repurposing wizard. User pastes content, Nova extracts and builds.

## Supporting commands

- `/repurpose instagram` — Repurpose to Instagram formats only
- `/repurpose linkedin` — Repurpose to LinkedIn formats only
- `/repurpose youtube` — Repurpose YouTube Shorts hooks and titles only
- `/repurpose carousel` — Extract carousel slides from long-form content
- `/repurpose hooks [n]` — Extract N short-form video hooks from the content
- `/repurpose email` — Extract one email subject line and preview text
- `/extract insights` — Pull the top insights from long-form content without building posts

---

## Input types Nova can repurpose

Nova handles any of the following as input. User can paste directly into the chat.

| Input Type | What Nova extracts |
|---|---|
| Blog post | Key insights, frameworks, contrarian angles, quotes, data points |
| Video transcript | Hooks, punchy moments, quotable lines, teachable segments |
| Newsletter | Core argument, supporting points, calls-to-action, data/stats |
| Podcast transcript | Stories, analogies, opinion takes, how-to segments |
| Twitter/X thread | Expanded angles, carousel slides, LinkedIn adaptations |
| Long LinkedIn post | Instagram caption adaptation, carousel, YouTube hook |
| Sales page | Pain point content, benefit posts, social proof angles |
| Case study | Results posts, before/after content, process breakdowns |

If the input type is unclear, Nova identifies it before extracting.

---

## Core repurposing principle

**One idea. Many containers.**

The content is not rewritten — it is extracted and reformatted. The insight stays the same.
The container changes to match the platform, format, and audience behavior on that platform.

A blog post insight that works as a 900-word section becomes:
- A 3-second Instagram Reel hook
- A 9-slide carousel
- A 150-word LinkedIn text post
- A YouTube Short script
- An email subject line

Nova never copy-pastes from the source. Every output is adapted for its format.
Lazy repurposing (copy the paragraph, add a hashtag, post it) is not acceptable.

---

## Repurposing workflow

---

### STAGE 1 — Content intake

When `/repurpose` is triggered, prompt:

```
📥 REPURPOSING ENGINE

Paste your content below — blog post, transcript, newsletter, whatever you've got.
Once I read it I'll tell you what I can extract and ask which platforms to target.
```

After the user pastes content, proceed to Stage 2 immediately. Do not ask clarifying
questions before reading the content.

---

### STAGE 2 — Content analysis

Read the full input and identify:

1. **Content type** — blog post, transcript, newsletter, etc.
2. **Core argument or main insight** — the one idea the whole piece is built around
3. **Top 5 extractable insights** — the most standalone, punchy, or teachable moments
4. **Quotable lines** — sentences that are sharp enough to stand alone as a post
5. **Data points or stats** — any numbers, percentages, or results mentioned
6. **Stories or analogies** — any narrative moments that could anchor a post
7. **Contrarian angles** — any places where the content pushes back on conventional wisdom

Output a brief content audit before asking about platforms:

```
📋 CONTENT AUDIT

Type: [Blog post / Transcript / Newsletter / etc.]
Core argument: [One sentence]

What I can extract:
✅ [X] standalone insights
✅ [X] quotable lines
✅ [X] data points
✅ [X] story moments
✅ [X] contrarian angles

Estimated output: [X] posts across platforms

Which platforms are we targeting?
→ Instagram | YouTube | LinkedIn | All three | Pick a combination
```

Wait for platform selection before building.

---

### STAGE 3 — Platform selection and output plan

After platform selection, confirm the output plan before building:

```
📤 REPURPOSING PLAN

From this [content type] I'll build:

INSTAGRAM
→ [X] Reel hooks (with scripts)
→ [X] Carousel (slides)
→ [X] Single image caption

YOUTUBE
→ [X] Shorts scripts/hooks
→ [X] Long-form title + thumbnail concept (if content supports it)

LINKEDIN
→ [X] Text post
→ [X] Carousel (PDF)

Total: [X] pieces of content from one source

Build all of these? Or select specific formats?
```

Wait for confirmation. If user selects specific formats, build only those.

---

### STAGE 4 — Build all outputs

Build each format in sequence. Present all outputs in one block at the end —
do not drip outputs one at a time mid-build.

---

## Platform-specific build rules

---

### INSTAGRAM — Reel Hooks

Extract 3–5 standalone hooks from the content. Each hook is the opening line
of a short-form video. The hook is the entire deliverable — Nova does not script
the full Reel unless asked.

**Hook formula options:**

| Type | Structure | Example |
|---|---|---|
| Controversy | "[Common belief] is wrong. Here's what actually works." | "Hiring is the old way. Here's what actually scales." |
| Curiosity gap | "Most [audience] don't know [surprising thing]. I'll show you." | "Most business owners don't know their AI agent is costing them money." |
| Result first | "I [achieved result] in [timeframe]. Here's the exact system." | "I automated 80% of my business in 30 days. Here's the exact system." |
| Direct value | "Here are [number] [things] that [outcome]. Save this." | "Here are 5 AI agents that run your business while you sleep. Save this." |
| Pattern interrupt | "[Unexpected statement that stops the scroll]" | "You don't need more content. You need one system." |

**Output format per hook:**
```
## REEL HOOK [#]
Hook type: [Controversy / Curiosity gap / Result first / Direct value / Pattern interrupt]
Opening line: [The hook — exactly as it would be spoken in the first 2–3 seconds]
Source insight: [Which insight from the original content this comes from]
Suggested visual: [One line on what should be on screen during this hook]
```

---

### INSTAGRAM — Carousel

Extract the most educational insight from the content and build a carousel.

**Carousel structure rules:**
- Slide 1: Hook slide — bold statement or question. No more than 8 words.
- Slides 2–8: One insight per slide. Headline + 1–2 supporting sentences. No walls of text.
- Last slide: CTA slide — one action. "Save this", "Follow for more", or "DM me [word]".
- Total slides: 7–10. Never fewer than 5, never more than 12.
- Each slide must make sense standalone — reader should get value from any single slide.

**Output format:**
```
## CAROUSEL — [Title]

SLIDE 1 (Hook): [Text — under 8 words]

SLIDE 2: [Headline]
[1–2 sentences of body copy]

SLIDE 3: [Headline]
[Body copy]

[Continue through all slides]

LAST SLIDE (CTA): [Action]
Caption (for post): [2–3 line caption with hook + context + CTA]
Hashtags: [3–5 relevant hashtags]
```

---

### INSTAGRAM — Single image caption

Extract one quotable line or punchy insight and build a caption around it.

**Caption structure:**
- Line 1: Hook — the most interesting sentence. Standalone. Makes them stop.
- Lines 2–4: Context — brief expansion. Why this matters.
- Line 5: Micro-CTA — save, comment, follow, or click.
- Hashtags: 3–5 maximum.

**Output format:**
```
## SINGLE POST CAPTION

Line 1 (Hook): [Hook line]

[Body — 3–5 lines, no more]

[CTA line]

Hashtags: [3–5]
Suggested visual direction: [One line on what the image should show]
```

---

### YOUTUBE — Shorts Script

Extract 2–3 moments from the content that can become a YouTube Short under 60 seconds.
A Short needs: hook (0–3s), payoff (3–45s), CTA (45–60s).

**Output format:**
```
## YOUTUBE SHORT [#]

Title: [Title — curiosity gap or clear value — under 60 characters]
Source insight: [Which part of the original content]

SCRIPT:
[0–3s HOOK]: [Opening line — exactly as spoken]
[3–45s PAYOFF]: [The main content — punchy, no filler, direct instruction or story]
[45–60s CTA]: [One clear action — "Subscribe for more", "Comment below", "Link in bio"]

Thumbnail concept: [One line — what should be on the thumbnail]
```

---

### YOUTUBE — Long-form title and thumbnail concept

If the source content is substantial enough to support a full YouTube video
(1,000+ words or 10+ minutes of transcript), extract a title and thumbnail concept.
Nova does not script the full video — she identifies the angle and packaging.

**Output format:**
```
## YOUTUBE LONG-FORM CONCEPT

Title option 1: [Title — curiosity gap]
Title option 2: [Title — result-forward]
Title option 3: [Title — how-to]

Thumbnail concept: [What should be on the thumbnail — face + text + emotion guidance]
Hook (first 30 seconds): [What the video should open with to maximize retention]
Chapter structure: [3–5 suggested chapter titles based on the source content]
```

---

### LINKEDIN — Text post

LinkedIn text posts perform best when they lead with a personal angle or opinion,
use aggressive line breaks, and invite a specific response.

**Text post structure:**
- Line 1: Hook — bold, opinion-first, or story-opening. One line. No period.
- Lines 2–8: Body — one idea per line. Short sentences. White space is intentional.
- Last 2 lines: Takeaway + question or CTA.
- Total length: 150–300 words for standard posts. Up to 700 for long-form opinion posts.

**Output format:**
```
## LINKEDIN TEXT POST

[Full post text — formatted with line breaks exactly as it should appear]

Post type: [Opinion / How-to / Story / Stat-driven / Contrarian]
Best posting time: [Day + time based on LinkedIn algorithm profile]
Engagement hook: [The question or CTA at the end that will drive comments]
```

---

### LINKEDIN — Carousel (PDF)

LinkedIn carousels are uploaded as PDF documents. They perform similarly to Instagram
carousels but the tone is more professional and the content tends to be more framework-driven.

**LinkedIn carousel differences from Instagram:**
- More text per slide is acceptable (2–4 sentences vs 1–2)
- Frameworks, matrices, and step-by-step systems outperform pure inspiration
- Professional language — not corporate, but not as casual as Instagram
- No "save this" CTA — use "Share this with your network" or "Follow for more frameworks"

**Output format:** Same as Instagram carousel with a note flagging LinkedIn-specific adjustments.

---

### EMAIL — Subject line and preview text

Extract the sharpest insight or most compelling hook for an email promotion of the content.

**Output format:**
```
## EMAIL SUBJECT LINE OPTIONS

Option 1: [Subject — curiosity-driven]
Option 2: [Subject — result-driven]
Option 3: [Subject — contrarian]

Preview text: [The one line that appears after the subject in the inbox — 40–90 characters]
```

---

## STAGE 5 — Repurposing summary

After all outputs are built, close with a summary:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ REPURPOSING COMPLETE

Source: [Content type + one-line description]
Total pieces created: [X]

BREAKDOWN:
Instagram: [X Reel hooks] [X Carousel] [X Single post]
YouTube: [X Shorts] [X Long-form concept]
LinkedIn: [X Text post] [X Carousel]

RECOMMENDED POSTING ORDER:
1. [First post to publish] — [Platform] — [Why lead with this]
2. [Second] — [Platform]
3. [Third] — [Platform]
[Continue in order]

Estimated scheduling window: [X days to drip all content]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Next step: Run /social post pipeline to schedule and publish these posts,
or run /content calendar to slot them into the week's plan.
```

📲 *Telegram push — send when repurposing is complete:*
```
♻️ Nova Repurposing Complete

Source: [content type]
[X] pieces created across [platforms]

Ready to schedule → /social post pipeline
```

---

## Quick commands

### `/repurpose hooks [n]`
User wants only hooks, no other formats. Extract N hooks (default 5 if not specified).
Run Stage 1 and Stage 2, then skip directly to Reel Hook output only.

### `/extract insights`
User wants to see what's in the content before deciding what to build.
Run Stage 1 and Stage 2 only. Output the content audit with all extractable elements listed.
Do not build any posts. Ask what they want to do with the insights.

---

## Quality enforcement rules

**No lazy repurposing** — Copy-pasting a paragraph from the source with a hashtag added
is not repurposing. Every output must be rewritten for its format. If it reads like a
lifted excerpt, rewrite it.

**Platform-native tone** — Instagram is conversational and visual. YouTube is punchy and
retention-focused. LinkedIn is professional but human. A post written for one platform
pasted onto another without adaptation will underperform. Always adapt.

**One insight per post** — Do not cram multiple insights into a single post. One post,
one clear idea. Density kills engagement on social. Save depth for carousels and guides.

**Hook first, always** — Every single output — regardless of format or platform — must
open with a hook. The first line is the only line that matters if the hook fails.
No post should open with "In today's post..." or "I wanted to share..." or any warm-up language.

## What this skill does NOT do

- Does not publish content — hand off to Social Post Pipeline and PostStream
- Does not schedule content — hand off to Content Calendar
- Does not source or clip video — hand off to Video Cue
- Does not create the original long-form content — Nova repurposes what already exists
- Does not export to PDF or design the carousel visually — outputs are copy only
