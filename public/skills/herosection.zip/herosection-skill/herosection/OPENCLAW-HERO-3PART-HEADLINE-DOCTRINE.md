# OPENCLAW HERO: 3-PART HEADLINE DOCTRINE

**Purpose:** Generate a 3-part headline structure for the hero section of any page. Each part serves a different psychological function. Do not repeat ideas. Do not rephrase the same claim. Each line must escalate.

---

## THE THREE-PART STRUCTURE

Each hero section gets exactly three headline lines. They answer three different questions in sequence.

**Line 1 — Pattern Interrupt:** "Why should I care?"
**Line 2 — Mechanism Reveal:** "What is this?"
**Line 3 — Outcome + Identity Shift:** "What does this do for me?"

If two lines answer the same question — rewrite one.

---

## PART 1 — PATTERN INTERRUPT (SHORT + SHARP)

**Goal:** Stop the scroll. Create tension or signal advantage before explaining anything.

**Requirements:**
- 3–7 words
- Bold
- Punchy
- Emotion-triggering — challenge a belief, name a fear, imply an advantage

**Should:**
- Challenge something the reader assumed was true
- Create a moment of tension or recognition
- Signal that something has changed — or that they're missing something

**Should NOT:**
- Explain anything
- Name the product
- Make a promise (that comes in Line 3)

**Example structures:**
- "[Challenge a belief they hold]"
- "[Name a fear or problem at its sharpest]"
- "[Make a bold statement of fact that reframes their world]"

**Rule:** No fluff. No explanation. Just impact.

---

## PART 2 — MECHANISM REVEAL (CLARITY)

**Goal:** Answer the "what is this?" question. Make it specific and concrete.

**This line introduces:**
- The product or system
- The method or approach
- The specific mechanism that makes it work
- A concrete proof point or result

**Requirements:**
- One clear, complete sentence
- Names what it is and how it works (or what it produced)
- Specific enough that a skeptic would pause

**Example structure:**
- "[Product/system name] [does specific thing] in [timeframe or context]."
- "A [descriptor] [mechanism] that [specific result]."

**Rule:** Clarity lives here. No mystery, no vagueness. If the reader still doesn't know what they're looking at after Line 2 — rewrite it.

---

## PART 3 — OUTCOME + IDENTITY SHIFT

**Goal:** Tell the reader what this means for THEM. Turn the demonstration into a personal transformation.

**Must anchor:**
- The specific outcome the reader gets
- A speed advantage, simplicity win, or identity upgrade
- Language that puts the reader in the result — not the seller in the achievement

**Requirements:**
- Starts with "So you can..." or "So you..." or equivalent reader-focused construction
- Connects directly to the mechanism in Line 2
- Ends with a feeling of advantage, momentum, or identity shift

**Example structures:**
- "So you can [specific outcome] without [common obstacle]."
- "So you [do the thing] while [competitors/others are still doing the old thing]."
- "So [identity statement — the version of themselves they want to be]."

**Rule:** This line turns demonstration into transformation. It must be about the reader, not the product.

---

## VISUAL HIERARCHY RULES

**The 3 parts must NOT look like a paragraph.**

Use visual weight to signal the escalation:

```
LARGE / HEAVY       ← Line 1 (Pattern Interrupt)
Medium / Explained  ← Line 2 (Mechanism)
Smaller / Outcome   ← Line 3 (Identity Shift)
```

Or by font weight:
```
Bold, short line     ← Line 1
Regular, clear line  ← Line 2
Lighter, forward line ← Line 3
```

**Rule:** Spacing and breathing room matter as much as the words. Each line should feel visually distinct.

---

## FULL HERO STRUCTURE TEMPLATE

After the 3-part headline, the hero section includes:

```
[Line 1 — Pattern Interrupt]
[Line 2 — Mechanism Reveal]
[Line 3 — Outcome + Identity Shift]

[Supporting proof line — 1 sentence, specific, credibility-building]
[CTA button — action + outcome label]
[Micro reassurance — removes the last hesitation below the button]
```

**Supporting proof line rules:**
- One sentence — a specific result, number, or fact that validates Lines 1–2
- Must feel real and grounded — not a marketing claim
- Examples: a result stat, a testimonial pull-quote, a time-to-result fact

**CTA button rules:**
- Action + outcome label — not "Buy Now" or "Submit"
- What they get, not what they do
- Under 5 words

**Micro reassurance rules:**
- Removes the final hesitation
- Addresses price, risk, or commitment in one line
- Examples: "Instant access · 7-day guarantee · No subscription" / "Free to start · No credit card required"

---

## STRATEGIC ANGLES — CHOOSE ONE

Pick the angle that matches the offer and audience:

**A) Speed dominance**
Best for: productivity tools, launch systems, fast-result offers
Tone: competitive advantage, efficiency
Line 1 leans into: competitors being slower, time being wasted

**B) Fear of falling behind**
Best for: emerging technology, market-timing offers, trend-based products
Tone: urgency, opportunity cost
Line 1 leans into: the window closing, the cost of waiting

**C) Identity upgrade**
Best for: personal development, professional tools, creator economy products
Tone: transformation, aspiration
Line 1 leans into: who they want to become vs. who they are now

**D) Proof of concept / AI-driven result**
Best for: software, automation tools, AI products
Tone: demonstration, inevitability
Line 1 leans into: what the system already did — proof before the pitch

**E) Clean authority**
Best for: professional audiences, B2B, premium price points
Tone: precision, expertise, quiet confidence
Line 1 leans into: a sharp truth or reframe, not a hook

---

## OUTPUT FORMAT

Deliver:

```
## STRATEGIC ANGLE SELECTED
---
[Which angle, and 1-sentence reason based on the inputs]
---

## 3-PART HEADLINE (OPTION A)
---
Line 1: [copy]
Line 2: [copy]
Line 3: [copy]
---

## 3-PART HEADLINE (OPTION B)
---
Line 1: [copy]
Line 2: [copy]
Line 3: [copy]
---

## FULL HERO SECTION
---
[Complete hero section with headline, proof line, CTA, micro reassurance]
---
```

Always deliver 2 headline variants. The user selects or combines from them.

---

*License: Open — any agent may use this skill*
*Created: 2026-05-21*
