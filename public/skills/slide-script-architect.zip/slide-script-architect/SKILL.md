---
name: slide-script-architect
description: Transforms a course module from COURSE-OVERVIEW.md into narration scripts, ElevenLabs audio generation commands, and complete PPTX slide content specs ready for the slide-renderer skill to build. Use this skill whenever the user wants to turn a course module into video-ready assets, generate narration audio for slides, build slide content, or prepare a module for video assembly. Triggers on phrases like "build the slides for module X", "generate audio for phase X", "script this module", "prepare module X for video", or any request to move from course content to video assets.
---

# Slide Script Architect

Transform a course module into three production-ready outputs:
1. Narration scripts per segment
2. ElevenLabs audio generation commands
3. PPTX slide content specs per segment — handed to slide-renderer to build

## Voice configuration

- **Voice ID:** `rCN1DzW3yH6HTMAZaXf6`
- **Model:** `eleven_multilingual_v2`
- **Stability:** 0.5
- **Similarity boost:** 0.75

## ElevenLabs output

ElevenLabs audio must be hosted at a publicly accessible URL for Shotstack to fetch it.
After generating audio via the elevenlabs-voice skill, the file must be uploaded to Cloudinary and the public URL used in the Shotstack JSON soundtrack field.

---

## AI Operator brand design system

### Colors (hex values — never include # prefix in pptxgenjs)
- Background: `0a0f1e`
- Primary accent: `0099ff`
- Cyan accent: `00c8ff`
- Card background: `0d1b2e`
- Card border: `1a3a5c`
- Deep background: `0a1628`
- Footer background: `060c17`
- White: `ffffff`
- Muted: `8899aa`
- Header bar: `0066cc`

### Fonts
- Primary: `Trebuchet MS` (header/bold)
- Body: `Calibri`

### Slide dimensions
- Layout: `LAYOUT_WIDE` (13.3" × 7.5")
- All coordinates in inches

---

## Slide types

### Type A — Hero/Intro
Used for: phase intro, module openers

Layout:
- Dark background `0a0f1e`
- Left half: AI Operator logo (top-left), phase badge, large title (white + cyan second word), subtitle text, tagline
- Right half: vertical divider line, decorative grid/circle graphic area, stats box (dark card, bottom-right)
- Footer bar: `060c17` with "Days X–X" left, "© 2026 AI Operator" right

### Type C — Module overview
Used for: day overview showing numbered steps

Layout:
- Blue header bar full width: `0099ff`, "DAY X" label left, module title centered, clock icon + time right
- 5 vertical columns, each: dark card `0d1b2e` with cyan border `0099ff`, filled cyan circle with number, bold step name, time badge at bottom
- AI Operator logo bottom-right

### Type D — Step detail (most common)
Used for: individual lesson teaching slides

Layout:
- Dark header bar `0a0f1e` with blue accent line below
- Top-left badge: "DAY X · STEP X" on `0066cc`
- Title centered in header (white + one cyan accent word)
- Top-right: time badge (white border box)
- Body left 52%: italic intro line, 4 content cards (dark `0d1b2e`, blue left border `0099ff`, bold white title + muted body)
- Body right 44%: dark panel `0d1b2e` with cyan border, "THE RULE" / "YOUR FORMULA" label, formula box, "WHY IT WORKS" / "EXAMPLES" label, 4 bullet points with cyan › arrows, italic quote box
- Footer: `060c17`, "Days X–X" left, "© 2026 AI Operator" right
- AI Operator logo bottom-right corner

### Type E — Outro/Summary
Used for: module wrap-up

Layout:
- Similar to Type A but with "WHAT'S NEXT" callout and checklist of completed items

---

## Segment structure

Every module breaks into this pattern:

```
intro   → phaseX-01-intro        (Type A)
overview → phaseX-02-overview    (Type C)
lesson1 → phaseX-03-[slug]       (Type D)
lesson2 → phaseX-04-[slug]       (Type D)
...
outro   → phaseX-XX-outro        (Type E)
```

---

## Output format

For each module produce in order:

### 1. Segment map

| # | Segment ID | Slide Type | Content | Est. Duration |
|---|---|---|---|---|
| 01 | phase1-01-intro | Type A | Phase intro | 25s |
| 02 | phase1-02-overview | Type C | Day 1 overview | 20s |
| 03 | phase1-03-decision-lock | Type D | The Decision Lock Rule | 75s |

---

### 2. Narration scripts

For each segment:

#### [segment-id]
**Narration:** [Full spoken text exactly as ElevenLabs will speak it]
**Duration estimate:** [seconds]
**Slide type:** [A/C/D/E]

---

### 3. ElevenLabs commands

```bash
python scripts/elevenlabs_voice_api.py tts \
  --text "FULL NARRATION TEXT" \
  --voice-id rCN1DzW3yH6HTMAZaXf6 \
  --output phase1-01-intro.mp3
```

One command per segment.

---

### 4. PPTX slide content specs

For each segment, output a complete content spec in this format. Do NOT generate Shotstack JSON — that is slide-renderer's job.

#### TYPE A SPEC
```
SEGMENT_ID: phase1-01-intro
SLIDE_TYPE: A
PHASE_BADGE: PHASE 1
TITLE_LINE1: Launch
TITLE_LINE2: Fast.  ← (cyan)
SUBTITLE: From zero to a live, selling digital product in 72 hours — using AI.
STATS:
  - value: $1,200+  | label: avg. first-month revenue
  - value: 72 hrs   | label: from zero to first sale
  - value: $17-$47  | label: top-selling price range
STATS_LABEL: WHAT OTHERS ARE DOING
FOOTER_LEFT: Days 1–3
AUDIO_URL: PLACEHOLDER
DURATION: PLACEHOLDER
```

#### TYPE C SPEC
```
SEGMENT_ID: phase1-02-overview
SLIDE_TYPE: C
DAY_LABEL: DAY 1
MODULE_TITLE: Decision Lock & Validation
TIME_ESTIMATE: 2-3 hrs
STEPS:
  1. Brain Dump Problems | 15 min
  2. Validate Demand | 30 min
  3. Define Your Product | 20 min
  4. Create Offer Outline | 45 min
  5. Set Your Price | 10 min
FOOTER_LEFT: Days 1–3
AUDIO_URL: PLACEHOLDER
DURATION: PLACEHOLDER
```

#### TYPE D SPEC
```
SEGMENT_ID: phase1-03-decision-lock
SLIDE_TYPE: D
DAY_LABEL: DAY 1
STEP_LABEL: STEP 1
TITLE: The Decision [Lock] Rule   ← word in [] renders cyan
TIME_ESTIMATE: 75 MIN
INTRO_LINE: Why you can't change your idea after Day 1 — and why that's the point.
CARDS:
  1. title: The real problem      | body: Most people never commit to ONE idea — they keep pivoting before executing
  2. title: What creates clarity? | body: Action, not analysis. Execution reveals what thinking never can.
  3. title: Why lock in?          | body: Execution beats endless pivoting. A mediocre idea executed well makes money.
  4. title: Your move             | body: Post publicly + tag 2 accountability partners before midnight tonight.
RIGHT_PANEL_LABEL: THE RULE
FORMULA: Pick your idea. Lock it. Don't look back.
SECONDARY_LABEL: WHY IT WORKS
BULLETS:
  - Clarity comes from commitment, not research
  - Analysis paralysis kills more businesses than bad ideas
  - Public accountability increases follow-through by 65%
  - Day 1 locked = Day 14 executed
QUOTE: "A mediocre idea executed well makes money."
FOOTER_LEFT: Days 1–3
AUDIO_URL: PLACEHOLDER
DURATION: PLACEHOLDER
```

---

## Quality checks

- Narration sounds natural when read aloud
- Segment IDs follow `phaseX-XX-slug` exactly
- Every spec has AUDIO_URL and DURATION as PLACEHOLDER — never fill these in
- Content matches COURSE-OVERVIEW.md — no invented content
- Title cyan word marked with [brackets] in TYPE D specs
- All 4 cards filled for TYPE D — never leave a card empty

## What this skill does NOT do

- Does not call ElevenLabs — outputs commands for the pipeline to run
- Does not build PPTX files — that is slide-renderer's job
- Does not generate Shotstack JSON — that is also slide-renderer's job
- Does not upload audio — that is cloudinary's job
- Does not invent course content not in COURSE-OVERVIEW.md
