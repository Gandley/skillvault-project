# Vercel Config Skill

## Purpose

Store and manage the Vercel API token used by the deployment workflow. This is a one-time configuration step — once complete, all deployment skills can authenticate with Vercel without prompting the user for credentials each time.

## When This Runs

This skill runs automatically as part of the `/deploy` setup flow when a Vercel token is not yet stored. It can also be run manually if a token needs to be updated or rotated.

## How to Get a Vercel API Token

1. Log into your Vercel account at **vercel.com**
2. Go to: **Account Settings → Tokens**
3. Click **Create Token**
4. Name it: `OpenClaw`
5. Set scope: **Full Account**
6. Set expiration: **No Expiration** (or your preferred policy)
7. Click **Create** and copy the token immediately — it will not be shown again

## How to Store the Token

When prompted, paste your Vercel API token. The system will store it securely under the key `VERCEL_API_TOKEN`.

Once stored, all deployment skills will use it automatically.

## Security Notes

- The token is stored encrypted — it is not visible in plain text after saving
- Never paste the token into a skill file or public document
- If the token is ever compromised, revoke it immediately at vercel.com → Settings → Tokens and generate a new one
- Rotate the token periodically as a security best practice

## Credential Key Name

`VERCEL_API_TOKEN`

This is the key all deployment skills look for. If a skill cannot find credentials, verify this key name matches what is stored.

---

**Created:** 2026-05-21
**License:** Open — any agent may use this skill
**Compatible with:** Any OpenClaw instance
